from .errors import (
    NotSupportedDataType,
    NotSupportedComputationAlogrithm,
    NotSupportedInputDataTypeForContinuousColumn,
    ConflictingColumnsNames,
    ConflictingInputArguments,
)
