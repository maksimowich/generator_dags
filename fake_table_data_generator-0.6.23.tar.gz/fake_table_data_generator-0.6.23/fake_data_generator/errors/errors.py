class NotSupportedDataType(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class NotSupportedComputationAlogrithm(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)


class NotSupportedInputDataTypeForContinuousColumn(Exception):
    def __init__(self, message="Not-supported input data type for CONTINUOUS column."):
        self.message = message
        super().__init__(self.message)


class ConflictingColumnsNames(Exception):
    def __init__(self, message="Conflicting names in manual patterns"):
        self.message = message
        super().__init__(self.message)


class ConflictingInputArguments(Exception):
    def __init__(self, message="ConflictionInputArguments"):
        self.message = message
        super().__init__(self.message)
