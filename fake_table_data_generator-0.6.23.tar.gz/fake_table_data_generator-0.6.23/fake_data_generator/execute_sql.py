import pandas as pd

from .databases.errors import ConnectionTypeIsNotSupported


def execute_sql(
        conn,
        sql_query: str,
) -> pd.DataFrame:
    """
    Executes sql query in database and returns data in pd.DataFrame.

    Parameters
    --------
    conn : sqlalchemy Engine or SparkSession
        Connection to database.

    sql_query : str
        Sql query which will be executed.

    Returns
    --------
        Result of sql query in pd.DataFrame.
    """
    if conn.__class__.__name__ == 'Engine':
        return pd.read_sql_query(sql_query, conn)

    if conn.__class__.__name__ == 'SparkSession':
        return conn.sql(sql_query).toPandas()

    raise ConnectionTypeIsNotSupported()
