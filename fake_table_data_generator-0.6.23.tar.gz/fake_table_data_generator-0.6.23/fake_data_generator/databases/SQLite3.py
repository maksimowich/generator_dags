from typing import List
from dateutil import parser
import re

import numpy as np
import pandas as pd

from .Database import Database
from ..data_types import (
    DataType,
    Decimal, Float64,
    IntegerType, Int64, Int32, Int16, Boolean,
    String, Varchar, Char,
    Date, Timestamp
)
from ..errors import NotSupportedDataType


class SQLite3(Database):
    @staticmethod
    def get_describe_query(
            table_name_and_schema: str,
    ) -> str:
        return f"""
            PRAGMA table_info({table_name_and_schema});
        """

    @staticmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ) -> str:
        return f"""
            CREATE TABLE IF NOT EXISTS {table_name_and_schema}
            ({columns_names_and_types});
        """

    @staticmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        data_type = describe_data_row.get('data_type').lower()

        if "numeric" in data_type or "decimal" in data_type:
            if "numeric" == data_type or "decimal" == data_type:
                return Decimal()
            elif "," in data_type:
                precision, scale = re.search(r"\w\((\d+),(\d+)\)", data_type).groups()
                return Decimal(int(precision), int(scale))
            else:
                precision = re.search(r"\w\((\d+)\)", data_type).groups()[0]
                return Decimal(int(precision))

        elif data_type in ["real", "double", "float", ]:
            return Float64()

        elif "bigint" == data_type:
            return Int64()

        elif "integer" == data_type or "int" == data_type:
            return Int32()

        elif "smallint" == data_type:
            return Int16()

        elif "boolean" == data_type:
            return Boolean()

        elif "text" == data_type or "string" == data_type:
            return String()

        elif "varchar" in data_type:
            n = re.search(r"\w\((\d+)\)", data_type).groups()[0]
            return Varchar(n)

        elif "char" in data_type:
            n = re.search(r"\w\((\d+)\)", data_type).groups()[0]
            return Char(n)

        elif "date" == data_type:
            return Date()

        elif "timestamp" == data_type or "datetime" == data_type:
            return Timestamp()

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for SQLite"
            )

    @staticmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        if isinstance(data_type, Decimal):
            if data_type.precision is None:
                return "numeric"
            elif data_type.precision is not None and data_type.scale is None:
                return f"numeric({data_type.precision})"
            else:
                return f"numeric({data_type.precision},{data_type.scale})"

        elif isinstance(data_type, Float64):
            return "real"

        elif isinstance(data_type, Int64):
            return "bigint"

        elif isinstance(data_type, Int32):
            return "integer"

        elif isinstance(data_type, Int16):
            return "smallint"

        elif isinstance(data_type, Boolean):
            return "boolean"

        elif isinstance(data_type, String):
            return "text"

        elif isinstance(data_type, Varchar):
            if data_type.n is None:
                return "varchar"
            else:
                return f"varchar({data_type.n})"

        elif isinstance(data_type, Char):
            return f"char({data_type.n})"

        elif isinstance(data_type, Date):
            return f"date"

        elif isinstance(data_type, Timestamp):
            return "timestamp"

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for SQLite"
            )

    @staticmethod
    def get_correct_column_values(
            column_values: pd.Series,
            column_data_type: DataType,
            conn_type: str,
    ) -> pd.Series:
        null_values = column_values[column_values.isnull()]
        null_values.replace([pd.NaT, np.NAN, None], None, inplace=True)

        if isinstance(column_data_type, IntegerType):
            correct_column_values = pd.concat([
                column_values.dropna().astype(column_data_type.NUMPY_TYPE),
                null_values,
            ]).sort_index()
            return correct_column_values

        elif isinstance(column_data_type, Date):
            return pd.to_datetime(column_values).dt.date

        elif isinstance(column_data_type, Timestamp):
            first_valid_index = column_values.first_valid_index()
            if first_valid_index is not None and isinstance(column_values.iloc[first_valid_index], str):
                return column_values.apply(lambda x: parser.parse(x) if not pd.isna(x) else x)
            else:
                return column_values.apply(lambda x: x.to_pydatetime() if not pd.isna(x) else x)

        return column_values

    @staticmethod
    def get_unix_timestamp_column(
            historicity_column_name: str,
            historicity_column_type: DataType,
            string_datetime_format: str,
    ) -> str:
        if isinstance(historicity_column_type, (Timestamp, Date)):
            column = historicity_column_name
        elif isinstance(historicity_column_type, (String, Varchar, Char)) and string_datetime_format is not None:
            column = f"datetime({historicity_column_name}, '{string_datetime_format.replace('%', '%%')}')"
        else:
            raise Exception("incorrect data type for historicity columns!")
        return f"cast(strftime('%s', {column}) as float)"
