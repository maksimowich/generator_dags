from typing import Type

from .errors import (
    ConnectionTypeIsNotSupported,
    DatabaseIsNotSupported,
)
from .Database import Database
from .Postgresql import Postgresql
from .Impala import Impala
from .Hive import Hive
from .SQLite3 import SQLite3
from .MSSQL import MSSQL
from .ClickHouse import ClickHouse


def get_db(
        conn,
) -> Type[Database]:
    """
    Returns specific Database class from connection.

    Parameters
    --------
    conn : sqlalchemy Engine or SparkSession
        Connection to database.

    Returns
    --------
        Specific Database class which is inferred by connection information.
    """
    if conn.__class__.__name__ == 'Engine':
        if conn.name == 'postgresql':
            return Postgresql
        elif conn.name == 'impala':
            return Impala
        elif conn.name == 'sqlite':
            return SQLite3
        elif conn.name == 'mssql':
            return MSSQL
        elif conn.name == 'clickhouse':
            return ClickHouse
        else:
            raise DatabaseIsNotSupported

    elif conn.__class__.__name__ == 'SparkSession':
        return Hive  # если спарк сессия, то hive, поддержки с другими БД пока не реализованы

    else:
        raise ConnectionTypeIsNotSupported()
