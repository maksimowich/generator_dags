from typing import List
from abc import ABC, abstractmethod

import numpy as np
import pandas as pd

from ..data_types import DataType, IntegerType, TimestampWithTZ


class Database(ABC):
    @staticmethod
    @abstractmethod
    def get_describe_query(
            table_name_and_schema: str,
    ) -> str:
        pass

    @staticmethod
    @abstractmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ) -> str:
        pass

    @staticmethod
    @abstractmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        pass

    @staticmethod
    @abstractmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        pass

    @staticmethod
    def get_correct_column_values(
            column_values: pd.Series,
            column_data_type: DataType,
            conn_type: str,
    ) -> pd.Series:
        """
        Returns pd.Series object with correct data type.
        This conversion is needed to bring values of different databases to unified types.

        conversion logic:
            Values of Int64, Int32, Int16, Int8 data types are converted to np.int64, np.int32, np.int16, np.int8 correspondingly.
            Values of Decimal, Float64, Float32 data types are converted to float.
            Values of Date type are converted to datetime.date.
            Values of Timestamp, TimestampWithTZ types are converted to pandas.Timestamp.
            Values of String, Varchar, Char types are converted to str.
            Values of Boolean type are converted to bool.

        Parameters
        ----------
        column_values : pd.Series object
            Contains data of table column in Series.
        column_data_type : DataType
            Column data type.
        conn_type : string
            'Engine' or 'SparkSession'

        Returns
        ----------
            pd.Series object with values of correct type.
        """
        if isinstance(column_data_type, TimestampWithTZ):
            return pd.to_datetime(column_values, utc=True, errors="coerce")

        elif not isinstance(column_data_type, IntegerType):
            return column_values

        else:
            null_values = column_values[column_values.isnull()]
            null_values.replace([pd.NaT, np.NAN, None], None, inplace=True)
            correct_column_values = pd.concat([
                column_values.dropna().astype(column_data_type.NUMPY_TYPE),
                null_values,
            ]).sort_index()
            return correct_column_values

    @staticmethod
    @abstractmethod
    def get_select_table_fk_query(
            table_schema: str,
            table_name: str,
    ) -> str:
        pass

    @staticmethod
    @abstractmethod
    def get_unix_timestamp_column(
            historicity_column_name: str,
            historicity_column_type: DataType,
            string_datetime_format: str,
    ) -> str:
        pass
