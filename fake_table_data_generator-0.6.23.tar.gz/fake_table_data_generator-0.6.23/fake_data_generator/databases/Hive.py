from .Impala import Impala


class Hive(Impala):
    pass
