from typing import List

from .Postgresql import Postgresql
from ..data_types import (
    DataType,
    Decimal, Float64, Float32,
    IntegerType, Int64, Int32, Int16, Boolean,
    String, Varchar, Char, UUID,
    Date, Timestamp, TimestampWithTZ,
)
from ..errors import NotSupportedDataType


class MSSQL(Postgresql):
    @staticmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ) -> str:
        schema, name = table_name_and_schema.split('.')
        return f'''
            IF NOT EXISTS (
                SELECT * FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_NAME='{name}' AND TABLE_SCHEMA='{schema}'
            )
            BEGIN
                CREATE TABLE {table_name_and_schema} 
                ({columns_names_and_types});
            END
        '''

    @staticmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        data_type = describe_data_row.get('data_type')
        numeric_precision = describe_data_row.get('numeric_precision')
        numeric_scale = describe_data_row.get('numeric_scale')
        character_maximum_length = describe_data_row.get('character_maximum_length')

        if "decimal" == data_type:
            return Decimal(int(numeric_precision), int(numeric_scale))

        elif "float" == data_type:
            return Float64()

        elif "real" == data_type:
            return Float32()

        elif "bigint" == data_type:
            return Int64()

        elif "int" == data_type:
            return Int32()

        elif "smallint" == data_type:
            return Int16()

        elif "bit" == data_type:
            return Boolean()

        elif "varchar" == data_type:
            if character_maximum_length == -1:
                return String()
            else:
                return Varchar(character_maximum_length)

        elif "text" == data_type:
            return String()

        elif "char" == data_type:
            return Char(character_maximum_length)

        elif "date" == data_type:
            return Date()

        elif "timestamp" == data_type or "datetime" == data_type:
            return Timestamp()

        elif "datetimeoffset" == data_type:
            return TimestampWithTZ()

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for MSSQL"
            )

    @staticmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        if isinstance(data_type, Decimal):
            if data_type.precision is None:
                return "decimal"
            elif data_type.precision is not None and data_type.scale is None:
                return f"decimal({data_type.precision})"
            else:
                return f"decimal({data_type.precision},{data_type.scale})"

        elif isinstance(data_type, Float64):
            return "float"

        elif isinstance(data_type, Float32):
            return "real"

        elif isinstance(data_type, Int64):
            return "bigint"

        elif isinstance(data_type, Int32):
            return "int"

        elif isinstance(data_type, Int16):
            return "smallint"

        elif isinstance(data_type, Boolean):
            return "bit"

        elif isinstance(data_type, String):
            return "text"

        elif isinstance(data_type, Varchar):
            if data_type.n is None:
                return "varchar(max)"
            else:
                return f"varchar({data_type.n})"

        elif isinstance(data_type, Char):
            return f"char({data_type.n})"

        elif isinstance(data_type, Date):
            return f"date"

        elif isinstance(data_type, Timestamp):
            return "datetime"

        elif isinstance(data_type, TimestampWithTZ):
            return "datetimeoffset"

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for MSSQL"
            )

