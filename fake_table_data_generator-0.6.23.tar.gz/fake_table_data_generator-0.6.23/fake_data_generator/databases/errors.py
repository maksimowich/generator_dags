class ConnectionTypeIsNotSupported(Exception):
    def __init__(
            self,
            message="Such connection type is not supported."
    ):
        self.message = message
        super().__init__(self.message)


class DatabaseIsNotSupported(Exception):
    def __init__(
            self,
            message="Database is not supported by fake_table_data_generator library."
    ):
        self.message = message
        super().__init__(self.message)
