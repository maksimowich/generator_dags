from typing import List
import re

import numpy as np
import pandas as pd

from .Database import Database
from ..data_types import (
    DataType,
    Decimal, Float64, Float32,
    IntegerType,
    Int64, Int32, Int16, Int8,
    UInt64, UInt32, UInt16, UInt8,
    Boolean,
    String, Varchar, Char, UUID,
    Date, Timestamp, TimestampWithTZ,
)
from ..errors import NotSupportedDataType


class ClickHouse(Database):
    QUOTE_SYMBOL = '`'
    RANDOM_CLAUSE = 'RAND()'

    @staticmethod
    def get_describe_query(
            table_name_and_schema: str,
    ) -> str:
        return f'''
            DESCRIBE {table_name_and_schema};
        '''

    @staticmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ):
        return f"""
            CREATE TABLE IF NOT EXISTS {table_name_and_schema}
            ({columns_names_and_types})
            {table_details};
        """

    @staticmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        data_type = describe_data_row.get('data_type').lower()

        if "decimal" in data_type:
            precision, scale = re.search(r"\w\((\d+),(\d+)\)", data_type).groups()
            return Decimal(int(precision), int(scale))

        elif "float64" == data_type:
            return Float64()

        elif "float32" == data_type:
            return Float32()

        elif "int64" == data_type:
            return Int64()

        elif "int32" == data_type:
            return Int32()

        elif "int16" == data_type:
            return Int16()

        elif "int8" == data_type:
            return Int8()

        elif "uint64" == data_type:
            return UInt64()

        elif "uint32" == data_type:
            return UInt32()

        elif "uint16" == data_type:
            return UInt16()

        elif "uint8" == data_type:
            return UInt8()

        elif "bool" == data_type:
            return Boolean()

        elif "string" == data_type:
            return String()

        elif "date" == data_type:
            return Date()

        elif "datetime" == data_type:
            return Timestamp()

        elif "uuid" == data_type:
            return UUID()

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for ClickHouse"
            )

    @staticmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        if isinstance(data_type, Decimal):
            if data_type.precision is None:
                raise NotSupportedDataType(
                    message="Decimal data type in ClickHouse must have exactly two arguments: precision and scale"
                )
            elif data_type.precision is not None and data_type.scale is None:
                return f"Decimal({data_type.precision},0)"
            else:
                return f"Decimal({data_type.precision},{data_type.scale})"

        elif isinstance(data_type, Float64):
            return "Float64"

        elif isinstance(data_type, Float32):
            return "Float32"

        elif isinstance(data_type, IntegerType):
            return str(data_type)

        elif isinstance(data_type, Boolean):
            return "Boolean"

        elif isinstance(data_type, (String, Varchar, Char)):
            return "String"

        elif isinstance(data_type, Date):
            return f"Date"

        elif isinstance(data_type, Timestamp):
            return "DateTime"

        elif isinstance(data_type, UUID):
            return "UUID"

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for ClickHouse"
            )

    @staticmethod
    def get_table_details(
            engine,
            table_name: str,
    ) -> str:
        with engine.begin() as conn:
            create_query = conn.execute(f"SHOW CREATE TABLE {table_name};").fetchone()[0]
            pattern = r'CREATE\s+TABLE\s+\S+\s+\((.*?)\)\s+(ENGINE\s*=.*)'
            match = re.search(pattern, create_query, re.DOTALL)
            if match:
                return match.group(2).strip()
            else:
                return None

    @staticmethod
    def get_unix_timestamp_column(
            historicity_column_name: str,
            historicity_column_type: str,
            string_datetime_format: str,
    ) -> str:
        historicity_column_type = historicity_column_type.lower()
        if historicity_column_type == "datetime":
            column = historicity_column_name
        elif historicity_column_type == "date":
            column = f"toDateTime({historicity_column_name})"
        elif string_datetime_format is not None:
            column = f"toDateTime({historicity_column_name}, '{string_datetime_format}')"
        else:
            raise Exception
        return f"toUnixTimestamp({column})"
