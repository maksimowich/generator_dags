from typing import List
import re

import numpy as np
import pandas as pd

from .Database import Database
from ..data_types import (
    DataType,
    Decimal, Float64, Float32,
    IntegerType, Int64, Int32, Int16, Int8, Boolean,
    String, Varchar, Char,
    Date, Timestamp,
)
from ..errors import NotSupportedDataType


class Impala(Database):
    QUOTE_SYMBOL = '`'

    @staticmethod
    def get_describe_query(
            table_name_and_schema: str,
    ) -> str:
        return f'''
            DESCRIBE {table_name_and_schema};
        '''

    @staticmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ):
        if partition_columns:
            pattern = r"(\b(?:{})\s+\w+\b)".format("|".join(partition_columns))
            matches = re.findall(pattern, columns_names_and_types)
            if len(matches) != len(partition_columns):
                raise Exception("specified partition column does not exist in table columns!")
            for match in matches:
                columns_names_and_types = columns_names_and_types.replace(match, "")
            columns_names_and_types = re.sub(r',(?!\s*\w)', '', columns_names_and_types)
            partition_clause = f"PARTITIONED BY ({', '.join(matches)})"
        else:
            partition_clause = ""
        return f"""
            CREATE TABLE IF NOT EXISTS {table_name_and_schema}
            ({columns_names_and_types})
            {partition_clause}
            STORED AS PARQUET;
        """

    @staticmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        data_type = describe_data_row.get('data_type')
        if "decimal" in data_type:
            precision, scale = re.search(r"\w\((\d+),(\d+)\)", data_type).groups()
            return Decimal(int(precision), int(scale))

        elif "double" == data_type:
            return Float64()

        elif "float" == data_type:
            return Float32()

        elif "bigint" == data_type:
            return Int64()

        elif "int" == data_type:
            return Int32()

        elif "smallint" == data_type:
            return Int16()

        elif "tinyint" == data_type:
            return Int8()

        elif "boolean" == data_type:
            return Boolean()

        elif "string" == data_type:
            return String()

        elif "varchar" in data_type:
            n = re.search(r"\w\((\d+)\)", data_type).groups()[0]
            return Varchar(int(n))

        elif "char" in data_type:
            n = re.search(r"\w\((\d+)\)", data_type).groups()[0]
            return Char(int(n))

        elif "date" == data_type:
            return Date()

        elif "timestamp" == data_type:
            return Timestamp()

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for Postgresql"
            )

    @staticmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        if isinstance(data_type, Decimal):
            if data_type.precision is None:
                return "decimal"
            elif data_type.precision is not None and data_type.scale is None:
                return f"decimal({data_type.precision})"
            else:
                return f"decimal({data_type.precision},{data_type.scale})"

        elif isinstance(data_type, Float64):
            return "double"

        elif isinstance(data_type, Float32):
            return "float"

        elif isinstance(data_type, Int64):
            return "bigint"

        elif isinstance(data_type, Int32):
            return "int"

        elif isinstance(data_type, Int16):
            return "smallint"

        elif isinstance(data_type, Int8):
            return "tinyint"

        elif isinstance(data_type, Boolean):
            return "boolean"

        elif isinstance(data_type, String):
            return "string"

        elif isinstance(data_type, Varchar):
            if data_type.n is None:
                return "varchar"
            else:
                return f"varchar({data_type.n})"

        elif isinstance(data_type, Char):
            return f"char({data_type.n})"

        elif isinstance(data_type, Date):
            return f"date"

        elif isinstance(data_type, Timestamp):
            return "timestamp"

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for Postgresql"
            )

    @staticmethod
    def get_correct_column_values(
            column_values: pd.Series,
            column_data_type: DataType,
            conn_type: str,
    ) -> pd.Series:
        if isinstance(column_data_type, IntegerType):
            null_values = column_values[column_values.isnull()]
            null_values.replace([pd.NaT, np.NAN, None], None, inplace=True)
            if isinstance(column_data_type, IntegerType):
                correct_column_values = pd.concat([
                    column_values.dropna().astype(column_data_type.NUMPY_TYPE),
                    null_values,
                ]).sort_index()
                return correct_column_values

        elif isinstance(column_data_type, Decimal) and conn_type == 'SparkSession':
            return column_values.astype(float)

        else:
            return column_values

    @staticmethod
    def get_unix_timestamp_column(
            historicity_column_name: str,
            historicity_column_type: str,
            string_datetime_format: str,
    ) -> str:
        if ("timestamp" in historicity_column_type
                or historicity_column_name == "date"):
            column = historicity_column_name
        elif string_datetime_format is not None:
            column = f"TO_TIMESTAMP({historicity_column_name}, '{string_datetime_format}')"
        else:
            raise Exception
        return f"UNIX_TIMESTAMP({column})"
