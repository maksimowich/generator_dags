from typing import List

import pandas as pd

from .Database import Database
from ..data_types import (
    DataType,
    Decimal, Float64, Float32,
    Int64, Int32, Int16, Boolean,
    String, Varchar, Char, UUID,
    Date, Timestamp, TimestampWithTZ,
)
from ..errors import NotSupportedDataType


class Postgresql(Database):
    QUOTE_SYMBOL = '"'

    @staticmethod
    def get_describe_query(
            table_name_and_schema: str,
    ) -> str:
        # default schema is public:
        if table_name_and_schema.find('.') != -1:
            schema, name = table_name_and_schema.split('.')
        else:
            schema = "public"
            name = table_name_and_schema

        return f'''
            SELECT
                column_name AS col_name,
                data_type,
                character_maximum_length,
                numeric_precision,
                numeric_scale
            FROM information_schema.columns
            WHERE table_schema = '{schema}' AND table_name = '{name}';
        '''

    @staticmethod
    def get_create_query(
            table_name_and_schema: str,
            columns_names_and_types: str,
            partition_columns: List[str],
            table_details: str,
    ) -> str:
        if table_name_and_schema.find('.') != -1:
            schema, name = table_name_and_schema.split('.')
        else:
            schema = "public"
            name = table_name_and_schema
        return f'''
            do $$
                begin
                if not exists(
                 select 
                    table_name
                FROM 
                    information_schema.columns
                WHERE 
                    table_schema = '{schema}' AND table_name = '{name}')
                then
                    CREATE TABLE IF NOT EXISTS {table_name_and_schema} 
                    ({columns_names_and_types});
                end if;
            end
            $$;
        '''

    @staticmethod
    def get_generator_data_type(
            describe_data_row: dict,
    ) -> DataType:
        data_type = describe_data_row.get('data_type')
        numeric_precision = describe_data_row.get('numeric_precision')
        numeric_scale = describe_data_row.get('numeric_scale')
        character_maximum_length = describe_data_row.get('character_maximum_length')

        if "numeric" == data_type:
            precision = int(numeric_precision) if not pd.isnull(numeric_precision) else None
            scale = int(numeric_scale) if not pd.isnull(numeric_precision) else None
            return Decimal(precision, scale)

        elif "double precision" == data_type:
            return Float64()

        elif "real" == data_type:
            return Float32()

        elif "bigint" == data_type:
            return Int64()

        elif "integer" == data_type:
            return Int32()

        elif "smallint" == data_type:
            return Int16()

        elif "boolean" == data_type:
            return Boolean()

        elif "character varying" == data_type:
            if not pd.isnull(character_maximum_length):
                return Varchar(int(character_maximum_length))
            else:
                return String()

        elif "text" == data_type:
            return String()

        elif "character" == data_type:
            return Char(character_maximum_length)

        elif "date" == data_type:
            return Date()

        elif "timestamp without time zone" == data_type:
            return Timestamp()

        elif "timestamp with time zone" == data_type:
            return TimestampWithTZ()

        elif "uuid" == data_type:
            return UUID()

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for Postgresql"
            )

    @staticmethod
    def get_db_data_type(
            data_type: DataType,
    ) -> str:
        if isinstance(data_type, Decimal):
            if data_type.precision is None:
                return "numeric"
            elif data_type.precision is not None and data_type.scale is None:
                return f"numeric({data_type.precision})"
            else:
                return f"numeric({data_type.precision},{data_type.scale})"

        elif isinstance(data_type, Float64):
            return "double precision"

        elif isinstance(data_type, Float32):
            return "real"

        elif isinstance(data_type, Int64):
            return "bigint"

        elif isinstance(data_type, Int32):
            return "integer"

        elif isinstance(data_type, Int16):
            return "smallint"

        elif isinstance(data_type, Boolean):
            return "boolean"

        elif isinstance(data_type, String):
            return "text"

        elif isinstance(data_type, Varchar):
            if data_type.n is None:
                return "varchar"
            else:
                return f"varchar({data_type.n})"

        elif isinstance(data_type, Char):
            return f"char({data_type.n})"

        elif isinstance(data_type, Date):
            return f"date"

        elif isinstance(data_type, Timestamp):
            return "timestamp"

        elif isinstance(data_type, TimestampWithTZ):
            return "timestamp with time zone"

        elif isinstance(data_type, UUID):
            return "uuid"

        else:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for Postgresql"
            )

    @staticmethod
    def get_select_table_fk_query(
            table_schema: str,
            table_name: str,
    ) -> str:
        return f'''
            with v as (
                select
                    con.conname AS constraint_name,
                    nsp.nspname AS table_schema,
                    cls.relname AS table_name,
                    (regexp_matches(pg_get_constraintdef(con.oid), 'FOREIGN KEY \(([^)]+)\) REFERENCES ([^ ]+)\(([^)]+)\)'))[1] AS column_name,
                    pg_get_constraintdef(con.oid) AS constraint_definition,
                    r_nsp.nspname AS foreign_table_schema,
                    r_cls.relname AS foreign_table_name,
                    (regexp_matches(pg_get_constraintdef(con.oid), 'FOREIGN KEY \(([^)]+)\) REFERENCES ([^ ]+)\(([^)]+)\)'))[3] AS foreign_column_name
                FROM pg_constraint con
                JOIN pg_class cls ON con.conrelid = cls.oid
                JOIN pg_namespace nsp ON cls.relnamespace = nsp.oid
                LEFT JOIN pg_class r_cls ON con.confrelid = r_cls.oid
                LEFT JOIN pg_namespace r_nsp ON r_cls.relnamespace = r_nsp.oid
                WHERE 1=1
                    and con.contype = 'f'
                    and nsp.nspname = '{table_schema}'
                    AND cls.relname = '{table_name}'
            )
            select
                v.*,
                c.data_type as column_data_type,
                c.numeric_scale as column_numeric_scale,
                c.numeric_precision as column_numeric_precision,
                c.character_maximum_length as column_character_maximum_length,
                fk_c.data_type as foreign_column_data_type,
                fk_c.numeric_scale as foreign_column_numeric_scale,
                fk_c.numeric_precision as foreign_column_numeric_precision,
                fk_c.character_maximum_length as foreign_column_character_maximum_length
            from v
            JOIN information_schema.columns AS c
                ON c.table_schema = v.table_schema
                AND c.table_name = v.table_name
                AND c.column_name = v.column_name
            JOIN information_schema.columns AS fk_c
                ON fk_c.table_schema = v.foreign_table_schema
                AND fk_c.table_name = v.foreign_table_name
                AND fk_c.column_name = v.foreign_column_name;   
        '''

    @staticmethod
    def get_unix_timestamp_column(
            historicity_column_name: str,
            historicity_column_type: DataType,
            string_datetime_format: str,
    ) -> str:
        if isinstance(historicity_column_type, (Date, Timestamp, TimestampWithTZ)):
            column = historicity_column_name
        elif isinstance(historicity_column_type, (String, Varchar, Char)) and string_datetime_format is not None:
            column = f"TO_TIMESTAMP({historicity_column_name}, '{string_datetime_format.replace('%', '%%')}')"
        else:
            raise Exception("incorrect data type for historicity columns!")
        return f"extract(epoch from {column})"
