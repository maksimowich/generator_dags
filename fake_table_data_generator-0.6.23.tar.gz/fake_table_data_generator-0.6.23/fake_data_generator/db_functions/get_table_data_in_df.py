from typing import List
import pandas as pd
from ..databases import get_db
from ..execute_sql import execute_sql


def get_table_data_in_df(
        conn,
        table_name: str,
        columns_to_select: List[str],
        number_of_rows_to_select: int,
) -> pd.DataFrame:
    """
    Returns table data in pd.Dataframe.
    Data is ordered by random.

    Parameters
    ----------
    conn: sqlalchemy Engine or SparkSession
        Connection to database.

    table_name : string
        Source table name with schema from which to select data.

    columns_to_select: list of strings
        Names of columns which will be selected.

    number_of_rows_to_select: int
        Number of rows to select.

    Returns
    ----------
        Table data in pd.Dataframe.
    """
    if number_of_rows_to_select is not None:
        limit_clause = f"LIMIT {number_of_rows_to_select}"
    else:
        limit_clause = ''

    db = get_db(conn)
    if hasattr(db, 'QUOTE_SYMBOL'):
        quote = db.QUOTE_SYMBOL
    else:
        quote = '"'

    if hasattr(db, 'RANDOM_CLAUSE'):
        random_clause = db.RANDOM_CLAUSE
    else:
        random_clause = 'RANDOM()'

    columns_names = ','.join([quote + column_name + quote for column_name in columns_to_select])

    select_query = f'''
        SELECT {columns_names}
        FROM {table_name}
        ORDER BY {random_clause} {limit_clause};
    '''

    table_data_df = execute_sql(conn, select_query)
    table_data_df.columns = table_data_df.columns.str.replace("'", '')
    return table_data_df
