import pandas as pd
from ..databases import get_db
from ..execute_sql import execute_sql


def get_table_description_data_in_df(
        conn,
        table_name: str,
) -> pd.DataFrame:
    """
    Returns table description data in pd.Dataframe.
    Result DataFrame contains columns "col_name" and "data_type".
    Result can also contain other columns depending on database.

    Parameters
    ----------
    conn : sqlalchemy Engine or SparkSession
        Connection to database.

    table_name: string
        Name and schema of source table from which data will be selected.

    Returns
    ----------
        Table description data in pd.Dataframe.
    """
    db = get_db(conn)
    describe_query = db.get_describe_query(table_name)

    describe_data_in_df = execute_sql(conn, describe_query) \
        .rename(columns={'name': 'col_name', 'type': 'data_type'})

    # describe_data_in_df['col_name'] = describe_data_in_df['col_name'].str.lower()
    # describe_data_in_df['data_type'] = describe_data_in_df['data_type'].str.lower()
    return describe_data_in_df
