from typing import Dict, List, Union
from copy import copy
import json

from ...create_table import create_table
from ...errors import ConflictingInputArguments
from ...columns import (
    Column,
    ColumnWithMix,
    MultipleColumns,
    MultipleCategoricalColumns,
    MULTIPLE_COLUMNS,
    MULTIPLE_COLUMNS_CLASS_NAMES,
    IncrementalIDColumn,
    get_historicity_pattern,
)
from ...get_obj_from_str import get_obj_from_str
from .execute_insertion import execute_insertion
from .get_patterns_as_class_objects import get_patterns_as_class_objects
from ...db_functions import get_table_description_data_in_df


def get_columns_names(
        table_profile: Dict[str, Dict],
) -> List[str]:
    columns_names = []
    for pattern_name, pattern_info in table_profile.items():
        if pattern_info['type'] in MULTIPLE_COLUMNS_CLASS_NAMES:
            columns_names.extend([column_name for column_name in pattern_info['columns']])
        else:
            columns_names.append(pattern_name)
    return columns_names


def delete_overlapping_patterns(
    columns_info: List[Union[Column, MultipleColumns]],
    table_profile: Dict[str, Dict],
) -> None:

    def delete_pattern(
            column_name: str,
    ) -> None:
        if (column_name in table_profile
                and table_profile[column_name]['type'] not in [cls.CLASS_NAME for cls in MULTIPLE_COLUMNS]):
            del table_profile[column_name]
        else:
            for pattern_name, pattern_info in table_profile.items():
                if (pattern_info['type'] in [cls.CLASS_NAME for cls in MULTIPLE_COLUMNS]
                        and column_name in pattern_info['columns']):
                    del table_profile[pattern_name]

    table_profile_columns_names = get_columns_names(table_profile)
    for pattern in columns_info:
        if isinstance(pattern, MultipleColumns):
            for column in pattern.get_columns():
                if column.get_column_name() in table_profile_columns_names:
                    delete_pattern(column.get_column_name())
        else:
            if pattern.get_column_name() in table_profile_columns_names:
                delete_pattern(pattern.get_column_name())


def set_ids_start_values(
    table_patterns,
    table_name,
    conn,
) -> None:
    for pattern in table_patterns:
        if isinstance(pattern, IncrementalIDColumn) and pattern.next_id is None:
            pattern.set_next_id(table_name, conn)


def get_columns_order(patterns) -> List[str]:
    columns_order = []
    for pattern in patterns:
        if isinstance(pattern, Column):
            columns_order.append(pattern.get_column_name())
        elif isinstance(pattern, MultipleColumns):
            columns_order.extend(pattern.get_columns_names())
        else:
            raise Exception("patterns should be of type Column or MultipleColumns")
    return columns_order


def convert_data_types_to_objects(
        table_profile: Dict,
) -> None:
    for pattern_info in table_profile.values():
        if not isinstance(pattern_info, Dict):
            continue
        if pattern_info['type'] in MULTIPLE_COLUMNS_CLASS_NAMES:
            for column_info in pattern_info["columns"].values():
                column_info["data_type"] = get_obj_from_str(column_info["data_type"])
        else:
            pattern_info["data_type"] = get_obj_from_str(pattern_info["data_type"])


def get_patterns_with_mix(
        patterns: List[Union[Column, MultipleColumns]],
) -> List[ColumnWithMix]:
    patterns_with_mix = []
    for pattern in patterns:
        if isinstance(pattern, ColumnWithMix) and pattern.has_mix():
            patterns_with_mix.append(pattern)
        elif isinstance(pattern, MultipleColumns):
            patterns_with_mix.extend(get_patterns_with_mix(pattern.get_columns()))
    return patterns_with_mix


def generate_table_from_profile(
        dest_table_name: str,
        number_of_rows_to_insert: int,
        batch_size: int,
        conn=None,
        output_file_format: str = None,
        source_table_profile: Union[dict, str] = None,
        columns_info: List[Union[Column, MultipleColumns]] = None,
        output_file_starting_postfix: int = 1,
        columns_order: Union[List[str], str] = None,
        conn_for_columns_order=None,
        partition_columns: List[str] = None,
        key_columns_names: List[str] = None,
        table_details: str = None,
        generate_mix: bool = False,
        mix_columns_names: List[str] = None,
) -> None:
    """
    Generates fake table data into table in database or files of specific formats ('parquet', 'csv').

    Parameters
    ------------
    dest_table_name: str
        Name of table or common part of files` names.
        If table is absent in database, it will be created.
    number_of_rows_to_insert: int
        Number of rows that will be inserted into table or files.
    batch_size: int
        Inserting records into table occurs iteratively in batches.
        This parameter allows controlling how many rows will be inserted in one batch.
    conn: sqlalchemy Engine or SparkSession
        Connection to database.
    output_file_format: str
        Output file format. For example: 'csv', 'parquet_1.0'.
    source_table_profile: dict or str
        If parameter is of type str, then parameter represents path to table profile.
        If parameter is of type dict, then parameter represents table profile itself.
    columns_info: list of Column-like or MultipleColumns-like objects
        This parameter is used to overwrite generation algorithms for specific columns.
    output_file_starting_postfix: int
        If data is generated into files, then this parameter is used to set postfix for files` names.
        For example:
            If parameters are set as such:
                dest_table_name='fake_data'
                output_file_format='csv'
                output_file_starting_postfix=5
            Then output file names will be:
                'fake_data_5.csv'
                'fake_data_6.csv'
                'fake_data_7.csv'
                ...
    columns_order: List[str] or str
        List of columns` names or table name from which columns` order will be inferred.

    conn_for_columns_order: sqlalchemy.Engine or SparkSession
        If columns order must be taken from table in other DB, this parameter is used
        to specify connection to the other DB.

    partition_columns: List[str]
        The parameter is used to specify columns` names by which generated table will be partitioned.
        Parameter is relevant only with certain DB.

    key_columns_names: List[str]
        The parameter is used to overwrite key columns` names for Historicity pattern.

    table_details: str
        The parameter contains string which will be appended to the end of CREATE TABLE sql statement.
        For example, these parameter can contain information about table engine and sorting for ClickHouse DB.

    generate_mix: bool
        Whether to generate data from mix pattern for columns.

    mix_columns_names: List[str]
        The parameter is only relevant

    Returns
    ----------
    """
    if conn is not None and output_file_format is not None:
        raise ConflictingInputArguments("only one destination source can be specified")

    if isinstance(source_table_profile, str):
        with open(source_table_profile, 'r', encoding='utf-8') as file:
            table_profile = json.load(file)
            convert_data_types_to_objects(table_profile)
    elif isinstance(source_table_profile, dict):
        table_profile = copy(source_table_profile)
    elif source_table_profile is None:
        table_profile = {}
    else:
        raise TypeError("invalid argument type, source_table_profile must be an str, dict or None")

    if isinstance(columns_order, str):
        columns_order = get_table_description_data_in_df(conn_for_columns_order, columns_order)['col_name'].tolist()
    elif columns_order is None and table_profile.get("__columns_order__") is not None:
        columns_order = table_profile.get("__columns_order__")

    if table_profile.get("__columns_order__") is not None:
        del table_profile["__columns_order__"]

    table_details = table_details or table_profile.get("__table_details__")
    if table_profile.get("__table_details__") is not None:
        del table_profile["__table_details__"]

    if columns_info is None:
        columns_info = []

    delete_overlapping_patterns(
        columns_info=columns_info,
        table_profile=table_profile,
    )

    table_patterns = get_patterns_as_class_objects(
        table_patterns_dict=table_profile,
        conn=conn,
    ) + columns_info

    historicity_pattern = get_historicity_pattern(table_patterns)
    if historicity_pattern and key_columns_names:
        historicity_pattern.set_key_columns_names(key_columns_names)

    if columns_order is None:
        columns_order = get_columns_order(table_patterns)

    if conn:
        create_table(
            conn=conn,
            table_name=dest_table_name,
            table_patterns=table_patterns,
            columns_order=columns_order,
            partition_columns=partition_columns,
            table_details=table_details,
        )

    # constraining number of rows to insert if dictionary table
    for pattern in table_patterns:
        if (isinstance(pattern, MultipleCategoricalColumns)
                and pattern.get_probabilities() is None
                and number_of_rows_to_insert > len(pattern.get_values())):
            number_of_rows_to_insert = len(pattern.get_values())

    set_ids_start_values(
        table_patterns=table_patterns,
        table_name=dest_table_name,
        conn=conn,
    )

    if not generate_mix:
        mix_columns_names = []
    elif generate_mix and mix_columns_names is None:
        patterns_with_mix = get_patterns_with_mix(table_patterns)
        mix_columns_names = [pattern.get_column_name() for pattern in patterns_with_mix]
    else:
        pass

    execute_insertion(
        conn=conn,
        dest_table_name=dest_table_name,
        number_of_rows_to_insert=number_of_rows_to_insert,
        patterns=table_patterns,
        batch_size=batch_size,
        output_file_format=output_file_format,
        output_file_starting_postfix=output_file_starting_postfix,
        columns_order=columns_order,
        partition_columns=partition_columns,
        mix_columns_names=mix_columns_names,
    )
