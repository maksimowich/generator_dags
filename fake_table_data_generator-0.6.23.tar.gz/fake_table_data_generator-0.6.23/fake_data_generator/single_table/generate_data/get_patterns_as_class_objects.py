from typing import List, Union
from datetime import datetime
import decimal
from math import isnan

import pandas as pd

from .errors import NonExistentPatternType
from ...columns import *
from ...data_types import (
    DataType,
    Decimal,
    IntegerType,
    Date,
    Timestamp,
)


def get_correct_values_for_categorical_column(
        values: list,
        data_type: DataType,
) -> list:
    if isinstance(data_type, Decimal):
        precision = data_type.precision
        if precision == 0:
            conversion_function = lambda x: decimal.Decimal(int(x)) if not isnan(x) else None
        else:
            conversion_function = lambda x: decimal.Decimal(str(round(x, precision))) if not isnan(x) else None
    elif isinstance(data_type, IntegerType):
        conversion_function = int
    elif isinstance(data_type, Date):
        conversion_function = lambda x: datetime.strptime(x, "%Y-%m-%d").date() if isinstance(x, str) else None
    elif isinstance(data_type, Timestamp):
        conversion_function = lambda x: pd.to_datetime(x) if isinstance(x, str) else None
    else:
        conversion_function = lambda x: x

    return [conversion_function(value) if value is not None else None for value in values]


def get_correct_values_for_multiple_categorical_column(
        values: List,
        columns: List[Column],
) -> pd.DataFrame:
    columns_in_series = []
    for column_index in range(len(values[0])):
        correct_column_values = get_correct_values_for_categorical_column(
            values=[row[column_index] for row in values],
            data_type=columns[column_index].get_data_type(),
        )
        columns_in_series.append(pd.Series(correct_column_values, dtype=object))
    return pd.concat(columns_in_series, axis=1)


DETECTABLE_COLUMNS_CLASS_NAME_TO_CLASS = {
    cls.CLASS_NAME: cls
    for cls in NOT_DETECTABLE_BY_DEFAULT_COLUMNS + DETECTABLE_BY_DEFAULT_COLUMNS + DEPENDENT_DETECTABLE_COLUMNS
}

COMPREHENSIVE_COLUMN_CLASS_NAME_TO_CLASS = {
    cls.CLASS_NAME: cls
    for cls in COMPREHENSIVE_COLUMNS
}


def get_pattern_as_object(
        pattern_name: str,
        pattern_dict: dict,
        conn=None,
        mix_column_data_type: DataType = None,
) -> Pattern:
    pattern_type = pattern_dict.get('type') or "COLUMN"

    if pattern_dict.get('data_type') is not None:
        column_data_type = pattern_dict.get('data_type')
    else:
        column_data_type = mix_column_data_type

    if pattern_dict.get("null_ratio") is not None:
        pattern_null_ratio = pattern_dict.get("null_ratio")
    else:
        pattern_null_ratio = 0

    if pattern_type == Column.CLASS_NAME:
        return Column(
            column_name=pattern_name,
            data_type=column_data_type,
        )

    elif pattern_type == CustomGeneratorColumns.CLASS_NAME:
        columns = get_patterns_as_class_objects(pattern_dict.get("columns"))
        local_vars = {}
        exec(pattern_dict.get('generator_function'), {}, local_vars)
        generate_data_function = local_vars.get('generator_function', None)
        column_info = CustomGeneratorColumns(
            algorithm_name=pattern_name,
            columns=columns,
            generate_data_function=generate_data_function,
        )

    elif pattern_type == CategoricalColumn.CLASS_NAME:
        values = get_correct_values_for_categorical_column(
            values=pattern_dict.get('values'),
            data_type=column_data_type,
        )
        probabilities = pattern_dict.get('probabilities')
        column_info = CategoricalColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            values=values,
            probabilities=probabilities,
        )

    elif pattern_type == ContinuousColumn.CLASS_NAME:
        intervals = pattern_dict.get('intervals')
        probabilities = pattern_dict.get('probabilities')
        date_flag = pattern_dict.get('date_flag')
        string_datetime_format = pattern_dict.get('string_datetime_format')
        distribution_type = pattern_dict.get('distribution_type')
        distribution_params = pattern_dict.get('distribution_params')
        column_info = ContinuousColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            intervals=intervals,
            probabilities=probabilities,
            null_ratio=pattern_null_ratio,
            date_flag=date_flag,
            string_datetime_format=string_datetime_format,
            distribution_type=distribution_type,
            distribution_params=distribution_params,
        )

    elif pattern_type == StringFromRegexColumn.CLASS_NAME:
        common_regex = pattern_dict.get('common_regex')
        column_info = StringFromRegexColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            common_regex=common_regex,
            null_ratio=pattern_null_ratio,
        )

    elif pattern_type == TimestampWithTzColumn.CLASS_NAME:
        start = pattern_dict.get('start_timestamp')
        end = pattern_dict.get('end_timestamp')
        timezone = pattern_dict.get('tz_info')
        column_info = TimestampWithTzColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            start_timestamp=start,
            end_timestamp=end,
            timezone=timezone,
            null_ratio=pattern_null_ratio,
        )

    elif pattern_type == CurrentTimestampColumn.CLASS_NAME:
        timezone = pattern_dict.get("timezone")
        is_data_type_with_timezone = pattern_dict.get("is_data_type_with_timezone")
        string_datetime_format = pattern_dict.get("string_datetime_format")
        column_info = CurrentTimestampColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            timezone=timezone,
            is_data_type_with_timezone=is_data_type_with_timezone,
            string_datetime_format=string_datetime_format,
        )

    elif pattern_type in DETECTABLE_COLUMNS_CLASS_NAME_TO_CLASS:
        pattern_cls = DETECTABLE_COLUMNS_CLASS_NAME_TO_CLASS.get(pattern_type)
        format_ = pattern_dict.get('format')
        column_info = pattern_cls(
            column_name=pattern_name,
            data_type=column_data_type,
            null_ratio=pattern_null_ratio,
            format_=format_
        )

    elif pattern_type == IncrementalIDColumn.CLASS_NAME:
        pk_constraint = pattern_dict.get('pk_constraint')
        column_info = IncrementalIDColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            null_ratio=pattern_null_ratio,
            pk_constraint=pk_constraint
        )

    elif pattern_type == UuidColumn.CLASS_NAME:
        pk_constraint = pattern_dict.get('pk_constraint')
        column_info = UuidColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            null_ratio=pattern_null_ratio,
            pk_constraint=pk_constraint
        )

    elif pattern_type == ForeignKeyRandomSamplingColumn.CLASS_NAME:
        foreign_key_table_name = pattern_dict.get('foreign_key_table_name')
        foreign_key_column_name = pattern_dict.get('foreign_key_column_name')
        fk_constraint = pattern_dict.get('fk_constraint')
        column_info = ForeignKeyRandomSamplingColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            foreign_key_table_name=foreign_key_table_name,
            foreign_key_column_name=foreign_key_column_name,
            fk_constraint=fk_constraint,
            conn=conn,
        )

    elif pattern_type == ForeignKeyCategoricalSamplingColumn.CLASS_NAME:
        foreign_key_table_name = pattern_dict.get('foreign_key_table_name')
        foreign_key_column_name = pattern_dict.get('foreign_key_column_name')
        fk_constraint = pattern_dict.get('fk_constraint')
        values = pattern_dict.get('values')
        probabilities = pattern_dict.get('probabilities')
        column_info = ForeignKeyCategoricalSamplingColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            foreign_key_table_name=foreign_key_table_name,
            foreign_key_column_name=foreign_key_column_name,
            fk_constraint=fk_constraint,
            values=values,
            probabilities=probabilities,
        )

    elif pattern_type == MultipleCategoricalColumns.CLASS_NAME:
        columns = get_patterns_as_class_objects(pattern_dict.get("columns"))
        values = get_correct_values_for_multiple_categorical_column(
            values=pattern_dict.get('values'),
            columns=columns,
        )
        probabilities = pattern_dict.get('probabilities')
        column_info = MultipleCategoricalColumns(
            algorithm_name=pattern_name,
            columns=columns,
            values=values,
            probabilities=probabilities,
        )

    elif pattern_type == HistoricityColumns.CLASS_NAME:
        columns = get_patterns_as_class_objects(pattern_dict.get("columns"))
        key_columns_names = pattern_dict.get("key_columns_names")
        min_and_max_unix_timestamps = pattern_dict.get("min_and_max_unix_timestamps")
        time_intervals = pattern_dict.get("time_intervals")
        string_datetime_format = pattern_dict.get("string_datetime_format")
        column_info = HistoricityColumns(
            algorithm_name=pattern_name,
            columns=columns,
            key_columns_names=key_columns_names,
            min_and_max_unix_timestamps=min_and_max_unix_timestamps,
            time_intervals=time_intervals,
            string_datetime_format=string_datetime_format,
        )

    elif pattern_type in [cls.CLASS_NAME for cls in COMPREHENSIVE_COLUMNS]:
        cls = COMPREHENSIVE_COLUMN_CLASS_NAME_TO_CLASS.get(pattern_type)
        columns = get_patterns_as_class_objects(pattern_dict.get('columns'))
        column_info = cls(
            algorithm_name=pattern_name,
            columns=columns,
        )

    elif pattern_type == ConditionalContinuousColumn.CLASS_NAME:
        parameter_pattern_name = pattern_dict.get("parameter_pattern_name")

        distributions = {}
        for distribution_index, continuous_pattern_dict in pattern_dict.get("distributions").items():
            continuous_pattern_dict.update({"type": ContinuousColumn.CLASS_NAME, "data_type": column_data_type})
            continuous_pattern = get_pattern_as_object(
                pattern_name=None,
                pattern_dict=continuous_pattern_dict
            )
            distributions[int(distribution_index)] = continuous_pattern

        column_info = ConditionalContinuousColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            parameter_pattern_name=parameter_pattern_name,
            distributions=distributions,
            null_ratio=pattern_null_ratio,
        )

    elif pattern_type == MixedColumn.CLASS_NAME:
        column_info = MixedColumn(
            column_name=pattern_name,
            data_type=column_data_type,
            patterns=get_patterns_as_class_objects(
                table_patterns_dict=pattern_dict.get("patterns"),
                mix_column_data_type=column_data_type,
            ),
            probabilities=pattern_dict.get("probabilities"),
            null_ratio=pattern_dict.get("null_ratio"),
        )

    else:
        raise NonExistentPatternType(f'"{pattern_type}" pattern type does not exist')

    if isinstance(column_info, ColumnWithMix) and pattern_dict.get("mix"):
        pattern_dict["mix"]["type"] = MixedColumn.CLASS_NAME
        pattern_dict["mix"]["data_type"] = column_data_type
        pattern_dict["mix"]["null_ratio"] = pattern_null_ratio
        mixed_pattern = get_pattern_as_object(
            pattern_name="mix",
            pattern_dict=pattern_dict.get("mix"),
        )
        column_info.set_mix(mixed_pattern)

    return column_info


def get_patterns_as_class_objects(
        table_patterns_dict: dict,
        conn=None,
        mix_column_data_type: DataType = None,
) -> List[Pattern]:
    """
    Returns list of pattern objects from dictionary.
    """
    table_patterns = []
    for pattern_name, pattern_dict in table_patterns_dict.items():
        pattern = get_pattern_as_object(
            pattern_name=pattern_name,
            pattern_dict=pattern_dict,
            conn=conn,
            mix_column_data_type=mix_column_data_type,
        )
        table_patterns.append(pattern)
    return table_patterns
