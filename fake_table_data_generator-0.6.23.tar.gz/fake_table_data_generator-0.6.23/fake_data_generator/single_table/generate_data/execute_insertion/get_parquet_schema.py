from typing import List, Union

import pyarrow as pa

from ....errors import NotSupportedDataType
from ....data_types import (
    DataType,
    String, Varchar, Char,
    Int64, Int32, Int16, Int8,
    UInt64, UInt32, UInt16, UInt8,
    Decimal,
    Float64, Float32,
    Date, Timestamp,
    Boolean,
)
from ....columns import (
    Column,
    MultipleColumns,
)


TYPES_MAPPING = {
    Boolean: pa.bool_(),
    Timestamp: pa.timestamp('ns'),
    Date: pa.date32(),
    Float64: pa.float64(),
    Float32: pa.float32(),
    Int64: pa.int64(),
    Int32: pa.int32(),
    Int16: pa.int16(),
    Int8: pa.int8(),
    UInt64: pa.uint64(),
    UInt32: pa.uint32(),
    UInt16: pa.uint16(),
    UInt8: pa.uint8(),
    String: pa.string(),
    Varchar: pa.string(),
    Char: pa.string(),
}


def get_inferred_data_type(
        data_type: DataType,
):
    if isinstance(data_type, Decimal):
        return pa.decimal128(data_type.precision, data_type.scale)
    else:
        inferred_type = TYPES_MAPPING.get(data_type.__class__)
        if not inferred_type:
            raise NotSupportedDataType(
                message=f"{data_type} is not supported for parquet file format"
            )


def get_parquet_schema(
    patterns: List[Union[Column, MultipleColumns]],
    columns_order: List[str],
) -> pa.Schema:
    fields = []
    for pattern in patterns:
        if isinstance(pattern, MultipleColumns):
            for column in pattern.get_columns():
                fields.append(
                    (column.get_column_name(), get_inferred_data_type(column.get_data_type()))
                )
        else:
            fields.append(
                (pattern.get_column_name(), get_inferred_data_type(pattern.get_data_type()))
            )
    if columns_order is not None:
        specified_fields = sorted(
            [field for field in fields if field[0] in columns_order],
            key=lambda x: columns_order.index(x[0])
        )
        not_specified_fields = [field for field in fields if field[0] not in columns_order]
        fields = specified_fields + not_specified_fields
    return pa.schema(fields)
