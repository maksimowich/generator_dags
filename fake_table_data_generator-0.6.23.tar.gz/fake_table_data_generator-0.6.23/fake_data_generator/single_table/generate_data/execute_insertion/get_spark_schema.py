from typing import List, Union

from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    IntegerType,
    DateType,
    TimestampType,
    DecimalType,
    FloatType,
    DataType,
    BooleanType,
)
from ....data_types import (
    DataType as DataType_,
    String, Varchar, Char,
    IntegerType as IntegerType_,
    Decimal,
    Float64, Float32,
    Date, Timestamp,
    Boolean,
)
from ....columns import (
    Column,
    MultipleColumns,
)


def get_inferred_data_type(
        column_data_type: DataType_,
) -> DataType:
    """
    Get Spark data type from database data type.
    """
    if isinstance(column_data_type, (String, Varchar, Char)):
        return StringType()
    elif isinstance(column_data_type, IntegerType_):
        return IntegerType()
    elif isinstance(column_data_type, Decimal):
        precision = column_data_type.precision
        scale = column_data_type.scale
        return DecimalType(precision, scale)
    elif isinstance(column_data_type, (Float64, Float32)):
        return FloatType()
    elif isinstance(column_data_type, Timestamp):
        return TimestampType()
    elif isinstance(column_data_type, Date):
        return DateType()
    elif isinstance(column_data_type, Boolean):
        return BooleanType()
    else:
        return StringType()


def get_spark_schema(
        patterns: List[Union[Column, MultipleColumns]],
        columns_order: List[str],
) -> StructType:
    fields = []
    for pattern in patterns:
        if isinstance(pattern, MultipleColumns):
            for column in pattern.get_columns():
                fields.append(
                    StructField(
                        name=column.get_column_name(),
                        dataType=get_inferred_data_type(column.get_data_type()),
                    )
                )
        else:
            fields.append(
                StructField(
                    name=pattern.get_column_name(),
                    dataType=get_inferred_data_type(pattern.get_data_type()),
                )
            )
    if columns_order is not None:
        specified_fields = sorted(
            [field for field in fields if field.name in columns_order],
            key=lambda x: columns_order.index(x.name)
        )
        not_specified_fields = [field for field in fields if field.name not in columns_order]
        fields = specified_fields + not_specified_fields
    return StructType(fields)
