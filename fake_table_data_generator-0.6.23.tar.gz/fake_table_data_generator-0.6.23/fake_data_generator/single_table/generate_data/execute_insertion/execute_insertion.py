from typing import List, Optional, Union
import importlib

from loguru import logger

from ....columns import (
    Column,
    MultipleColumns,
    generate_data,
)


def execute_insertion(
        conn,
        dest_table_name: str,
        number_of_rows_to_insert: int,
        patterns: List[Union[Column, MultipleColumns]],
        batch_size: int,
        output_file_format: Optional[str],
        output_file_starting_postfix: int,
        columns_order: List[str],
        partition_columns: List[str],
        mix_columns_names: List[str],
) -> None:
    """
    Generates and saves data into database or files.
    """
    schema = None
    if conn.__class__.__name__ == 'SparkSession':
        get_spark_schema = importlib.import_module(
            "fake_data_generator.single_table.generate_data.execute_insertion.get_spark_schema"
        )
        schema = get_spark_schema.get_spark_schema(patterns, columns_order)

    elif output_file_format is not None and 'parquet' in output_file_format:
        get_parquet_schema = importlib.import_module(
            "fake_data_generator.single_table.generate_data.execute_insertion.get_parquet_schema"
        )
        schema = get_parquet_schema.get_parquet_schema(patterns, columns_order)

    number_of_rows_left_to_insert = number_of_rows_to_insert
    while number_of_rows_left_to_insert != 0:
        logger.info('-----------Start generating batch of fake data-----------')
        fake_data_in_df = generate_data(
            output_size=min(batch_size, number_of_rows_left_to_insert),
            patterns=patterns,
            mix_columns_names=mix_columns_names,
        )
        if columns_order is not None:
            additional_columns = [col for col in fake_data_in_df.columns if col not in columns_order]
            fake_data_in_df = fake_data_in_df[columns_order + additional_columns]

        logger.info(f'--------Finished generating batch of fake data-----------')

        logger.info(f'Start inserting generated fake data into {dest_table_name} table.')
        if conn.__class__.__name__ == 'Engine':
            if len(dest_table_name.split('.')) == 1:
                table_schema = None
                table_name = dest_table_name
            else:
                table_schema = dest_table_name.split('.')[0]
                table_name = dest_table_name.split('.')[1]
            fake_data_in_df.to_sql(
                con=conn,
                name=table_name,
                schema=table_schema,
                if_exists='append',
                index=False,
                method='multi',
            )

        elif conn.__class__.__name__ == 'SparkSession':
            fake_data_in_df_spark = conn.createDataFrame(fake_data_in_df, schema=schema).coalesce(1)
            if partition_columns:
                (fake_data_in_df_spark
                    .write
                    .partitionBy(*partition_columns)
                    .format('hive')
                    .mode('append')
                    .saveAsTable(dest_table_name))
            else:
                (fake_data_in_df_spark
                    .write
                    .format('hive')
                    .mode('append')
                    .saveAsTable(dest_table_name))

        elif output_file_format == 'csv':
            fake_data_in_df.to_csv(f'{dest_table_name}_{output_file_starting_postfix}.csv', index=False)
            output_file_starting_postfix += 1

        elif output_file_format is not None and 'parquet' in output_file_format:
            pyarrow = importlib.import_module("pyarrow")
            pq = importlib.import_module("pyarrow.parquet")
            table = pyarrow.Table.from_pandas(fake_data_in_df, schema=schema)
            pq.write_table(
                table,
                f'{dest_table_name}_{output_file_starting_postfix}.parquet',
                version=output_file_format.split('_')[-1],
            )
            output_file_starting_postfix += 1

        else:
            raise Exception()

        del fake_data_in_df

        number_of_rows_left_to_insert -= min(batch_size, number_of_rows_left_to_insert)
        logger.info(
            f'Insertion of fake data into {dest_table_name} was finished.\n'
            f'\tNumber of rows left to insert: {number_of_rows_left_to_insert}'
        )
