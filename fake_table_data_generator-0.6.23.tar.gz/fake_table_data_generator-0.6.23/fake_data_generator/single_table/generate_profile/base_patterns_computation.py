from typing import List, Optional, Tuple

from loguru import logger
import pandas as pd

from ...columns import (
    Column,
    CategoricalColumn,
    ContinuousColumn,
    StringFromRegexColumn,
    UuidColumn,
    TimestampWithTzColumn,
    DATE_FORMATS,
    does_satisfy_format,
)
from ...data_types import (
    DataType,
    UUID,
    Boolean,
    String, Varchar, Char,
    TimestampWithTZ,
)


def is_column_string_datetime(
        column_values: pd.Series,
) -> Tuple[bool, Optional[str]]:
    inferred_frmt = None
    for value in column_values:
        if not isinstance(value, str):
            return False, None
        for frmt in DATE_FORMATS:
            if does_satisfy_format(value, frmt):
                if inferred_frmt is None:
                    inferred_frmt = frmt
                    break
                if inferred_frmt == frmt:
                    break
                return False, None
        else:
            return False, None
    return True, inferred_frmt


def compute_base_pattern(
        column_values: pd.Series,
        column_name: str,
        column_data_type: DataType,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
) -> Column:
    if isinstance(column_data_type, UUID):
        logger.info(f'Column "{column_name}" — {column_data_type} {UuidColumn.CLASS_NAME}')
        return UuidColumn(
            column_name=column_name,
            data_type=column_data_type,
            null_ratio=0,
        )

    null_ratio = column_values.isnull().mean()
    is_categorical = (
        (column_values.nunique() in [0, 1])
        or (column_values.nunique() / column_values.count() < categorical_threshold)
        or isinstance(column_data_type, Boolean)
    )

    if is_categorical:
        logger.info(f'Column "{column_name}" — {column_data_type} {CategoricalColumn.CLASS_NAME}')
        values, probabilities = CategoricalColumn.get_values_and_probabilities(
            column_values=column_values,
        )
        return CategoricalColumn(
            column_name=column_name,
            data_type=column_data_type,
            values=values,
            probabilities=probabilities,
        )

    is_string_datetime, string_datetime_format = is_column_string_datetime(column_values=column_values.dropna())
    if isinstance(column_data_type, (String, Varchar, Char)) and not is_string_datetime:
        logger.info(f'Column "{column_name}" — {column_data_type} {StringFromRegexColumn.CLASS_NAME}')
        common_regex = StringFromRegexColumn.get_common_regex(
            strings=column_values.dropna(),
        )
        return StringFromRegexColumn(
            column_name=column_name,
            data_type=column_data_type,
            common_regex=common_regex,
            null_ratio=null_ratio,
        )

    if isinstance(column_data_type, TimestampWithTZ):
        logger.info(f'Column "{column_name}" — {column_data_type} {TimestampWithTzColumn.CLASS_NAME}')
        start, end, timezone = (
            TimestampWithTzColumn.get_start_end_timestamp_and_timezone(
                timestamps=column_values.dropna(),
            )
        )
        return TimestampWithTzColumn(
            column_name=column_name,
            data_type=column_data_type,
            start_timestamp=start,
            end_timestamp=end,
            timezone=timezone,
            null_ratio=null_ratio,
        )

    logger.info(f'Column "{column_name}" — {column_data_type} {ContinuousColumn.CLASS_NAME}')
    intervals, probabilities = ContinuousColumn.get_intervals_and_probabilities(
        column_values=column_values,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
    )
    return ContinuousColumn(
        column_name=column_name,
        data_type=column_data_type,
        intervals=intervals,
        probabilities=probabilities,
        null_ratio=null_ratio,
        string_datetime_format=string_datetime_format,
    )


def compute_base_patterns(
        columns: List[Column],
        table_data_df: pd.DataFrame,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
) -> List[Column]:
    base_patterns = []
    for column in columns:
        column_name = column.get_column_name()
        column_data_type = column.get_data_type()
        column_values = table_data_df[column_name]
        pattern = compute_base_pattern(
            column_values=column_values,
            column_name=column_name,
            column_data_type=column_data_type,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
        )
        base_patterns.append(pattern)
    return base_patterns
