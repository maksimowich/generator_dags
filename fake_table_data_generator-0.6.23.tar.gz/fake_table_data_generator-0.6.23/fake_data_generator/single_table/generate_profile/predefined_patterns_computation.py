from typing import List

import pandas as pd

from ...errors import NotSupportedComputationAlogrithm
from ...columns import (
    Pattern,
    Column,
    MultipleColumns,
    CategoricalColumn,
    ContinuousColumn,
    StringFromRegexColumn,
    UuidColumn,
    TimestampWithTzColumn,
    MultipleCategoricalColumns,
    HistoricityColumns,
    ConditionalContinuousColumn,
)
from ...columns.utils import get_pattern_by_name
from ...columns.ConditionalContinuousColumn import compute_conditional_continuous_pattern
from ...data_types import DataType
from ...databases import get_db

COMPUTATION_ORDER_TO_PATTERN_CLASSES = {
    0: (
        CategoricalColumn,
        ContinuousColumn,
        StringFromRegexColumn,
        UuidColumn,
        TimestampWithTzColumn,
        MultipleCategoricalColumns,
        HistoricityColumns,
    ),
    1: (
        ConditionalContinuousColumn,
    )
}


def compute_single_column_predefined_pattern(
        computation_algorithm: Column,
        column_name: str,
        column_data_type: DataType,
        column_values: pd.Series,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        computed_predefined_patterns: List[Pattern],
        table_data_df: pd.DataFrame,
) -> Column:
    column_values_null_ratio = column_values.isnull().mean()

    # if isinstance(computation_algorithm, CategoricalColumn):
    #     values, probabilities = CategoricalColumn.get_values_and_probabilities(
    #         column_values=column_values,
    #     )
    #     return CategoricalColumn(
    #         column_name=column_name,
    #         data_type=column_data_type,
    #         values=values,
    #         probabilities=probabilities,
    #     )

    if isinstance(computation_algorithm, ContinuousColumn):
        column_number_of_intervals = computation_algorithm.get_number_of_intervals() or number_of_intervals
        column_number_of_quantiles = computation_algorithm.number_of_quantiles or number_of_quantiles
        column_intervals_computation_method = computation_algorithm.intervals_computation_method or intervals_computation_method
        column_upper_percentile = computation_algorithm.upper_percentile or upper_percentile
        column_lower_percentile = computation_algorithm.lower_percentile or lower_percentile
        column_null_ratio = computation_algorithm.get_null_ratio() or column_values_null_ratio
        intervals, probabilities = ContinuousColumn.get_intervals_and_probabilities(
            column_values=column_values,
            number_of_intervals=column_number_of_intervals,
            number_of_quantiles=column_number_of_quantiles,
            intervals_computation_method=column_intervals_computation_method,
            upper_percentile=column_upper_percentile,
            lower_percentile=column_lower_percentile,
        )
        return ContinuousColumn(
            column_name=column_name,
            data_type=column_data_type,
            intervals=intervals,
            probabilities=probabilities,
            null_ratio=column_null_ratio,
        )

    # Not tested
    elif isinstance(computation_algorithm, UuidColumn):
        column_null_ratio = computation_algorithm.get_null_ratio() or column_values_null_ratio
        return UuidColumn(
            column_name=column_name,
            data_type=column_data_type,
            null_ratio=column_null_ratio,
        )

    # Not tested
    elif isinstance(computation_algorithm, TimestampWithTzColumn):
        column_null_ratio = computation_algorithm.get_null_ratio() or column_values_null_ratio
        start, end, timezone = TimestampWithTzColumn.get_start_end_timestamp_and_timezone(
            timestamps=column_values.dropna(),
        )
        return TimestampWithTzColumn(
            column_name=column_name,
            data_type=column_data_type,
            start_timestamp=start,
            end_timestamp=end,
            timezone=timezone,
            null_ratio=column_null_ratio,
        )

    elif isinstance(computation_algorithm, StringFromRegexColumn):
        common_regex = StringFromRegexColumn.get_common_regex(
            strings=column_values.dropna(),
        )
        column_null_ratio = computation_algorithm.get_null_ratio() or column_values_null_ratio
        return StringFromRegexColumn(
            column_name=column_name,
            data_type=column_data_type,
            common_regex=common_regex,
            null_ratio=column_null_ratio,
        )

    elif isinstance(computation_algorithm, ConditionalContinuousColumn):
        parameter_pattern = get_pattern_by_name(
            patterns=computed_predefined_patterns,
            pattern_name=computation_algorithm.parameter_pattern_name,
        )
        if not isinstance(parameter_pattern, MultipleCategoricalColumns):
            raise Exception(
                "Parameter pattern was not successfully computed for"
                f"{ConditionalContinuousColumn.CLASS_NAME} {column_name}. "
                "Check correctness of specified parameter columns` names."
            )
        return compute_conditional_continuous_pattern(
            conditional_continuous_predefined_pattern=computation_algorithm,
            parameter_pattern=parameter_pattern,
            table_data_df=table_data_df,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
        )

    else:
        raise NotSupportedComputationAlogrithm


def compute_multiple_columns_predefined_pattern(
        computation_algorithm: MultipleColumns,
        columns: List[Column],
        columns_values: pd.DataFrame,
        conn,
        table_name: str,
) -> MultipleColumns:
    if isinstance(computation_algorithm, MultipleCategoricalColumns):
        columns = computation_algorithm.get_columns()
        values, probabilities = MultipleCategoricalColumns.get_values_and_probabilities(
            values=columns_values,
            columns=columns,
            db=get_db(conn),
            conn_type=conn.__class__.__name__,
        )
        return MultipleCategoricalColumns(
            algorithm_name=computation_algorithm.get_algorithm_name(),
            columns=columns,
            values=values,
            probabilities=probabilities,
        )
    elif isinstance(computation_algorithm, HistoricityColumns):
        algorithm_name = computation_algorithm.get_algorithm_name()
        key_columns_names = computation_algorithm.get_key_columns_names()
        string_datetime_format = computation_algorithm.get_string_datetime_format()

        min_and_max_unix_timestamps = computation_algorithm.compute_min_and_max_unix_timestamps(
            conn=conn,
            table_name=table_name,
        )
        time_intervals = computation_algorithm.compute_time_intervals(
            conn=conn,
            table_name=table_name,
        )
        return HistoricityColumns(
            algorithm_name=algorithm_name,
            columns=columns,
            key_columns_names=key_columns_names,
            min_and_max_unix_timestamps=min_and_max_unix_timestamps,
            time_intervals=time_intervals,
            string_datetime_format=string_datetime_format,
        )
    else:
        raise NotSupportedComputationAlogrithm


def compute_predefined_patterns(
        predefined_patterns: List[Pattern],
        table_data_df: pd.DataFrame,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        conn,
        table_name,
) -> List[Pattern]:
    computed_predefined_patterns: List[Pattern] = []

    for computation_order_classes in COMPUTATION_ORDER_TO_PATTERN_CLASSES.values():
        for predefined_pattern in predefined_patterns:

            if not isinstance(predefined_pattern, computation_order_classes):
                continue

            if isinstance(predefined_pattern, Column):
                column_name = predefined_pattern.get_column_name()
                column_data_type = predefined_pattern.get_data_type()
                column_values = table_data_df[column_name]
                pattern = compute_single_column_predefined_pattern(
                    computation_algorithm=predefined_pattern,
                    column_name=column_name,
                    column_data_type=column_data_type,
                    column_values=column_values,
                    number_of_intervals=number_of_intervals,
                    number_of_quantiles=number_of_quantiles,
                    intervals_computation_method=intervals_computation_method,
                    upper_percentile=upper_percentile,
                    lower_percentile=lower_percentile,
                    computed_predefined_patterns=computed_predefined_patterns,
                    table_data_df=table_data_df,
                )

            else:
                predefined_pattern_columns_names = predefined_pattern.get_columns_names()
                pattern = compute_multiple_columns_predefined_pattern(
                    computation_algorithm=predefined_pattern,
                    columns=predefined_pattern.get_columns(),
                    columns_values=table_data_df[predefined_pattern_columns_names],
                    conn=conn,
                    table_name=table_name,
                )

            computed_predefined_patterns.append(pattern)

    return computed_predefined_patterns
