from typing import List, Type, Tuple, Optional, Dict
from collections import defaultdict

from loguru import logger
import pandas as pd

from ...data_types import DataType
from .detectable_patterns_computation import compute_distribution
from ...columns import (
    Column,
    AbstractDependentDetectableColumn,
    DEPENDENT_DETECTABLE_COLUMNS,
)


def detect_dependent_column_class(
    dependent_detectable_class: Type[AbstractDependentDetectableColumn],
    data_type: DataType,
    values: pd.Series,
    values_of_other_columns: pd.DataFrame,
) -> Tuple[bool, Optional[Dict]]:
    vales_without_null = values.dropna()
    if not isinstance(data_type, dependent_detectable_class.types):
        return False, None
    else:
        allowable_dismatches = int(len(vales_without_null) * (1 - dependent_detectable_class.RECOGNITION_THRESHOLD))
        dismatches = 0
        frmts_cnts = defaultdict(int)
        for index, value in vales_without_null.items():
            does_match, frmt = dependent_detectable_class.does_match_class(
                value=value,
                values_of_other_columns=values_of_other_columns.loc[index].to_dict()
            )
            dismatches += not does_match
            if does_match and frmt is not None:
                frmts_cnts[frmt] += 1
            if dismatches > allowable_dismatches:
                break
        else:
            if len(frmts_cnts) == 0:
                return True, None
            else:
                return True, compute_distribution(frmts_cnts)
    return False, None


def compute_dependent_patterns(
    columns: List[Column],
    table_data_df: pd.DataFrame,
    detected_patterns: List[Column],
) -> List[AbstractDependentDetectableColumn]:
    if len(columns) == 0:
        return []
    detected_columns_indexes = []
    dependent_patterns = []
    for dependent_detectable_class in DEPENDENT_DETECTABLE_COLUMNS:
        dependencies_detected_columns = [
            computed_pattern for computed_pattern in detected_patterns
            if isinstance(computed_pattern, dependent_detectable_class.DEPENDENCIES_CLASSES)
        ]

        continue_flg = False
        for dependency_class in dependent_detectable_class.DEPENDENCIES_CLASSES:
            count_instances = sum(isinstance(column, dependency_class) for column in dependencies_detected_columns)
            if count_instances != 1:
                continue_flg = True
                break
        if continue_flg:
            continue

        dependencies_detected_columns_mapping = {
            column.get_column_name(): column.CLASS_NAME for column in dependencies_detected_columns
        }
        values_of_other_columns = (table_data_df[dependencies_detected_columns_mapping.keys()]
                                   .rename(columns=dependencies_detected_columns_mapping))
        for index, column in enumerate(columns):
            if index in detected_columns_indexes:
                continue
            column_name = column.get_column_name()
            column_data_type = column.get_data_type()
            column_values = table_data_df[column_name]
            does_match, frmts_distribution = detect_dependent_column_class(
                dependent_detectable_class=dependent_detectable_class,
                data_type=column_data_type,
                values=column_values,
                values_of_other_columns=values_of_other_columns,
            )
            if does_match:
                logger.info(f'Column "{column_name}" — {column.get_data_type()} {dependent_detectable_class.CLASS_NAME}')
                dependent_detectable_pattern = dependent_detectable_class(
                    column_name=column_name,
                    data_type=column.get_data_type(),
                    null_ratio=column_values.isnull().mean(),
                    format_=frmts_distribution,
                )
                detected_columns_indexes.append(index)
                dependent_patterns.append(dependent_detectable_pattern)
                break
    return dependent_patterns
