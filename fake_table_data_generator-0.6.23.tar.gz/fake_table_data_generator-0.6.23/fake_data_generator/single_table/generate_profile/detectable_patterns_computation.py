from typing import Dict, List, Optional, Tuple, Type, Union
from collections import defaultdict

from loguru import logger
import pandas as pd

from ...columns import (
    Column,
    ColumnWithMix,
    CategoricalColumn,
    UuidColumn,
    MixedColumn,
    AbstractDetectableColumn,
    DETECTABLE_BY_DEFAULT_COLUMNS,
)
from ...data_types import DataType, UUID
from .base_patterns_computation import compute_base_pattern


def compute_distribution(
        value_to_cnt: Dict[str, int]
) -> Dict[str, float]:
    total_count = sum(value_to_cnt.values())
    return {
        key: count / total_count
        for key, count in value_to_cnt.items()
    }


def _construct_mix_pattern(
        cls_frmt_to_cnt: Dict[Type[AbstractDetectableColumn], Dict[Union[str, None], int]],
        base_pattern_values: List,
        data_type: DataType,
        total_cnt_of_not_null_values: int,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
) -> MixedColumn:
    patterns = []
    probabilities = []

    for cls, frmt_to_cnt in cls_frmt_to_cnt.items():
        pattern = cls(
            column_name=None,
            data_type=None,
            null_ratio=None,
            format_=compute_distribution(
                value_to_cnt=frmt_to_cnt
            ) if None not in frmt_to_cnt else None,
        )
        patterns.append(pattern)
        probability = sum(frmt_to_cnt.values()) / total_cnt_of_not_null_values
        probabilities.append(probability)

    if len(base_pattern_values) > 0:
        base_pattern = compute_base_pattern(
            column_values=pd.Series(base_pattern_values, dtype=object),
            column_name=None,
            column_data_type=data_type,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
        )
        patterns.append(base_pattern)
        base_pattern_probability = len(base_pattern_values) / total_cnt_of_not_null_values
        probabilities.append(base_pattern_probability)

    return MixedColumn(
        column_name=None,
        data_type=data_type,
        patterns=patterns,
        probabilities=probabilities,
    )


def _get_cls_frmt_to_cnt__and__base_pattern_values(
    vales_without_null: pd.Series,
    data_type: DataType,
    classes_to_detect: List[Type[AbstractDetectableColumn]],
) -> Tuple[Dict, List]:
    base_pattern_values = []
    cls_frmt_to_cnt = defaultdict(lambda: defaultdict(int))
    for value in vales_without_null:
        for cls in [cls for cls in classes_to_detect if isinstance(data_type, cls.types)]:
            does_match, frmt = cls.does_match_class(value)
            if does_match:
                cls_frmt_to_cnt[cls][frmt] += 1
                break
        else:
            base_pattern_values.append(value)
    return cls_frmt_to_cnt, base_pattern_values


def _try_to_get_detectable_pattern(
        cls_frmt_to_cnt: Dict,
        classes_to_detect: List[Type[AbstractDetectableColumn]],
        base_pattern_values: List,
        total_cnt_of_not_null_values: int,
        column_name: str,
        data_type: DataType,
        null_ratio: float,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
        compute_mix: bool,
) -> Optional[AbstractDetectableColumn]:
    for cls in classes_to_detect:
        if cls in cls_frmt_to_cnt:
            cls_matching_ratio = sum(cnt for _, cnt in cls_frmt_to_cnt[cls].items()) / total_cnt_of_not_null_values
            if cls_matching_ratio >= cls.RECOGNITION_THRESHOLD:
                if compute_mix:
                    mix_pattern = _construct_mix_pattern(
                        cls_frmt_to_cnt=cls_frmt_to_cnt,
                        base_pattern_values=base_pattern_values,
                        data_type=data_type,
                        total_cnt_of_not_null_values=total_cnt_of_not_null_values,
                        number_of_intervals=number_of_intervals,
                        number_of_quantiles=number_of_quantiles,
                        intervals_computation_method=intervals_computation_method,
                        upper_percentile=upper_percentile,
                        lower_percentile=lower_percentile,
                        categorical_threshold=categorical_threshold,
                    )
                else:
                    mix_pattern = None
                logger.info(f'Column "{column_name}" — {data_type} {cls.CLASS_NAME}')
                return cls(
                    column_name=column_name,
                    data_type=data_type,
                    null_ratio=null_ratio,
                    format_=compute_distribution(
                        cls_frmt_to_cnt[cls]
                    ) if None not in cls_frmt_to_cnt[cls] else None,
                    mix=mix_pattern,
                )


def _get_base_pattern(
        cls_frmt_to_cnt: Dict,
        values: pd.Series,
        base_pattern_values: List,
        total_cnt_of_not_null_values: int,
        column_name: str,
        data_type: DataType,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
        compute_mix: bool,
) -> Column:
    base_pattern = compute_base_pattern(
        column_values=values,
        column_name=column_name,
        column_data_type=data_type,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
        categorical_threshold=categorical_threshold,
    )
    if compute_mix:
        mix_pattern = _construct_mix_pattern(
            cls_frmt_to_cnt=cls_frmt_to_cnt,
            base_pattern_values=base_pattern_values,
            data_type=data_type,
            total_cnt_of_not_null_values=total_cnt_of_not_null_values,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
        )
        base_pattern.set_mix(mix_pattern)
    return base_pattern


def _try_to_get_pattern(
        column_values: pd.Series,
        column_name: str,
        column_data_type: DataType,
        extra_detectable_classes: List[Type[AbstractDetectableColumn]],
        compute_base: bool,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
        compute_mix: bool,
        cached_results: Dict[str, Tuple],
) -> Optional[ColumnWithMix]:
    if isinstance(column_data_type, UUID):
        logger.info(f'Column "{column_name}" — {column_data_type} {UuidColumn.CLASS_NAME}')
        return UuidColumn(
            column_name=column_name,
            data_type=column_data_type,
            null_ratio=0,
        )

    null_ratio = column_values.isnull().mean()
    if null_ratio == 1.0 or column_values.count() == 0:
        logger.info(f'Column "{column_name}" — {column_data_type} {CategoricalColumn.CLASS_NAME}')
        return CategoricalColumn(
            column_name=column_name,
            data_type=column_data_type,
            values=[None],
            probabilities=[1.0]
        )

    classes_to_detect = (extra_detectable_classes or []) + DETECTABLE_BY_DEFAULT_COLUMNS
    vales_without_null = column_values.dropna()

    if column_name not in cached_results:
        cls_frmt_to_cnt, base_pattern_values = _get_cls_frmt_to_cnt__and__base_pattern_values(
            vales_without_null=vales_without_null,
            data_type=column_data_type,
            classes_to_detect=classes_to_detect,
        )
        cached_results[column_name] = cls_frmt_to_cnt, base_pattern_values
    else:
        cls_frmt_to_cnt, base_pattern_values = cached_results.get(column_name)

    if not compute_base:
        detected_pattern = _try_to_get_detectable_pattern(
            cls_frmt_to_cnt=cls_frmt_to_cnt,
            classes_to_detect=classes_to_detect,
            base_pattern_values=base_pattern_values,
            total_cnt_of_not_null_values=len(vales_without_null),
            column_name=column_name,
            data_type=column_data_type,
            null_ratio=null_ratio,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
            compute_mix=compute_mix,
        )
        return detected_pattern

    else:
        base_pattern = _get_base_pattern(
            cls_frmt_to_cnt=cls_frmt_to_cnt,
            values=column_values,
            base_pattern_values=base_pattern_values,
            total_cnt_of_not_null_values=len(vales_without_null),
            column_name=column_name,
            data_type=column_data_type,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
            compute_mix=compute_mix,
        )
        return base_pattern


def compute_patterns(
        columns: List[Column],
        table_data_df: pd.DataFrame,
        extra_detectable_classes: List[Type[AbstractDetectableColumn]],
        compute_base: bool,
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        upper_percentile: int,
        lower_percentile: int,
        categorical_threshold: float,
        compute_mix: bool,
        cached_results: Dict[str, Tuple],
) -> List[ColumnWithMix]:
    patterns = []
    for column in columns:
        column_name = column.get_column_name()
        column_data_type = column.get_data_type()
        column_values = table_data_df[column_name]
        pattern = _try_to_get_pattern(
            column_values=column_values,
            column_name=column_name,
            column_data_type=column_data_type,
            extra_detectable_classes=extra_detectable_classes,
            compute_base=compute_base,
            number_of_intervals=number_of_intervals,
            number_of_quantiles=number_of_quantiles,
            intervals_computation_method=intervals_computation_method,
            upper_percentile=upper_percentile,
            lower_percentile=lower_percentile,
            categorical_threshold=categorical_threshold,
            compute_mix=compute_mix,
            cached_results=cached_results,
        )
        if pattern:
            patterns.append(pattern)
    return patterns
