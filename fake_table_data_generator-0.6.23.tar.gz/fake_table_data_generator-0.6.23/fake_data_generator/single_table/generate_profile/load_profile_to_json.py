from typing import Dict
import json

import pandas as pd

from ...data_types import DataType


def load_profile_to_json(
        output_table_profile_path: str,
        table_profile_in_dict: Dict,
):
    def _to_obj_to_str(obj):
        if isinstance(obj, DataType):
            return str(obj)
        elif pd.isna(obj):
            return None
        else:
            return obj

    with open(output_table_profile_path, 'w', encoding='utf-8') as file:
        json.dump(
            obj=table_profile_in_dict,
            fp=file,
            ensure_ascii=False,
            default=_to_obj_to_str,
        )
