from typing import Dict

import pandas as pd

from ...columns import Column, MultipleCategoricalColumns
from ...data_types import DataType


def compute_dictionary_pattern(
    table_data_df: pd.DataFrame,
    dictionary_id_column: Column,
    column_name_to_data_type: Dict[str, DataType]
):
    values, _ = MultipleCategoricalColumns.get_values_and_probabilities(
        values=table_data_df,
    )
    if dictionary_id_column:
        dictionary_columns = [
            Column(column_name, column_data_type)
            for column_name, column_data_type in column_name_to_data_type.items()
            if column_name != dictionary_id_column.get_column_name()
        ]
        dictionary_id_column_index = table_data_df.columns.get_loc(dictionary_id_column.get_column_name())
        old_ids = [row[dictionary_id_column_index] for _, row in values.iterrows()]
        new_ids = dictionary_id_column.generate_data(len(values))
        values.drop(values.columns[dictionary_id_column_index], axis=1, inplace=True)
        old_id_to_new_id = {old_id: new_id for old_id, new_id in zip(old_ids, new_ids)}
    else:
        dictionary_columns = [
            Column(column_name, column_data_type)
            for column_name, column_data_type in column_name_to_data_type.items()
        ]
        old_id_to_new_id = None

    dictionary_pattern = MultipleCategoricalColumns(
        algorithm_name='_dictionary_columns',
        columns=dictionary_columns,
        values=values,
    )
    dictionary_pattern.old_id_to_new_id = old_id_to_new_id

    return dictionary_pattern
