from typing import Dict, List, Type

import pandas as pd

from ...columns import (
    Column,
    Pattern,
    AbstractDetectableColumn,
    DateOfBirthColumn,
)
from ...data_types import DataType
from .detectable_patterns_computation import compute_patterns
from .dependent_patterns_computation import compute_dependent_patterns
from .comprehensive_patterns_computation import compute_comprehensive_patterns


def exclude_patterns(
        patterns_from_which_to_exclude: List[Column],
        excludable_patterns: List[Column],
) -> None:
    for excludable_pattern in excludable_patterns:
        excludable_pattern_column_name = excludable_pattern.get_column_name()
        for i, pattern in enumerate(patterns_from_which_to_exclude):
            if pattern.get_column_name() == excludable_pattern_column_name:
                del patterns_from_which_to_exclude[i]
                break


def ensure_birth_column(
        detected_patterns: List[AbstractDetectableColumn],
        table_data_df: pd.DataFrame,
):
    min_dttm = None
    for detected_pattern in detected_patterns:
        if isinstance(detected_pattern, DateOfBirthColumn):
            values = table_data_df[detected_pattern.get_column_name()].dropna()
            column_min_dttm = DateOfBirthColumn.get_min_dttm(values)
            if min_dttm is None or column_min_dttm < min_dttm:
                min_dttm = column_min_dttm
            else:
                detected_patterns.remove(detected_pattern)


def compute_bate_and_detectable_patterns(
    table_data_df: pd.DataFrame,
    column_name_to_data_type: Dict[str, DataType],
    number_of_intervals: int,
    number_of_quantiles: int,
    intervals_computation_method: str,
    categorical_threshold: float,
    extra_detectable_classes: List[Type[AbstractDetectableColumn]],
    compute_mix: bool,
    upper_percentile: int,
    lower_percentile: int,
):
    computed_patterns: List[Pattern] = []
    computable_columns: List[Column] = [
        Column(column_name, column_data_type)
        for column_name, column_data_type in column_name_to_data_type.items()
    ]

    cached_results = {}
    detected_patterns = compute_patterns(
        columns=computable_columns,
        table_data_df=table_data_df,
        extra_detectable_classes=extra_detectable_classes,
        compute_base=False,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
        categorical_threshold=categorical_threshold,
        compute_mix=compute_mix,
        cached_results=cached_results,
    )
    ensure_birth_column(detected_patterns, table_data_df)
    exclude_patterns(computable_columns, detected_patterns)
    computed_patterns.extend(detected_patterns)

    dependent_patterns = compute_dependent_patterns(
        columns=computable_columns,
        table_data_df=table_data_df,
        detected_patterns=detected_patterns,
    )
    exclude_patterns(computable_columns, dependent_patterns)
    computed_patterns.extend(dependent_patterns)

    base_patterns = compute_patterns(
        columns=computable_columns,
        table_data_df=table_data_df,
        extra_detectable_classes=extra_detectable_classes,
        compute_base=True,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
        categorical_threshold=categorical_threshold,
        compute_mix=compute_mix,
        cached_results=cached_results,
    )
    del cached_results
    exclude_patterns(computable_columns, base_patterns)
    computed_patterns.extend(base_patterns)

    comprehensive_patterns, indexes_to_delete = compute_comprehensive_patterns(
        computed_patterns=computed_patterns,
    )
    computed_patterns = [
        column for index, column in enumerate(computed_patterns)
        if index not in indexes_to_delete
    ]
    computed_patterns.extend(comprehensive_patterns)

    return computed_patterns
