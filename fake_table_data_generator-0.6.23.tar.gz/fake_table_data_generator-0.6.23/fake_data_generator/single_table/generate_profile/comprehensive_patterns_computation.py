from typing import List, Tuple, Type

from ...columns import (
    Column,
    AbstractComprehensiveColumns,
    AbstractDetectableColumn,
    COMPREHENSIVE_COLUMNS,
)


def check_for_repeating_patterns(
    comprehensive_cls_single_columns: List[Tuple[Type[AbstractComprehensiveColumns], List[Column]]],
) -> None:
    repeating_columns: List[Tuple[Type[AbstractDetectableColumn], List[Column]]] = []
    for comprehensive_cls, single_columns in comprehensive_cls_single_columns:
        for class_to_check in comprehensive_cls.SINGLE_COLUMN_CLASSES:
            class_columns = [column for column in single_columns if isinstance(column, class_to_check)]
            if len(class_columns) > 1:
                repeating_columns.append((class_to_check, class_columns))
    if len(repeating_columns) > 0:
        err_msg = 'more than 1 patterns of the same type relating to comprehensive column were found.\n'
        for cls, columns in repeating_columns:
            err_msg += f'\t*) {",".join([column.get_column_name() for column in columns])} columns are all of {cls.CLASS_NAME} type.\n'
        err_msg += 'Resolve conflicts by explicitly defining patterns for the columns above.'
        raise Exception(err_msg)


def compute_comprehensive_patterns(
        computed_patterns: List[Column],
) -> Tuple[List[AbstractComprehensiveColumns], List[int]]:
    comprehensive_patterns = []
    indexes_to_delete = []

    comprehensive_cls_single_columns = []
    for comprehensive_cls in COMPREHENSIVE_COLUMNS:
        single_columns = []
        for index, column in enumerate(computed_patterns):
            if isinstance(column, comprehensive_cls.SINGLE_COLUMN_CLASSES):
                single_columns.append(column)
                indexes_to_delete.append(index)
        if len(single_columns) == 0:
            continue
        comprehensive_cls_single_columns.append((comprehensive_cls, single_columns))

    check_for_repeating_patterns(comprehensive_cls_single_columns)

    for comprehensive_cls, single_columns in comprehensive_cls_single_columns:
        comprehensive_column = comprehensive_cls(
            algorithm_name=f'_{comprehensive_cls.CLASS_NAME.lower()}',
            columns=single_columns,
        )
        comprehensive_patterns.append(comprehensive_column)
    return comprehensive_patterns, indexes_to_delete
