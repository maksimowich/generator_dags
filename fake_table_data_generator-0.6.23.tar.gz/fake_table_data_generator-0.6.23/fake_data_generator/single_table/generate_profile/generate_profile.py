from typing import Dict, List, Optional, Union, Tuple, Type

from loguru import logger

from ...errors import ConflictingColumnsNames
from ...columns import *
from ...data_types import DataType
from ...databases import get_db, ClickHouse
from ...convert_df_to_correct_types import convert_df_to_correct_types
from ...db_functions import (
    get_table_description_data_in_df,
    get_table_data_in_df,
)
from ...columns.utils import (
    get_columns_names,
    get_id_pattern,
    get_defined_patterns,
)
from ...columns.get_predefined_patterns import get_predefined_patterns
from .predefined_patterns_computation import compute_predefined_patterns
from .base_and_detectable_patterns_computation import compute_bate_and_detectable_patterns
from .dictionary_pattern_computation import compute_dictionary_pattern
from .load_profile_to_json import load_profile_to_json


def set_data_type_for_predefined_patterns(
        predefined_patterns: List[Pattern],
        column_name_to_data_type: Dict[str, DataType]
) -> None:
    def set_data_type_for_predefined_column(predefined_pattern: Column):
        pattern_column_name = predefined_pattern.get_column_name()
        column_data_type = column_name_to_data_type.get(pattern_column_name)
        if column_data_type is None:
            raise ValueError
        if predefined_pattern.get_data_type() is None:
            predefined_pattern.set_data_type(column_data_type)
        del column_name_to_data_type[pattern_column_name]

    for predefined_pattern in predefined_patterns:
        if isinstance(predefined_pattern, Column):
            set_data_type_for_predefined_column(predefined_pattern)
        elif isinstance(predefined_pattern, MultipleColumns):
            for predefined_pattern_column in predefined_pattern.get_columns():
                set_data_type_for_predefined_column(predefined_pattern_column)
        else:
            raise TypeError


def get_result_table_patterns(
        conn,
        source_table_name: str,
        number_of_rows_from_which_create_patterns: int,
        columns_info: List[Union[Column, MultipleColumns]],
        columns_to_include: List[str],
        number_of_intervals: int,
        number_of_quantiles: int,
        intervals_computation_method: str,
        categorical_threshold: float,
        is_dict: bool,
        extra_detectable_classes: List[Type[AbstractDetectableColumn]],
        compute_mix: bool,
        upper_percentile: int = 100,
        lower_percentile: int = 0,
) -> Tuple[List[Pattern], Optional[List[str]]]:
    if source_table_name is None:
        return columns_info, None

    else:
        if columns_info is None:
            columns_info = []
        predefined_patterns: List[Pattern] = get_predefined_patterns(columns_info)
        defined_patterns: List[Pattern] = get_defined_patterns(columns_info)
        columns_to_exclude_from_select: List[str] = get_columns_names(defined_patterns)
        dictionary_id_column: Column = get_id_pattern(defined_patterns) if is_dict else None

        if len(columns_to_exclude_from_select) != len(set(columns_to_exclude_from_select)):
            raise ConflictingColumnsNames

        description_data_in_df = get_table_description_data_in_df(
            conn=conn,
            table_name=source_table_name,
        )

        if columns_to_include is not None:
            description_data_in_df = description_data_in_df[
                description_data_in_df['col_name'].isin(columns_to_include)
            ]
        columns_order = description_data_in_df['col_name'].tolist()
        description_data_in_df = description_data_in_df[
            ~description_data_in_df['col_name'].isin(columns_to_exclude_from_select)
        ]

        logger.info(f'Start making select-query from table {source_table_name}')
        table_data_df = get_table_data_in_df(
            conn=conn,
            table_name=source_table_name,
            columns_to_select=description_data_in_df['col_name'].tolist(),
            number_of_rows_to_select=number_of_rows_from_which_create_patterns,
        )
        logger.info(f'Number of rows fetched is {table_data_df.shape[0]}')

        db = get_db(conn)
        column_name_to_data_type: Dict[str, DataType] = {
            describe_data_row['col_name']: db.get_generator_data_type(describe_data_row)
            for _, describe_data_row in description_data_in_df.iterrows()
        }

        convert_df_to_correct_types(
            db=db,
            df=table_data_df,
            column_name_to_data_type=column_name_to_data_type,
            conn_type=conn.__class__.__name__,
        )

        set_data_type_for_predefined_patterns(
            predefined_patterns=predefined_patterns,
            column_name_to_data_type=column_name_to_data_type,
        )

        result_table_patterns: List[Pattern] = []
        result_table_patterns.extend(
            compute_predefined_patterns(
                predefined_patterns=predefined_patterns,
                table_data_df=table_data_df,
                number_of_intervals=number_of_intervals,
                number_of_quantiles=number_of_quantiles,
                intervals_computation_method=intervals_computation_method,
                upper_percentile=upper_percentile,
                lower_percentile=lower_percentile,
                conn=conn,
                table_name=source_table_name,
            )
        )

        if not is_dict:
            computed_patterns = compute_bate_and_detectable_patterns(
                table_data_df=table_data_df,
                column_name_to_data_type=column_name_to_data_type,
                number_of_intervals=number_of_intervals,
                number_of_quantiles=number_of_quantiles,
                intervals_computation_method=intervals_computation_method,
                categorical_threshold=categorical_threshold,
                extra_detectable_classes=extra_detectable_classes,
                compute_mix=compute_mix,
                upper_percentile=upper_percentile,
                lower_percentile=lower_percentile,
            )
            result_table_patterns.extend(computed_patterns)

        else:
            dictionary_pattern = compute_dictionary_pattern(
                table_data_df=table_data_df,
                dictionary_id_column=dictionary_id_column,
                column_name_to_data_type=column_name_to_data_type,
            )
            result_table_patterns.append(dictionary_pattern)

        result_table_patterns.extend(defined_patterns)
        return result_table_patterns, columns_order


def get_table_profile(
        conn=None,
        source_table_name: str = None,
        number_of_rows_from_which_create_patterns: int = None,
        columns_info: List[Union[Column, MultipleColumns]] = None,
        columns_to_include: List[str] = None,
        number_of_intervals: int = 5,
        number_of_quantiles: int = 10,
        intervals_computation_method: str = "length_based",
        categorical_threshold: float = 0.1,
        is_dict: bool = False,
        extra_detectable_classes: List[Type[AbstractDetectableColumn]] = None,
        compute_mix: bool = False,
        upper_percentile: int = 100,
        lower_percentile: int = 0,
) -> Dict[str, Union[Dict, List]]:
    if intervals_computation_method not in ("quantile_based", "length_based"):
        raise ValueError(
            "invalid value for 'intervals_computation_method' parameter, "
            "valid options are: quantile_based, length_based"
        )

    if categorical_threshold != 0.1:
        logger.warning(
            "parameter categorical_threshold is deprecated. "
            "For security reasons categorical_threshold will always equal to 0.1"
        )
        categorical_threshold = 0.1

    result_table_patterns, columns_order = get_result_table_patterns(
        conn=conn,
        source_table_name=source_table_name,
        number_of_rows_from_which_create_patterns=number_of_rows_from_which_create_patterns,
        columns_info=columns_info,
        columns_to_include=columns_to_include,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        categorical_threshold=categorical_threshold,
        is_dict=is_dict,
        extra_detectable_classes=extra_detectable_classes,
        compute_mix=compute_mix,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
    )

    table_profile = {}

    if conn and get_db(conn) is ClickHouse:
        table_details = ClickHouse.get_table_details(
            engine=conn,
            table_name=source_table_name,
        )
        table_profile['__table_details__'] = table_details

    if columns_order is not None:
        table_profile['__columns_order__'] = columns_order
    for pattern in result_table_patterns:
        table_profile.update(pattern.get_as_dict())
    return table_profile


def generate_table_profile(
        output_table_profile_path: str,
        conn=None,
        source_table_name: str = None,
        number_of_rows_from_which_create_patterns: int = None,
        columns_info: List[Union[Column, MultipleColumns]] = None,
        columns_to_include: List[str] = None,
        number_of_intervals: int = 5,
        number_of_quantiles: int = 10,
        intervals_computation_method: str = "length_based",
        categorical_threshold: float = 0.1,
        is_dict: bool = False,
        extra_detectable_classes: List[Type[AbstractDetectableColumn]] = None,
        compute_mix: bool = False,
        upper_percentile: int = 100,
        lower_percentile: int = 0,
) -> None:
    """
    Generates table profile in json-file format.

    Parameters
    ----------
    output_table_profile_path: string
        Output profile name (absolute or relative path).
        It is recommended to name profile similar to source table name.
        For example, if source table name is 'test.table_name'
        then output profile name should be something like this 'test.table_name.json'.

    conn: sqlalchemy Engine or SparkSession
        Connection to database.
        If it is None then only information specified in column_info parameter will be included in output table profile.

    source_table_name: string
        Name and schema of table from which profile will be taken.
        Can be None only if conn parameter is also None.

    number_of_rows_from_which_create_patterns: int
        Number of rows which will be randomly selected from source table.
        Patterns of data generation will be inferred from selected rows.

    columns_info: list of Column-like objects
        This parameter is used to specify generation algorithms for columns.

        If column is not present in source table but is present in column_info parameter
        then generation algorithm from column_info parameter will be written in output profile.

        If column is present both in source table and in column_info parameter
        then column_info parameter will have higher priority and generation algorithm from
        column_info parameter will be written in output profile.

        Examples:
            This is how list of column_info can be created:

            column_info = [
                StringFromRegexColumn(
                    column_name='foto',
                    data_type='varchar',
                    common_regex='[A-Z][A-Z][A-Z]-[0-9][0-9]',
                ),
                CategoricalColumn(
                    column_name='category',
                    data_type='varchar',
                    values=['SEGMENT_1', 'SEGMENT_2', 'SEGMENT_3'],
                    probabilities=[0.2, 0.6, 0.2],
                ),
                FioColumn(
                    column_name='fio',
                    data_type='varchar',
                ),
            ]

            Then this list should be passed to function as parameter.
            The information specified about generation algorithm will be written to table profile.

    columns_to_include: list of strings
        This parameter is used if only specific columns of source table should be included in output profile.

    intervals_computation_method: str
        This parameter is applicable to continuous pattern computation.
        Generator supports two interval computation methods:
        1) length_based — in this case intervals are equal in length;
        2) quantile_based — in this case intervals are computed based of quantiles.

    number_of_intervals: Optional[int]
        Only applicable if intervals_computation_method is set to 'length_based'.
        Column values will be divided into number_of_intervals intervals of equal length.

    number_of_quantiles: Optional[int]
        Only applicable if intervals_computation_method is set to 'quantile_based'.
        Specified number of quantiles will be computed for column values
        and intervals will be constructed based on these quantiles.

    categorical_threshold: float
        This parameter is used to determine whether column is categorical or not.
        If ratio of the number of unique values to the number of rows in the selection is less than
        categorical_threshold then column is considered categorical.

    is_dict: boolean
        If it is True then source table is considered dictionary
        and columns (which are not specified in columns_info parameter) will be treated as multiple categorical columns.

    extra_detectable_classes: List[Type[AbstractDetectableColumn]]
        Some detectable pattern classes are not detected by default,
        to detect such classes you should specify them in this parameter.

    compute_mix: bool
        Whether to calculate mix pattern for each column.

    upper_percentile: int
        Parameter is used to ignore outliers when computing intervals for Continuous pattern.
        All value greater than value of upper percentile will be ignored.

    lower_percentile: int
        Parameter is used to ignore outliers when computing intervals for Continuous pattern.
        All value less than value of lower percentile will be ignored.

    Returns
    --------
        Returns nothing.
    """
    if categorical_threshold != 0.1:
        logger.warning(
            "parameter categorical_threshold is deprecated. "
            "For security reasons categorical_threshold will always equal to 0.1"
        )
        categorical_threshold = 0.1

    table_profile_in_dict = get_table_profile(
        conn=conn,
        source_table_name=source_table_name,
        number_of_rows_from_which_create_patterns=number_of_rows_from_which_create_patterns,
        columns_info=columns_info,
        columns_to_include=columns_to_include,
        number_of_intervals=number_of_intervals,
        number_of_quantiles=number_of_quantiles,
        intervals_computation_method=intervals_computation_method,
        categorical_threshold=categorical_threshold,
        is_dict=is_dict,
        extra_detectable_classes=extra_detectable_classes,
        compute_mix=compute_mix,
        upper_percentile=upper_percentile,
        lower_percentile=lower_percentile,
    )

    load_profile_to_json(output_table_profile_path, table_profile_in_dict)
    logger.info(f'Profile was loaded into {output_table_profile_path}')
