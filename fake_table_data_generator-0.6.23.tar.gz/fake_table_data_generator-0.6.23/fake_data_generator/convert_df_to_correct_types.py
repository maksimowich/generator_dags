from typing import Dict, Type

import pandas as pd

from .databases import Database
from .data_types import DataType


def convert_df_to_correct_types(
        db: Type[Database],
        df: pd.DataFrame,
        column_name_to_data_type: Dict[str, DataType],
        conn_type: str,
) -> None:
    for column_name, column_values in df.items():
        df[column_name] = db.get_correct_column_values(
            column_values=column_values,
            column_data_type=column_name_to_data_type.get(column_name),
            conn_type=conn_type,
        )
