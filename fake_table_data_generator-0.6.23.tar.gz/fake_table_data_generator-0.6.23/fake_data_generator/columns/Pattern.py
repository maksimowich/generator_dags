from abc import ABCMeta, abstractmethod
from typing import Dict

from numpy.random import choice


class Pattern(metaclass=ABCMeta):
    @abstractmethod
    def get_pattern_name(self) -> str:
        pass

    @abstractmethod
    def get_as_dict(self) -> Dict[str, Dict]:
        pass

    def is_predefined_pattern(self):
        return False

    def generate_null(self) -> bool:
        if choice(a=[False, True], p=[self.null_ratio, self.not_null_ratio]):
            return False
        else:
            return True
