from typing import List

import pandas as pd

from .Column import Column
from .detectable_columns import AbstractSupportColumn
from .MultipleColumns import MultipleColumns
from .CustomGeneratorColumns import CustomGeneratorColumns
from .ConditionalContinuousColumn import ConditionalContinuousColumn


def generate_central_data(
        patterns,
        output_size: int,
        skip_custom_generator: bool,
        mix_columns_names: List[str],
) -> pd.DataFrame:
    generated_series_and_df = []
    generated_support_series = []
    for pattern in patterns:
        if isinstance(pattern, AbstractSupportColumn):
            generated_series = pattern.generate_fake_data(
                output_size=output_size,
                mix=pattern.get_column_name() in mix_columns_names,
            )
            generated_series_and_df.append(generated_series)
            generated_support_series.append(generated_series.rename(pattern.CLASS_NAME))
    support_data = pd.concat(generated_support_series, axis=1) if len(generated_support_series) > 0 else pd.DataFrame()

    for pattern in patterns:
        if isinstance(pattern, Column) and not isinstance(pattern, (ConditionalContinuousColumn, AbstractSupportColumn)):
            data = pattern.generate_fake_data(
                output_size=output_size,
                mix=pattern.get_column_name() in mix_columns_names,
            )
            generated_series_and_df.append(data)
        elif (isinstance(pattern, MultipleColumns) and not isinstance(pattern, CustomGeneratorColumns)
                or (not skip_custom_generator and isinstance(pattern, CustomGeneratorColumns))):
            data = pattern.generate_fake_data(output_size, support_data, mix_columns_names)
            generated_series_and_df.append(data)
    return pd.concat(generated_series_and_df, axis=1) if len(generated_series_and_df) > 0 else pd.DataFrame()
