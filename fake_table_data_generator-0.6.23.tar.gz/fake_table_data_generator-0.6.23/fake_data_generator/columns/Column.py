from typing import Dict, Union

import pandas as pd

from ..data_types import DataType
from ..get_obj_from_str import get_obj_from_str
from .Pattern import Pattern


class Column(Pattern):
    CLASS_NAME = "COLUMN"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
    ):
        self.column_name = column_name
        if isinstance(data_type, DataType):
            self.data_type = data_type
        elif isinstance(data_type, str):
            self.data_type = get_obj_from_str(data_type)
        else:
            self.data_type = None

    def get_pattern_name(self) -> str:
        return self.column_name

    def generate_data(
            self,
            output_size: int,
    ) -> pd.Series:
        return pd.Series([None] * output_size)

    def generate_fake_data(
            self,
            output_size: int,
            mix=False,
    ) -> pd.Series:
        generated_data_in_series = self.generate_data(output_size)
        generated_data_in_series.name = self.column_name
        return generated_data_in_series

    def get_column_name(self) -> str:
        return self.column_name

    def get_data_type(self) -> DataType:
        return self.data_type

    def set_data_type(
            self,
            data_type: DataType,
    ) -> None:
        self.data_type = data_type

    def get_as_dict(self) -> Dict[str, Dict]:
        res = {self.column_name: {"type": self.CLASS_NAME}}
        if self.data_type:
            res[self.column_name]["data_type"] = self.data_type
        return res
