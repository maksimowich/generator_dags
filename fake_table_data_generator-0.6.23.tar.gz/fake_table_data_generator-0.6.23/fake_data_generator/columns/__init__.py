from .Pattern import Pattern
from .Column import Column
from .ColumnWithMix import ColumnWithMix
from .CategoricalColumn import CategoricalColumn
from .ContinuousColumn import ContinuousColumn
from .ConditionalContinuousColumn import ConditionalContinuousColumn
from .StringFromRegexColumn import StringFromRegexColumn
from .MixedColumn import MixedColumn
from fake_data_generator.columns.id_columns.UuidColumn import UuidColumn
from .TimestampWithTzColumn import TimestampWithTzColumn

from .detectable_columns import *
from .indetectable_columns import *
from .id_columns import *
from .foreign_key_columns import *

from .MultipleColumns import MultipleColumns
from .CustomGeneratorColumns import CustomGeneratorColumns
from .HistoricityColumns import HistoricityColumns
from .MultipleCategoricalColumns import MultipleCategoricalColumns

from .detectable_columns.datetime_functions import DATE_FORMATS, does_satisfy_format

from .generate_data import generate_data, get_historicity_pattern

NOT_DETECTABLE_BY_DEFAULT_COLUMNS = [
    DateOfBirthColumn,
]

DETECTABLE_BY_DEFAULT_COLUMNS = [
    GenderColumn,
    EmailColumn,
    NameColumn,
    PatronymicColumn,
    SurnameColumn,
    FioColumn,
    PhoneColumn,
    INNColumn,
    SNILSColumn,
    OKVEDCodeColumn,
    IpAddressColumn,
    PassportDepartmentCodeColumn,
    PassportDepartmentNameColumn,
    PassportSeriesAndNumberColumn,
    OGRNColumn,
    BIKColumn,
    KPPColumn,
    PaymentPurposeColumn,
    GPBBalanceSheetAccountNumberColumn,
    AddressOneStringColumn,
    LegalEntitiesAbbColumn,
    LegalEntitiesFullColumn,
    EmbossNameAndSurnameColumn,
    GPBNumberCardsColumn,
    OKATOColumn,
    OKTMOColumn,
]

DEPENDENT_DETECTABLE_COLUMNS = [
    PassportDateOfIssueColumn,
]

COMPREHENSIVE_COLUMNS = [
    ClientColumns,
    INNAndKPPColumns,
    PassportColumns,
    LegalEntitiesAbbAndFullColumns,
    OKATOAndOKTMOColumns,
]

MULTIPLE_COLUMNS = [
    MultipleColumns,
    CustomGeneratorColumns,
    MultipleCategoricalColumns,
    HistoricityColumns,
]

MULTIPLE_COLUMNS_CLASS_NAMES = [
    cls.CLASS_NAME for cls in MULTIPLE_COLUMNS + COMPREHENSIVE_COLUMNS
]
