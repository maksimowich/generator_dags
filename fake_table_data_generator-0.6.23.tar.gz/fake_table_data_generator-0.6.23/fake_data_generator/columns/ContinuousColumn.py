from typing import (
    Callable,
    Dict,
    List,
    Tuple,
    Optional,
    Union
)
from datetime import datetime, date, timedelta
import decimal
import math
import random
import warnings

import numpy as np
import pandas as pd
from scipy.stats import gaussian_kde, truncnorm
from loguru import logger

from .detectable_columns.datetime_functions import DATE_FORMATS, does_satisfy_format
from .ColumnWithMix import ColumnWithMix
from .MixedColumn import MixedColumn
from ..data_types import (
    DataType,
    Decimal, Float64, Float32,
    IntegerType,
    Date, Timestamp, TimestampWithTZ,
    String, Varchar, Char,
)
from ..errors import NotSupportedInputDataTypeForContinuousColumn


def get_conversion_to_float_function(
        column_values: pd.Series,
) -> Callable:
    if any(isinstance(value, float) for value in column_values):
        return lambda x: x
    elif any(isinstance(value, int) for value in column_values):
        return int
    elif any(isinstance(value, str) for value in column_values):
        value = column_values.iloc[0]
        for frmt in DATE_FORMATS:
            if does_satisfy_format(value, frmt):
                def conversion_func(x):
                    dt = min(max(datetime.strptime(x, frmt), pd.Timestamp.min), pd.Timestamp.max)
                    return pd.to_datetime(dt).timestamp()
                return conversion_func
        raise NotSupportedInputDataTypeForContinuousColumn()
    elif any(type(value) is pd.Timestamp for value in column_values):
        return lambda x: x.timestamp()
    elif any(type(value) is date for value in column_values):
        return lambda x: pd.to_datetime(x).timestamp()
    else:
        raise NotSupportedInputDataTypeForContinuousColumn()


def get_conversion_from_float_function(
        data_type: DataType,
        date_flag: bool,
        string_datetime_format: str,
) -> Callable:
    if isinstance(data_type, Decimal) and data_type.scale is not None:
        scale = data_type.scale
        if scale == 0:
            return lambda x: decimal.Decimal(int(x)) if not math.isnan(x) else None
        else:
            return lambda x: decimal.Decimal(str(round(x, scale))) if not math.isnan(x) else None
    elif isinstance(data_type, (Decimal, Float64, Float32)):
        return lambda x: x
    elif isinstance(data_type, IntegerType):
        return int
    elif isinstance(data_type, (Date, Timestamp, TimestampWithTZ)):
        if date_flag or isinstance(data_type, Date):
            return lambda x: datetime.fromtimestamp(x).replace(hour=0, minute=0, second=0, microsecond=0)
        else:
            return lambda x: datetime.fromtimestamp(x)
    elif isinstance(data_type, (String, Varchar, Char)) and string_datetime_format is not None:
        epoch = datetime(1970, 1, 1)
        return lambda x: (epoch + timedelta(seconds=x)).strftime(string_datetime_format)
    else:
        raise NotSupportedInputDataTypeForContinuousColumn(
            message=f"{data_type} is not supported for continuous column",
        )


def generate_trunc_normal_values(
        left: Union[int, float],
        right: Union[int, float],
        mean: Union[int, float],
        std: Union[int, float],
) -> float:
    a, b = (left - mean) / std, (right - mean) / std
    return truncnorm.rvs(a, b, loc=mean, scale=std, size=1)[0]


class ContinuousColumn(ColumnWithMix):
    CLASS_NAME = "CONTINUOUS"
    AVAILABLE_DISTRIBUTION_TYPES = ["normal", "uniform"]

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            intervals: List[Tuple[float, float]] = None,
            probabilities: List[float] = None,
            null_ratio: float = 0,
            date_flag: bool = None,
            intervals_computation_method: str = None,
            number_of_intervals: int = None,
            number_of_quantiles: int = None,
            upper_percentile: int = None,
            lower_percentile: int = None,
            string_datetime_format: str = None,
            distribution_type: str = None,
            distribution_params: List[Tuple[Union[int, float], Union[int, float]]] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            mix=mix,
        )
        self.intervals = intervals
        self.probabilities = probabilities
        self.null_ratio = null_ratio
        self.date_flag = date_flag
        self.intervals_computation_method = intervals_computation_method
        self.number_of_intervals = number_of_intervals
        self.number_of_quantiles = number_of_quantiles
        self.upper_percentile = upper_percentile
        self.lower_percentile = lower_percentile
        self.string_datetime_format = string_datetime_format
        self.distribution_type = distribution_type if distribution_type is not None else "uniform"
        self.distribution_params = distribution_params
        if probabilities is not None:
            multiplier_for_probabilities = (1 - self.null_ratio) / sum(self.probabilities)
            self.norm_probabilities = list(map(
                lambda p: p * multiplier_for_probabilities,
                self.probabilities
            ))
        self.conversion_from_float_func = get_conversion_from_float_function(
            data_type=self.data_type,
            date_flag=date_flag,
            string_datetime_format=string_datetime_format,
        )
        if self.distribution_type not in ContinuousColumn.AVAILABLE_DISTRIBUTION_TYPES:
            raise ValueError("Incorrect distribution type\nCheck ContinuousColumn.AVAILABLE_DISTRIBUTION_TYPES for available options")
        
        if self.distribution_type != "uniform" and self.distribution_params is None:
            self.compute_default_distribution_params()
            warnings.warn("You choose non-default distribution, but didn't provide intervals means and stds.\nValues will generated with default parameters", UserWarning)
            
        elif self.distribution_type != "normal" and self.distribution_params is not None:
            warnings.warn("You provided means and stds for distribution but didn't pick normal type. \nIt will ignored and uniform generated instead", UserWarning)

    def generate_uniform_intervals(self, output_size: int) -> List:
        fake_sample = map(
                lambda interval_index: self.conversion_from_float_func(random.uniform(
                    self.intervals[interval_index - 1][0],
                    self.intervals[interval_index - 1][1]
                )) if interval_index != 0 else None,
                np.random.choice(
                    a=len([None] + self.intervals),
                    size=output_size,
                    p=[self.null_ratio] + self.norm_probabilities
                )
            )
        return fake_sample

    def compute_default_distribution_params(self):
        """
        Based on provided distribution type different default parameters will set

            Normal: mean = (a + b)/2, std = (a + b)/10
            ...
        """
        if self.distribution_type == "normal":
            self.distribution_params = [[
                (interval[1] + interval[0]) / 2,
                (interval[1] + interval[0]) / 10
            ] for interval in self.intervals]            

    def generate_normal_intervals(self, output_size: int) -> List:
        if len(self.distribution_params) == 1 and len(self.intervals) > 1:
                self.distribution_params = self.distribution_params = [[
                                                    self.distribution_params[0][0],
                                                    self.distribution_params[0][1]
                                            ] for _ in self.intervals]
                logger.info('-----------Using same set of parameters for all intervals-----------')
        fake_sample = map(
                lambda params_index: self.conversion_from_float_func(generate_trunc_normal_values(
                    self.intervals[params_index - 1][0],
                    self.intervals[params_index - 1][1],
                    self.distribution_params[params_index - 1][0],
                    self.distribution_params[params_index - 1][1]
                )) if params_index != 0 else None,
                np.random.choice(
                    a=len([None] + self.intervals),
                    size=output_size,
                    p=[self.null_ratio] + self.norm_probabilities
                )
            )
        return fake_sample

    def generate_data(self, output_size: int) -> pd.Series:
        if self.intervals is None or self.probabilities is None:
            return pd.Series([None] * output_size, dtype=object)
        if self.distribution_type == "uniform":
            fake_sample = self.generate_uniform_intervals(output_size)
        elif self.distribution_type == "normal":
            fake_sample = self.generate_normal_intervals(output_size)       
        return pd.Series(fake_sample, dtype=object)

    @staticmethod
    def get_intervals_and_probabilities(
            column_values: pd.Series,
            intervals_computation_method: str,
            number_of_intervals: Optional[int],
            number_of_quantiles: Optional[int],
            upper_percentile: int,
            lower_percentile: int,
    ) -> Tuple[
        List[Tuple[float, float]],
        List[float]
    ]:
        """
        Returns continuous distribution (intervals and their probabilities) for given values.
        Probability of interval is calculated as the proportion of values included in the interval.

        Parameters:
        -----------
        column_values: Series
            Values from which continuous distribution will be inferred.

        intervals_computation_method: str
            Function supports two interval computation methods:
            1) length_based — in this case intervals are equal in length;
            2) quantile_based — in this case intervals are computed based of quantiles.

        number_of_intervals: Optional[int]
            Only applicable if intervals_computation_method is set to 'length_based'.
            Values will be divided into number_of_intervals intervals of equal length.

        number_of_quantiles: Optional[int]
            Only applicable if intervals_computation_method is set to 'quantile_based'.
            Specified number of quantiles will be computed for values
            and intervals will be constructed based on these quantiles.

        upper_percentile: int
            Values greater than value of upper percentile will be ignored.

        lower_percentile: int
            Values less than value of lower percentile will be ignored.

        Returns:
        -----------
            Tuple containing two lists: first list — intervals, second list — probabilities.
        """
        if intervals_computation_method not in ("quantile_based", "length_based"):
            raise ValueError(
                "invalid value for 'intervals_computation_method' parameter, "
                "valid options are: quantile_based, length_based"
            )

        column_values_without_nulls = column_values.dropna()
        conversion_to_float_function = get_conversion_to_float_function(column_values_without_nulls)
        float_column_values_without_null = column_values_without_nulls.apply(conversion_to_float_function)

        upper_bound = np.percentile(float_column_values_without_null, upper_percentile)
        lower_bound = np.percentile(float_column_values_without_null, lower_percentile)

        if intervals_computation_method == "quantile_based":
            truncated_float_column_values_without_null = float_column_values_without_null[
                (float_column_values_without_null >= lower_bound) & (float_column_values_without_null <= upper_bound)
            ]
            out = pd.qcut(truncated_float_column_values_without_null, number_of_quantiles, duplicates='drop')
            interval_probs = (out.value_counts() / len(out))

            min_value = min(truncated_float_column_values_without_null)
            interval_and_prob = [
                ((max(interval.left, min_value), interval.right), p)
                for interval, p in interval_probs.items() if p != 0
            ]

            intervals = [i[0] for i in interval_and_prob]
            probs = [i[1] for i in interval_and_prob]

        else:
            counts, bin_edges = np.histogram(
                a=float_column_values_without_null,
                bins=number_of_intervals,
                density=False,
                range=(lower_bound, upper_bound),
            )

            intervals = [
                (bin_edges[i], bin_edges[i + 1])
                for i in range(len(bin_edges) - 1)
            ]

            non_normalized_probs = [
                counts[i] / len(float_column_values_without_null)
                for i in range(len(bin_edges) - 1)
            ]
            probs = [p * (1 / sum(non_normalized_probs)) for p in non_normalized_probs]

        return intervals, probs

    def get_intervals(self) -> List[Tuple[float, float]]:
        return self.intervals

    def get_probabilities(self) -> List[float]:
        return self.probabilities

    def get_number_of_intervals(self) -> int:
        return self.number_of_intervals

    def get_null_ratio(self) -> float:
        return self.null_ratio
    
    def get_distribution_type(self) -> str:
        return self.distribution_type

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'intervals': self.intervals,
            'probabilities': self.probabilities,
            'null_ratio': self.null_ratio,
            'distribution_type': self.distribution_type,
            'distribution_params': self.distribution_params
        })
        if self.date_flag is not None:
            super_dict[self.column_name].update({
                'date_flag': self.date_flag,
            })
        if self.string_datetime_format is not None:
            super_dict[self.column_name].update({
                'string_datetime_format': self.string_datetime_format,
            })
        self.set_mix_to_end(super_dict)
        return super_dict

    def is_predefined_pattern(self):
        return self.get_intervals() is None and self.get_probabilities() is None
