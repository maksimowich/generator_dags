from typing import (
    Dict,
    List,
    Tuple,
)
import datetime

import pandas as pd
import numpy as np

from .Column import Column
from .MultipleColumns import MultipleColumns
from ..convert_df_to_correct_types import convert_df_to_correct_types


class MultipleCategoricalColumns(MultipleColumns):
    CLASS_NAME = 'MULTIPLE_CATEGORICAL'

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
            values: pd.DataFrame = None,
            probabilities: List[float] = None,
    ):
        super().__init__(
            algorithm_name=algorithm_name,
            columns=columns,
        )
        self.values = values
        self.probabilities = probabilities
        self.current_index = None
        if values is not None and probabilities is not None:
            self.generate_data = self.generate_data_for_multiple_categorical_columns
        elif values is not None and probabilities is None:
            self.generate_data = self.generate_data_for_dictionary_columns
        else:
            self.generate_data = None
        self.generated_data_indexes = None

    @staticmethod
    def get_values_and_probabilities(
            values: pd.DataFrame,
            columns=None,
            db=None,
            conn_type=None,
    ) -> Tuple[pd.DataFrame, List[float]]:
        row_frequency = values.apply(tuple, axis=1).value_counts()
        probabilities = (row_frequency / len(values)).tolist()
        unique_rows = pd.DataFrame([
            pd.Series(row, dtype=object)
            for row in row_frequency.index
        ])
        if columns:
            unique_rows.columns = [column.get_column_name() for column in columns]
            convert_df_to_correct_types(
                db=db,
                df=unique_rows,
                column_name_to_data_type={
                    column.get_column_name(): column.get_data_type()
                    for column in columns
                },
                conn_type=conn_type,
            )
        return unique_rows, probabilities

    def generate_data_for_multiple_categorical_columns(
            self,
            output_size: int,
            generated_data: pd.DataFrame = None,
            mix_columns_names=None,
    ) -> pd.DataFrame:
        random_sample = np.random.choice(self.values.index, size=output_size, p=self.probabilities)
        self.generated_data_indexes = random_sample
        return self.values.loc[random_sample].reset_index(drop=True)

    def generate_data_for_dictionary_columns(
            self,
            output_size: int,
            generated_data: pd.DataFrame = None,
            mix_columns_names=None,
    ) -> pd.DataFrame:
        if self.current_index is None:
            self.current_index = 0
        data = self.values.loc[self.current_index:self.current_index + output_size - 1]
        self.current_index += output_size
        return data

    def get_values(self) -> pd.DataFrame:
        return self.values

    def get_probabilities(self) -> List[float]:
        return self.probabilities

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()

        values_corrected = []
        for _, row in self.values.iterrows():
            row_corrected = []
            for value in row:
                if type(value) in (datetime.date, pd.Timestamp, str):
                    row_corrected.append(str(value))
                elif (isinstance(value, float) and value.is_integer()) or isinstance(value, int):
                    row_corrected.append(int(value))
                else:
                    row_corrected.append(value)
            values_corrected.append(row_corrected)

        super_dict[self.algorithm_name].update({
            'values': values_corrected,
            'probabilities': self.probabilities,
        })

        if hasattr(self, 'old_id_to_new_id'):
            super_dict[self.algorithm_name].update({
                'id_mapping': self.old_id_to_new_id
            })

        return super_dict

    def is_predefined_pattern(self):
        return self.get_values() is None or self.get_probabilities() is None
