from typing import List, Optional, Tuple, Union

import pandas as pd

from .Column import Column
from .MultipleColumns import MultipleColumns
from .HistoricityColumns import HistoricityColumns
from .ConditionalContinuousColumn import generate_continuous_conditional_data
from .CustomGeneratorColumns import CustomGeneratorColumns
from .generate_central_data import generate_central_data


def get_historicity_pattern(
        patterns,
) -> Optional[HistoricityColumns]:
    for pattern in patterns:
        if isinstance(pattern, HistoricityColumns):
            return pattern


def get_key_patterns(
        patterns: List[Union[Column, MultipleColumns]],
        key_columns_names: List[str],
) -> List[Union[Column, MultipleColumns]]:
    key_patterns = []
    for pattern in patterns:
        if (isinstance(pattern, Column)
                and pattern.get_column_name() in key_columns_names):
            key_patterns.append(pattern)
        elif (isinstance(pattern, MultipleColumns)
                and set(pattern.get_columns_names()) & set(key_columns_names)):
            key_patterns.append(pattern)
    return key_patterns


def generate_custom_data(
        patterns,
        output_size: int,
        generated_data: pd.DataFrame,
) -> pd.DataFrame:
    generated_custom_df = []
    for pattern in patterns:
        if isinstance(pattern, CustomGeneratorColumns):
            data = pattern.generate_fake_data(output_size, generated_data, [])
            generated_custom_df.append(data)
    return pd.concat(generated_custom_df, axis=1) if len(generated_custom_df) > 0 \
        else pd.DataFrame()


def generate_data(
        output_size: int,
        patterns: List[Union[Column, MultipleColumns]],
        mix_columns_names: List[str],
) -> pd.DataFrame:
    """
    Generates and returns data of specified size.

    :param output_size: Number of rows to generate
    :param patterns: List of patterns
    :param mix_columns_names: List of columns` names for which mix data should be generated

    :return: Pandas DataFrame containing patterns` generated data

    """
    historicity_pattern = get_historicity_pattern(patterns)
    if historicity_pattern is not None:
        key_columns_names = historicity_pattern.get_key_columns_names()
        key_patterns = get_key_patterns(patterns, key_columns_names) if key_columns_names else None
        generated_key_and_historicity_data = historicity_pattern.generate_data(
            output_size=output_size,
            generated_data=None,
            key_patterns=key_patterns,
        )
        patterns = [
            pattern for pattern in patterns
            if pattern not in (key_patterns or []) + [historicity_pattern]
        ]
    else:
        generated_key_and_historicity_data = pd.DataFrame()

    generated_central_data = generate_central_data(
        patterns=patterns,
        output_size=output_size,
        skip_custom_generator=True,
        mix_columns_names=mix_columns_names,
    )

    generated_continuous_conditional_data = generate_continuous_conditional_data(
        patterns=patterns,
        output_size=output_size,
    )

    generated_data = pd.concat([
        generated_key_and_historicity_data,
        generated_central_data,
        generated_continuous_conditional_data,
    ], axis=1)

    generated_custom_data = generate_custom_data(
        patterns=patterns,
        output_size=output_size,
        generated_data=generated_data,
    )

    return pd.concat([generated_data, generated_custom_data], axis=1)
