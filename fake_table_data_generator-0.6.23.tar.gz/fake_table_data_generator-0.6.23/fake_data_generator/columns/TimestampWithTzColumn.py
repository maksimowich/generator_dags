import datetime
import pytz
import random
from typing import Dict, Iterable, Tuple, Union

import numpy as np
import pandas as pd

from .ColumnWithMix import ColumnWithMix
from .MixedColumn import MixedColumn
from ..data_types import DataType
from .detectable_columns.datetime_functions import generate_random_timestamp_with_tz


class TimestampWithTzColumn(ColumnWithMix):
    CLASS_NAME = "TIMESTAMPTZ"

    def __init__(
        self,
        column_name: str = None,
        data_type: Union[DataType, str] = None,
        start_timestamp: pd.Timestamp = None,
        end_timestamp: pd.Timestamp = None,
        timezone: str = None,
        null_ratio: float = 0,
        mix: MixedColumn = None,
    ):
        """if timezone is None, Etc/GMT is used
        else - the defined timezone is set for all values"""
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            mix=mix,
        )
        self.null_ratio = null_ratio
        self.not_null_ratio = 1 - self.null_ratio
        self.timezone = timezone
        if not start_timestamp or not end_timestamp:
            raise Exception(
                "start_timestamp or end_timestamp for TimestampWithTzColumn pattern is None, "
                "you should specify them explicitly"
            )
        self.start_timestamp = pd.to_datetime(start_timestamp)
        self.end_timestamp = pd.to_datetime(end_timestamp)

    def _generate_random_timestamp_with_tz(
            self,
            is_random_tz: bool,
    ) -> pd.Timestamp:
        if is_random_tz:
            return generate_random_timestamp_with_tz(
                self.start_timestamp,
                self.end_timestamp,
                (
                    pytz.timezone(self.timezone)
                    if self.timezone
                    else pytz.timezone(f"Etc/GMT{random.randint(-12, 12):+}")
                ),
            )

        return generate_random_timestamp_with_tz(
            self.start_timestamp,
            self.end_timestamp,
            (
                pytz.timezone(self.timezone)
                if self.timezone
                else pytz.timezone(f"Etc/GMT")
            ),
        )

    def generate_data(
            self,
            output_size: int,
    ) -> pd.Series:
        timestamps = [
            (
                self._generate_random_timestamp_with_tz(is_random_tz=False)
                if np.random.choice(
                    a=[None, True], p=[self.null_ratio, self.not_null_ratio]
                )
                else None
            )
            for _ in range(output_size)
        ]
        return pd.Series(timestamps)

    def get_null_ratio(self) -> float:
        return self.null_ratio

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update(
            {
                "null_ratio": self.null_ratio,
                "start_timestamp": str(self.start_timestamp),
                "end_timestamp": str(self.end_timestamp),
                "tz_info": str(self.timezone),
            }
        )
        self.set_mix_to_end(super_dict)
        return super_dict

    @staticmethod
    def get_start_end_timestamp_and_timezone(
            timestamps: Iterable[pd.Timestamp],
    ) -> Tuple[pd.Timestamp, pd.Timestamp, datetime.tzinfo]:
        mints = timestamps[0]
        maxts = timestamps[0]
        tz = timestamps[0].tz
        is_tz_different = False
        for ts in timestamps:
            if ts < mints:
                mints = ts
            if ts > maxts:
                maxts = ts
            if ts.tz != tz:
                is_tz_different = True
        return mints, maxts, None if is_tz_different else tz
