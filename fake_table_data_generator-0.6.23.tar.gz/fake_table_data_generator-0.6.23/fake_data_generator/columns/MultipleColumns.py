from typing import List

import pandas as pd

from .Column import Column
from .Pattern import Pattern


class MultipleColumns(Pattern):
    CLASS_NAME = 'MULTIPLE_COLUMNS'

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.algorithm_name = algorithm_name
        self.columns = columns

    def get_pattern_name(self) -> str:
        return self.algorithm_name

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names: List[str],
    ) -> pd.DataFrame:
        return pd.DataFrame([[None] * len(self.columns)] * output_size)

    def generate_fake_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names: List[str],
    ) -> pd.DataFrame:
        columns_names = self.get_columns_names()
        if self.CLASS_NAME == "CUSTOM_GENERATOR_COLUMNS":
            fake_data_in_df = self.generate_data(output_size, generated_data)
        else:
            fake_data_in_df = self.generate_data(output_size, generated_data, mix_columns_names)
        fake_data_in_df.rename(columns={index: name for index, name in enumerate(columns_names)}, inplace=True)
        return fake_data_in_df

    def get_algorithm_name(self) -> str:
        return self.algorithm_name

    def get_columns(self) -> List[Column]:
        return self.columns

    def get_columns_names(self) -> List[str]:
        return [column.get_column_name() for column in self.get_columns()]

    def get_as_dict(self) -> dict:
        return {
            self.algorithm_name: {
                'type': self.CLASS_NAME,
                'columns': {
                    column.get_column_name(): column.get_as_dict()[column.get_column_name()]
                    for column in self.columns
                }
            }
        }
