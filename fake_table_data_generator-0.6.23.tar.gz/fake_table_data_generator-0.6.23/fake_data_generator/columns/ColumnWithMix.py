from typing import Dict, Optional, Tuple, Union
from abc import ABCMeta

import pandas as pd

from .Column import Column
from ..data_types import DataType
from .MixedColumn import MixedColumn


class ColumnWithMix(Column, metaclass=ABCMeta):
    """
    Abstract class for patterns which can contain mix pattern
    """
    def __init__(
            self,
            column_name: str,
            data_type: Union[DataType, str] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.mix = mix

    def generate_fake_data(
            self,
            output_size: int,
            mix: bool = False,
    ) -> pd.Series:
        if self.has_mix() and mix:
            generated_data_in_series = self.mix.generate_data(output_size)
        else:
            generated_data_in_series = self.generate_data(output_size)
        generated_data_in_series.name = self.column_name
        return generated_data_in_series

    def has_mix(self) -> bool:
        return self.mix is not None

    def set_mix(self, mix: MixedColumn) -> None:
        self.mix = mix

    # rearrangement for correct order in dictionary representation of pattern
    def set_mix_to_end(self, res_dict: Dict) -> None:
        if "mix" in res_dict[self.column_name]:
            mix = res_dict[self.column_name]["mix"]
            del res_dict[self.column_name]["mix"]
            res_dict[self.column_name]["mix"] = mix

    def get_itself_index_and_probability_in_mix(self) -> Optional[Tuple[int, float]]:
        for i, pattern_in_mix in enumerate(self.mix.patterns):
            if isinstance(pattern_in_mix, self.__class__):
                return i, self.mix.probabilities[i]

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        if self.mix:
            super_dict[self.column_name].update({
                "mix": self.mix.get_as_dict().get(self.mix.get_column_name())
            })
            del super_dict[self.column_name]["mix"]["data_type"]
            del super_dict[self.column_name]["mix"]["null_ratio"]
            del super_dict[self.column_name]["mix"]["type"]
        return super_dict
