from typing import Callable, List
import inspect

from .Column import Column
from .MultipleColumns import MultipleColumns


class CustomGeneratorColumns(MultipleColumns):
    CLASS_NAME = 'CUSTOM_GENERATOR_COLUMNS'

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
            generate_data_function: Callable,
    ):
        super().__init__(
            algorithm_name=algorithm_name,
            columns=columns,
        )
        self.generate_data = generate_data_function

    def get_as_dict(self):
        super_dict = super().get_as_dict()
        super_dict[self.algorithm_name].update({
            'generator_function': inspect.getsource(self.generate_data),
        })
        return super_dict
