from typing import List

from .utils import get_pattern_by_name
from .Pattern import Pattern
from .Column import Column
from .ConditionalContinuousColumn import ConditionalContinuousColumn
from .MultipleCategoricalColumns import MultipleCategoricalColumns


def get_predefined_patterns(
        patterns: List[Pattern],
) -> List[Pattern]:
    predefined_patterns = []
    for pattern in patterns:
        if pattern.is_predefined_pattern():
            predefined_patterns.append(pattern)

            if isinstance(pattern, ConditionalContinuousColumn):
                parameter_pattern_name = pattern.parameter_pattern_name
                existing_pattern = get_pattern_by_name(predefined_patterns, parameter_pattern_name)
                if not existing_pattern:
                    parameter_pattern = MultipleCategoricalColumns(
                        algorithm_name=parameter_pattern_name,
                        columns=[
                            Column(parameter_column_name)
                            for parameter_column_name in pattern.parameter_columns_names
                        ],
                    )
                    predefined_patterns.append(parameter_pattern)

    return predefined_patterns
