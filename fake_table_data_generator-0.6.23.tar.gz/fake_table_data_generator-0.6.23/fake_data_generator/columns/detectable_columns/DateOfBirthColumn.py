from typing import Dict, Optional, Tuple, Union
from datetime import date, datetime
from dateutil.relativedelta import relativedelta

import numpy as np
import pandas as pd

from .AbstractSupportColumn import AbstractSupportColumn
from ...data_types import String, Varchar, Char, Date, Timestamp
from .datetime_functions import (
    DATE_FORMATS,
    does_satisfy_format,
    generate_random_timestamp,
)


class DateOfBirthColumn(AbstractSupportColumn):
    CLASS_NAME = "DATE_OF_BIRTH"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = None
    FORMATS = DATE_FORMATS
    types = (String, Varchar, Char, Date, Timestamp)

    START_DATE_OF_BIRTH_FOR_DETECTION = pd.Timestamp(1920, 1, 1)
    START_DATE_OF_BIRTH_FOR_GENERATOIN = pd.Timestamp(1945, 1, 1)
    END_DATE_OF_BIRTH = pd.to_datetime(date.today() - relativedelta(years=14))
    THRESHOLD_YEAR = date.today().year

    @classmethod
    def get_date_of_birth_as_dt(
            cls,
            date_of_birth: Union[str, date, datetime],
    ) -> date:
        if isinstance(date_of_birth, str):
            for date_format in cls.FORMATS:
                try:
                    dt = datetime.strptime(date_of_birth, date_format).date()
                    if dt.year > cls.THRESHOLD_YEAR:
                        dt = dt.replace(year=dt.year - 100)
                    return dt
                except ValueError:
                    continue
            raise ValueError(f"{date_of_birth} does not match any format")
        elif isinstance(date_of_birth, pd.Timestamp):
            return date_of_birth.to_pydatetime().date()
        elif isinstance(date_of_birth, date):
            return date_of_birth

    def generate_date_of_birth(
            self,
    ) -> Union[str, pd.Timestamp, None]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            random_date_of_birth = generate_random_timestamp(
                start_timestamp=self.START_DATE_OF_BIRTH_FOR_GENERATOIN,
                end_timestamp=self.END_DATE_OF_BIRTH,
            )
            if self.formats is None:
                return random_date_of_birth
            else:
                date_format = np.random.choice(self.formats, p=self.formats_probs)
                return random_date_of_birth.strftime(date_format)
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_birth_dates = [self.generate_date_of_birth() for _ in range(output_size)]
        return pd.Series(fake_birth_dates, dtype=object)

    @classmethod
    def get_min_dttm(
            cls,
            values: pd.Series,
    ) -> pd.Timestamp:
        min_dttm: pd.Timestamp = None
        for value in values:
            if isinstance(value, datetime):
                if min_dttm is None or value < min_dttm:
                    min_dttm = value
            elif isinstance(value, date):
                value = pd.to_datetime(value)
                if min_dttm is None or value < min_dttm:
                    min_dttm = value
            elif isinstance(value, str):
                for frmt in cls.FORMATS:
                    if does_satisfy_format(value, frmt):
                        value = datetime.strptime(value, frmt)
                        if min_dttm is None or value < min_dttm:
                            min_dttm = value
                        break
            else:
                raise ValueError("unexpected data type, values can contain only types: datetime, date, str")
        return min_dttm

    @classmethod
    def does_match_class(
            cls,
            value: Union[date, pd.Timestamp, str],
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if isinstance(value, pd.Timestamp):
            return cls.START_DATE_OF_BIRTH_FOR_DETECTION <= value <= cls.END_DATE_OF_BIRTH, None

        elif isinstance(value, date):
            return cls.START_DATE_OF_BIRTH_FOR_DETECTION.to_pydatetime().date() <= value <= cls.END_DATE_OF_BIRTH.to_pydatetime().date(), None

        elif isinstance(value, str):
            for frmt in cls.FORMATS:
                if does_satisfy_format(string=value, datetime_format=frmt):
                    dt = datetime.strptime(value, frmt)
                    if dt.year > cls.THRESHOLD_YEAR:
                        dt = dt.replace(year=dt.year - 100)
                    return cls.START_DATE_OF_BIRTH_FOR_DETECTION <= dt <= cls.END_DATE_OF_BIRTH, frmt
            return False, None

        else:
            raise ValueError(f'value argument must be of type date, pd.Timestamp or str, not {type(value)}')
