from typing import List

import pandas as pd

from ... import Column
from ..AbstractComprehensiveColumns import AbstractComprehensiveColumns
from .INNColumn import INNColumn
from .KPPColumn import KPPColumn


class INNAndKPPColumns(AbstractComprehensiveColumns):
    CLASS_NAME = 'INN_AND_KPP'

    SINGLE_COLUMN_CLASSES = (
        INNColumn,
        KPPColumn,
    )

    def generate_row(
            self,
            mix_columns_indexes: List[int] = None,
    ) -> List:
        inn = None
        kpp = None

        if self.inn_column:
            inn = self.inn_column.generate_inn()

        if self.kpp_column:
            if inn is not None and len(inn) == 10:
                kpp = self.kpp_column.generate_kpp(infs_code=inn[:4])
            else:
                kpp = None

        unsorted_row = [
            (inn, self.inn_index),
            (kpp, self.kpp_index),
        ]

        return self.replace_values_with_mix_and_get_sorted_row(
            unsorted_row=unsorted_row,
            mix_columns_indexes=mix_columns_indexes
        )

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names: List[str],
    ) -> pd.DataFrame:
        mix_columns_indexes = self.get_indexes_by_columns_names(mix_columns_names)
        data = [
            self.generate_row(mix_columns_indexes)
            for _ in range(output_size)
        ]
        return pd.DataFrame(data)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.inn_column = None
        self.kpp_column = None

        self.inn_index = None
        self.kpp_index = None

        super().__init__(algorithm_name, columns)
