from typing import Dict, Optional, Tuple
from random import randint

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class KPPColumn(AbstractDetectableColumn):
    CLASS_NAME = "KPP"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    def generate_kpp(
            self,
            infs_code: str = None,
    ) -> Optional[str]:
        if ResourceLoader.SUBJECTS_CODES is None:
            ResourceLoader.load_subjects_codes()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if infs_code is None:
                subject_code = np.random.choice(ResourceLoader.SUBJECTS_CODES)
                tax_inspection_number = str(randint(1, 99)).zfill(2)
                infs_code = f"{subject_code}{tax_inspection_number}"
            reason_number = str(randint(1, 49)).zfill(2)
            order_number = str(randint(1, 999)).zfill(3)
            return f"{infs_code}{reason_number}{order_number}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_kpps = [self.generate_kpp() for _ in range(output_size)]
        return pd.Series(fake_kpps)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.SUBJECTS_CODES is None:
            ResourceLoader.load_subjects_codes()
        if (len(value) != 9
                or not value.isdigit()
                or value[:2] not in ResourceLoader.SUBJECTS_CODES
                or value[4:6] == '00'
                or int(value[4:6]) > 50):
            return False, None
        else:
            return True, None
