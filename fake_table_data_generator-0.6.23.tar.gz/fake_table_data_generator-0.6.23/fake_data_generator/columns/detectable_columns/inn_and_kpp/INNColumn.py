from typing import Dict, Optional, Tuple
import random

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class INNColumn(AbstractDetectableColumn):
    CLASS_NAME = "INN"
    RECOGNITION_THRESHOLD = 0.95
    DEFAULT_FORMATS = [
        "fiz",
        "yur",
    ]
    types = (String, Varchar, Char)

    COEFFICIENTS_1_FIZ = [7, 2, 4, 10, 3, 5, 9, 4, 6, 8]
    COEFFICIENTS_2_FIZ = [3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8]
    COEFFICIENTS_YUR = [2, 4, 10, 3, 5, 9, 4, 6, 8]

    def generate_inn(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if ResourceLoader.SUBJECTS_CODES is None:
                ResourceLoader.load_subjects_codes()
            subject_code = random.choice(ResourceLoader.SUBJECTS_CODES)
            digits_1 = str(random.randint(1, 99)).zfill(2)
            inn_type = np.random.choice(self.formats, p=self.formats_probs)
            if inn_type == 'fiz':
                digits_2 = str(random.randint(1, 999999)).zfill(6)
                result_string = f"{subject_code}{digits_1}{digits_2}"
                check_number_1 = sum(map(lambda x: int(x[0]) * x[1], zip(result_string, self.COEFFICIENTS_1_FIZ))) % 11 % 10
                result_string = f"{result_string}{check_number_1}"
                check_number_2 = sum(map(lambda x: int(x[0]) * x[1], zip(result_string, self.COEFFICIENTS_2_FIZ))) % 11 % 10
                return f"{result_string}{check_number_2}"
            elif inn_type == 'yur':
                digits_2 = str(random.randint(1, 99999)).zfill(5)
                result_string = f"{subject_code}{digits_1}{digits_2}"
                check_number = sum(map(lambda x: int(x[0]) * x[1], zip(result_string, self.COEFFICIENTS_YUR))) % 11 % 10
                return f"{result_string}{check_number}"
            else:
                raise ValueError(f"unsupported format '{inn_type}' for INNColumn")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_inns = [self.generate_inn() for _ in range(output_size)]
        return pd.Series(fake_inns)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.SUBJECTS_CODES is None:
            ResourceLoader.load_subjects_codes()
        if (len(value) not in [10, 12]
                or not value.isdigit()
                or value[2:4] == '00'
                or value[0:2] not in ResourceLoader.SUBJECTS_CODES):
            return False, None

        if len(value) == 12:
            check_number_1 = sum(map(lambda x: int(x[0]) * x[1], zip(value[0:10], cls.COEFFICIENTS_1_FIZ))) % 11 % 10
            check_number_2 = sum(map(lambda x: int(x[0]) * x[1], zip(value[0:11], cls.COEFFICIENTS_2_FIZ))) % 11 % 10
            if value[10] == str(check_number_1) and value[11] == str(check_number_2):
                return True, 'fiz'
            else:
                return False, None
        elif len(value) == 10:
            check_number = sum(map(lambda x: int(x[0]) * x[1], zip(value[0:10], cls.COEFFICIENTS_YUR))) % 11 % 10
            if value[9] == str(check_number):
                return True, 'yur'
            else:
                return False, None
        else:
            return False, None
