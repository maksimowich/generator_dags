from datetime import datetime
import locale

import numpy as np
import pandas as pd

# locale.setlocale(locale.LC_TIME, 'ru_RU')

DATE_FORMATS = [
    "%Y-%m-%d",
    "%d.%m.%Y",
    "%d/%m/%Y",
    "%d-%m-%Y",
    "%d %m %Y",
    "%d.%m.%y",
    "%d/%m/%y",
    "%d-%m-%y",
    "%d %m %y",
    "%d %B %Y г.",
    "%d-%B-%Y",
    "%Y-%m-%d %H:%M:%S",
]


def does_satisfy_format(
        string: str,
        datetime_format: str,
) -> bool:
    try:
        datetime.strptime(string, datetime_format)
        return True
    except ValueError:
        return False


def generate_random_timestamp(
        start_timestamp: pd.Timestamp,
        end_timestamp: pd.Timestamp,
) -> pd.Timestamp:
    random_days = np.random.randint((end_timestamp - start_timestamp).days + 1)
    return start_timestamp + pd.Timedelta(days=random_days)


def generate_random_timestamp_with_tz(
        start_timestamp: pd.Timestamp,
        end_timestamp: pd.Timestamp,
        timezone: datetime.tzinfo
) -> pd.Timestamp:
    ts = generate_random_timestamp(start_timestamp, end_timestamp)
    # return ts.tz_convert(timezone)
    if ts.tz:
        return ts.tz_convert("UTC")
    return ts.tz_localize(timezone)
