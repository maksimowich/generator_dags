from typing import List

import pandas as pd
import numpy as np
import random

from ... import Column
from ..AbstractComprehensiveColumns import AbstractComprehensiveColumns
from ..resource_loader import ResourceLoader
from .OKATOColumn import OKATOColumn
from .OKTMOColumn import OKTMOColumn
from ....data_types import String, Varchar, Char

class OKATOAndOKTMOColumns(AbstractComprehensiveColumns):
    CLASS_NAME = 'OKATO_AND_OKTMO'
    DEFAULT_FORMATS = ['01', '03', '04', '07', '08', '10', '11', '12', '14', '15', '17', '18', '19', '20', '22', '24',
                       '25', '27', '28', '29', '30', '32', '33', '34', '36', '37', '38', '41', '42', '44', '46', '47',
                       '49', '50', '52', '53', '54', '56', '57', '58', '60', '61', '63', '64', '65', '66', '68', '69',
                       '70', '71', '73', '75', '78', '40', '45', '67', '79', '84', '99', '91', '95', '77', '76', '80',
                       '81', '82', '83', '85', '86', '87', '88', '89', '90', '92', '93', '94', '26', '97', '98', '96']

    SINGLE_COLUMN_CLASSES = (
        OKATOColumn,
        OKTMOColumn
    )
    types = (String, Varchar, Char)

    def generate_okato_and_oktmo_data(
            self,
            mix_columns_indexes
    ) -> List:
        okato = None
        oktmo = None

        if ResourceLoader.OKATO_OKTMO_REGIONS_AND_NUMBERS is None:
            ResourceLoader.load_okato_oktmo_regions()
        if okato is None and oktmo is None:
            region_cod = np.random.choice(self.okato_column.formats, p=self.okato_column.formats_probs)
            okato, oktmo = random.choice(ResourceLoader.OKATO_OKTMO_REGIONS_AND_NUMBERS[region_cod])
        else:
            okato = None
            oktmo = None

        unsorted_data = [
            (okato, self.okato_index),
            (oktmo, self.oktmo_index),
        ]

        return self.replace_values_with_mix_and_get_sorted_row(
            unsorted_row=unsorted_data,
            mix_columns_indexes=mix_columns_indexes
        )

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names: List[str],
    ) -> pd.DataFrame:
        mix_columns_indexes = self.get_indexes_by_columns_names(mix_columns_names)
        data = [self.generate_okato_and_oktmo_data(mix_columns_indexes) for _ in range(output_size)]
        return pd.DataFrame(data)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.okato_column = None
        self.oktmo_column = None

        self.okato_index = None
        self.oktmo_index = None

        super().__init__(algorithm_name, columns)
