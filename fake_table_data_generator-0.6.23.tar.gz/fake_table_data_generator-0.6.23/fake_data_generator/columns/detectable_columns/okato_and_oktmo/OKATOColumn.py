from typing import Dict, Optional, Tuple
from random import randint

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ..resource_loader import ResourceLoader
from ....data_types import String, Varchar, Char

class OKATOColumn(AbstractDetectableColumn):
    CLASS_NAME = "OKATO"
    RECOGNITION_THRESHOLD = 0.8
    DEFAULT_FORMATS = ['01', '03', '04', '07', '08', '10', '11', '12', '14', '15', '17', '18', '19', '20', '22', '24',
                       '25', '27', '28', '29', '30', '32', '33', '34', '36', '37', '38', '41', '42', '44', '46', '47',
                       '49', '50', '52', '53', '54', '56', '57', '58', '60', '61', '63', '64', '65', '66', '68', '69',
                       '70', '71', '73', '75', '78', '40', '45', '67', '79', '84', '99', '91', '95', '77', '76', '80',
                       '81', '82', '83', '85', '86', '87', '88', '89', '90', '92', '93', '94', '26', '97', '98', '96']
    types = (String, Varchar, Char)

    def generate_okato(
            self,
            okato_code: str = None,
    ) -> Optional[str]:
        if ResourceLoader.OKATO_REGIONS_AND_NUMBERS is None:
            ResourceLoader.load_okato_regions()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if okato_code is None:
                region_cod = np.random.choice(self.formats, p=self.formats_probs)
                okato_code = np.random.choice(ResourceLoader.OKATO_REGIONS_AND_NUMBERS[region_cod])
            return f"{okato_code}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_okato = [self.generate_okato() for _ in range(output_size)]
        return pd.Series(fake_okato)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.OKATO_FIRST_8_DIGITS is None:
            ResourceLoader.load_okato_first_8_digits()
        if (len(value) != 11
                or not isinstance(value, str)
                or value[:8] not in ResourceLoader.OKATO_FIRST_8_DIGITS):
            return False, None
        else:
            return True, value[:2]
