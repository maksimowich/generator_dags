from abc import ABCMeta

from .AbstractDetectableColumn import AbstractDetectableColumn


class AbstractDependentDetectableColumn(AbstractDetectableColumn, metaclass=ABCMeta):
    DEPENDENCIES = None
