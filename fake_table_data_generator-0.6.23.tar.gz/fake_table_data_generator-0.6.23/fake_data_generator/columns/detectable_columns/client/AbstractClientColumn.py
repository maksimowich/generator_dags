from abc import ABCMeta
from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char


class AbstractClientColumn(AbstractDetectableColumn, metaclass=ABCMeta):
    DEFAULT_FORMATS = [
        'upper'
    ]
    FORMATS = {
        'upper': str.upper,
        'lower': lambda x: x.lower().title(),
        'all_lower': lambda x: x.lower(),
    }
    types = (String, Varchar, Char)
