from typing import Dict,Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import GenderColumn
from .AbstractClientColumn import AbstractClientColumn
from ..resource_loader import ResourceLoader


class NameColumn(AbstractClientColumn):
    CLASS_NAME = "NAME"
    RECOGNITION_THRESHOLD = 0.85

    REGEX_FOR_NAME_IN_UPPER_CASE = r'[А-ЯЁ]+$'
    REGEX_FOR_NAME_ONLY_STARTING_WITH_UPPER_CASE = r'[А-Я][а-яё]+$'

    def generate_name(
            self,
            gender: Optional[str] = None,
    ):
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if gender is None:
                gender = np.random.choice(['m', 'f'])
            applied_function = self.FORMATS[np.random.choice(self.formats, p=self.formats_probs)]
            if gender in GenderColumn.FEMALE:
                return applied_function(f"{np.random.choice(ResourceLoader.FEMALE_NAMES)}")
            else:
                return applied_function(f"{np.random.choice(ResourceLoader.MALE_NAMES)}")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        fake_names = [self.generate_name() for _ in range(output_size)]
        return pd.Series(fake_names)

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        if value.upper() in ResourceLoader.NAMES:
            if re.match(cls.REGEX_FOR_NAME_IN_UPPER_CASE, value):
                return True, 'upper'
            elif re.match(cls.REGEX_FOR_NAME_ONLY_STARTING_WITH_UPPER_CASE, value):
                return True, 'lower'
            else:
                return False, None
        else:
            return False, None
