from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import GenderColumn
from .AbstractClientColumn import AbstractClientColumn
from ..resource_loader import ResourceLoader


class FioColumn(AbstractClientColumn):
    CLASS_NAME = "FIO"
    RECOGNITION_THRESHOLD = 0.8

    REGEX_FOR_FIO_IN_UPPER_CASE = r'^[А-ЯЁ]+(?:-[А-ЯЁ]+)? [А-ЯЁ]+ [А-ЯЁ]+(?:-[А-ЯЁ]+)?$'
    REGEX_FOR_FIO_IN_LOWER_CASE = r'^[а-я]+(?:-[а-я]+)? [а-яё]+ [а-яё]+(?:-[а-яё]+)?$'
    REGEX_FOR_FIO_ONLY_STARTING_WITH_UPPER_CASE = r'^[А-Яа-яЁё]+(?:-[А-Яа-яЁё]+)? [А-Яа-яЁё]+ [А-Яа-яЁё]+(?:-[А-Яа-яЁё]+)?$'

    def generate_fio(
            self,
            gender: Optional[str] = None,
            name: Optional[str] = None,
            patronymic: Optional[str] = None,
            surname: Optional[str] = None,
    ):
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        if ResourceLoader.PATRONYMICS is None:
            ResourceLoader.load_patronymics()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if gender is None:
                gender = np.random.choice(['m', 'f'])
            if gender in GenderColumn.FEMALE:
                name = name or np.random.choice(ResourceLoader.FEMALE_NAMES)
                patronymic = patronymic or np.random.choice(ResourceLoader.FEMALE_PATRONYMICS)
                surname = surname or self.faker_ru.last_name_female()
            else:
                name = name or np.random.choice(ResourceLoader.MALE_NAMES)
                patronymic = patronymic or np.random.choice(ResourceLoader.MALE_PATRONYMICS)
                surname = surname or self.faker_ru.last_name_male()
            applied_function = self.FORMATS[np.random.choice(self.formats, p=self.formats_probs)]
            return applied_function(f"{surname} {name} {patronymic}")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_fio = [self.generate_fio() for _ in range(output_size)]
        return pd.Series(fake_fio)

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        if len(value.split(' ')) != 3:
            return False, None
        elif value.split(' ')[1].upper() in ResourceLoader.NAMES:
            if re.match(cls.REGEX_FOR_FIO_IN_LOWER_CASE, value):
                return True, 'all_lower'
            if re.match(cls.REGEX_FOR_FIO_IN_UPPER_CASE, value):
                return True, 'upper'
            elif re.match(cls.REGEX_FOR_FIO_ONLY_STARTING_WITH_UPPER_CASE, value):
                return True, 'lower'
            else:
                return False, None
        else:
            return False, None
