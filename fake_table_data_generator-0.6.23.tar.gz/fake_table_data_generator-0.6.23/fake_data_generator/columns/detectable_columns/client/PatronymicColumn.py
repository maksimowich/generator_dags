from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import GenderColumn
from .AbstractClientColumn import AbstractClientColumn
from ..resource_loader import ResourceLoader


class PatronymicColumn(AbstractClientColumn):
    CLASS_NAME = "PATRONYMIC"
    RECOGNITION_THRESHOLD = 0.85

    REGEX_FOR_PATRONYMIC_IN_UPPER_CASE = r'[А-ЯЁ]+$'
    REGEX_FOR_PATRONYMIC_ONLY_STARTING_WITH_UPPER_CASE = r'[А-Я][а-яё]+$'

    def generate_patronymic(
            self,
            gender: Optional[str] = None,
    ):
        if ResourceLoader.PATRONYMICS is None:
            ResourceLoader.load_patronymics()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if gender is None:
                gender = np.random.choice(['m', 'f'])
            applied_function = self.FORMATS[np.random.choice(self.formats, p=self.formats_probs)]
            if gender in GenderColumn.FEMALE:
                return applied_function(f"{np.random.choice(ResourceLoader.FEMALE_PATRONYMICS)}")
            else:
                return applied_function(f"{np.random.choice(ResourceLoader.MALE_PATRONYMICS)}")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_patronymics = [self.generate_patronymic() for _ in range(output_size)]
        return pd.Series(fake_patronymics)

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.PATRONYMICS is None:
            ResourceLoader.load_patronymics()
        if value.upper() in ResourceLoader.PATRONYMICS:
            if re.match(cls.REGEX_FOR_PATRONYMIC_IN_UPPER_CASE, value):
                return True, 'upper'
            elif re.match(cls.REGEX_FOR_PATRONYMIC_ONLY_STARTING_WITH_UPPER_CASE, value):
                return True, 'lower'
            else:
                return False, None
        else:
            return False, None
