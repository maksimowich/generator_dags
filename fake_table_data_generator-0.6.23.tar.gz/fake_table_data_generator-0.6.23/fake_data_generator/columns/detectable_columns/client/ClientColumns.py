from typing import List

import numpy as np
import pandas as pd

from ... import Column
from .. import GenderColumn
from .. import AbstractComprehensiveColumns
from .NameColumn import NameColumn
from .PatronymicColumn import PatronymicColumn
from .SurnameColumn import SurnameColumn
from .FioColumn import FioColumn
from .EmbossNameAndSurnameColumn import EmbossNameAndSurnameColumn


class ClientColumns(AbstractComprehensiveColumns):
    CLASS_NAME = 'CLIENT'

    SINGLE_COLUMN_CLASSES = (
        NameColumn,
        PatronymicColumn,
        SurnameColumn,
        FioColumn,
        EmbossNameAndSurnameColumn,
    )

    def generate_row(
            self,
            gender: str = None,
            mix_columns_indexes: List[int] = None,
    ) -> List:
        client_name = None
        client_patronymic = None
        client_surname = None
        client_fio = None
        client_emboss_name_and_surname = None

        if gender is None:
            gender = np.random.choice(['f', 'm'])

        if self.name_column:
            client_name = self.name_column.generate_name(gender=gender)
        if self.patronymic_column:
            client_patronymic = self.patronymic_column.generate_patronymic(gender=gender)
        if self.surname_column:
            client_surname = self.surname_column.generate_surname(gender=gender)
        if self.fio_column:
            client_fio = self.fio_column.generate_fio(
                gender=gender,
                name=client_name,
                patronymic=client_patronymic,
                surname=client_surname,
            )
            if client_fio is not None:
                fio_surname, fio_name, _ = client_fio.split(" ")
                if client_surname is None:
                    client_surname = fio_surname
                if client_name is None:
                    client_name = fio_name

        if self.emboss_name_and_surname_column:
            client_emboss_name_and_surname = self.emboss_name_and_surname_column.generate_emboss_name(
                gender=gender,
                name=client_name,
                surname=client_surname,
            )

        unsorted_row = [
            (client_name, self.name_index),
            (client_patronymic, self.patronymic_index),
            (client_surname, self.surname_index),
            (client_fio, self.fio_index),
            (client_emboss_name_and_surname, self.emboss_name_and_surname_index),
        ]

        return self.replace_values_with_mix_and_get_sorted_row(
            unsorted_row=unsorted_row,
            mix_columns_indexes=mix_columns_indexes
        )

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names: List[str],
    ) -> pd.DataFrame:
        mix_columns_indexes = self.get_indexes_by_columns_names(mix_columns_names)
        gender_col = generated_data.get(GenderColumn.CLASS_NAME)
        data = [
            self.generate_row(
                gender=gender_col[i] if gender_col is not None else None,
                mix_columns_indexes=mix_columns_indexes,
            )
            for i in range(output_size)
        ]
        return pd.DataFrame(data)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.name_column = None
        self.patronymic_column = None
        self.surname_column = None
        self.fio_column = None
        self.emboss_name_and_surname_column = None

        self.name_index = None
        self.patronymic_index = None
        self.surname_index = None
        self.fio_index = None
        self.emboss_name_and_surname_index = None

        super().__init__(algorithm_name, columns)
