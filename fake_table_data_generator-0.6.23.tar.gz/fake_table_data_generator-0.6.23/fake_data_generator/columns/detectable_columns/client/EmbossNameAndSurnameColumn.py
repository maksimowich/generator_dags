from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import GenderColumn
from .AbstractClientColumn import AbstractClientColumn
from ..resource_loader import ResourceLoader


class EmbossNameAndSurnameColumn(AbstractClientColumn):
    CLASS_NAME = "EMBOSS_NAME_AND_SURNAME"
    RECOGNITION_THRESHOLD = 0.8

    REGEX_FOR_EMBOSS_NAME_IN_UPPER_CASE = r'^[A-Z]+ [A-Z]+$'
    REGEX_FOR_EMBOSS_NAME_ONLY_STARTING_WITH_UPPER_CASE = r'^[A-Z][a-z]* [A-Z][a-z]*$'
    REGEX_FOR_EMBOSS_NAME_IN_LOWER_CASE = r'^[a-z]+ [a-z]+$'

    EMBOSS_LETTERS = {
        "А": "A",
        "Б": "B",
        "В": "V",
        "Г": "G",
        "Д": "D",
        "Е": "E",
        "Ё": "E",
        "Ж": "ZH",
        "З": "Z",
        "И": "I",
        "Й": "I",
        "К": "K",
        "Л": "L",
        "М": "M",
        "Н": "N",
        "О": "O",
        "П": "P",
        "Р": "R",
        "С": "S",
        "Т": "T",
        "У": "U",
        "Ф": "F",
        "Х": "KH",
        "Ц": "TC",
        "Ч": "CH",
        "Ш": "SH",
        "Щ": "SHCH",
        "Ы": "Y",
        "Э": "E",
        "Ю": "IU",
        "Я": "IA"
    }

    @classmethod
    def translit_name(cls, name):
        word = []
        for letter in list(name.upper()):
            if letter == " " or letter == "Ь":
                continue
            word.append(cls.EMBOSS_LETTERS[letter])
        lat_name = "".join(word)
        return lat_name

    def generate_emboss_name(
            self,
            gender: Optional[str] = None,
            name: Optional[str] = None,
            surname: Optional[str] = None,
    ):
        if ResourceLoader.NAMES is None:
            ResourceLoader.load_names()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if gender is None:
                gender = np.random.choice(['m', 'f'])
            if gender in GenderColumn.FEMALE:
                name = name or np.random.choice(ResourceLoader.FEMALE_NAMES)
                name = self.translit_name(name)
                surname = surname or self.faker_ru.last_name_female()
                surname = self.translit_name(surname)
            else:
                name = name or np.random.choice(ResourceLoader.MALE_NAMES)
                name = self.translit_name(name)
                surname = surname or self.faker_ru.last_name_male()
                surname = self.translit_name(surname)
            applied_function = self.FORMATS[np.random.choice(self.formats, p=self.formats_probs)]
            return applied_function(f"{name} {surname}")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        emboss_name = [self.generate_emboss_name() for _ in range(output_size)]
        return pd.Series(emboss_name)

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.EMBOSS_NAMES is None:
            ResourceLoader.load_emboss_names()
        if len(value.split(' ')) != 2:
            return False, None
        if value.split(' ')[0].upper() in ResourceLoader.EMBOSS_NAMES:
            if re.match(cls.REGEX_FOR_EMBOSS_NAME_IN_UPPER_CASE, value):
                return True, 'upper'
            elif re.match(cls.REGEX_FOR_EMBOSS_NAME_ONLY_STARTING_WITH_UPPER_CASE, value):
                return True, 'lower'
            elif re.match(cls.REGEX_FOR_EMBOSS_NAME_IN_LOWER_CASE, value):
                return True, 'all_lower'
            else:
                return False, None
        else:
            return False, None
