from typing import List, Optional, Tuple

import pandas as pd

from ... import Column
from ..AbstractComprehensiveColumns import AbstractComprehensiveColumns
from .LegalEntitesAbbFullColumn import (
    LegalEntitiesAbbColumn,
    LegalEntitiesFullColumn
)
from ..resource_loader import ResourceLoader


class LegalEntitiesAbbAndFullColumns(AbstractComprehensiveColumns):
    CLASS_NAME = 'LE_ABB_AND_FULL'

    SINGLE_COLUMN_CLASSES = (
        LegalEntitiesAbbColumn,
        LegalEntitiesFullColumn,
    )
    
    def generate_le_names(self) -> Tuple[Optional[str], Optional[str]]:
        if not self.le_fullname_column and self.le_abb_column:
            raise Exception("LE column-patterns are not initialized!")

        le_full_form = self.le_fullname_column.generate_le_full_form_name()
        if le_full_form:
            if not self.le_abb_column.generate_le_abb_form_name():
                le_abb_form = None
            else:
                le_abb_form = ResourceLoader.get_legal_entities_full_to_abb_dict()[le_full_form]
            le_name = self.le_fullname_column.generate_le_name_for_le_form(le_full_form)
        else:
            # We've generated None for full form, but abb
            # could be non-null (according to null_ratio of abb_column)
            le_abb_form = self.le_abb_column.generate_le_abb_form_name()
            le_name = self.le_abb_column.generate_le_name_for_le_form(le_abb_form)

        if le_full_form and le_abb_form:
            return le_full_form + ' ' + le_name, le_abb_form + ' ' + le_name
        if le_full_form:
            return le_full_form + ' ' + le_name, None
        if le_abb_form:
            return None, le_abb_form + ' ' + le_name
        return None, None

    def generate_row(
            self,
            mix_columns_indexes: List[int] = None,
    ) -> List:
        names = None
        names_full = (None, None)
        names_abb = (None, None)

        if not self.le_fullname_column and self.le_abb_column:
            raise Exception("LE column-patterns are not initialized!")
        names = self.generate_le_names()

        unsorted_row = [
            (names[1], self.le_abb_index),
            (names[0], self.le_fullname_index),
        ]

        return self.replace_values_with_mix_and_get_sorted_row(
            unsorted_row=unsorted_row,
            mix_columns_indexes=mix_columns_indexes
        )

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names
    ) -> pd.DataFrame:
        mix_columns_indexes = self.get_indexes_by_columns_names(mix_columns_names)
        data = [
            self.generate_row(mix_columns_indexes)
            for _ in range(output_size)
        ]
        return pd.DataFrame(data)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.le_abb_column = None
        self.le_fullname_column = None

        self.le_abb_index = None
        self.le_fullname_index = None

        super().__init__(algorithm_name, columns)
