from abc import abstractmethod
from typing import Dict, Optional, Tuple, List
import random

import numpy as np
import pandas as pd

from ..AbstractDetectableColumn import AbstractDetectableColumn
from ...MixedColumn import MixedColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class AbstractLegalEntitiesAbbFullColumn(AbstractDetectableColumn):
    CLASS_NAME = "LE"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    INDIVIDUAL_ENTERPRENEUR_FULL_FORM_NAMES = ['ИНДИВИДУАЛЬНЫЙ ПРЕДПРИНИМАТЕЛЬ', 'ИП']
    AVAILABLE_ACRONIM_LETTERS = 'АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ'

    def __init__(
            self,
            column_name: str = None,
            data_type: str = None,
            null_ratio: float = 0,
            format_: Dict[str, float] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(column_name, data_type, null_ratio, format_, mix)
        self._full_format = []
        self._abb_format = []

    @abstractmethod
    def _map_formats_to_full_forms(self) -> List[str]:
        pass

    @abstractmethod
    def _map_formats_to_abb_forms(self) -> List[str]:
        pass

    def generate_le_abb_form_name(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if self.formats:
                return np.random.choice(self._map_formats_to_abb_forms(), p=self.formats_probs)
            return np.random.choice(list(ResourceLoader.get_legal_entities_full_to_abb_dict().values()))
        return None

    def generate_le_full_form_name(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if self.formats:
                return np.random.choice(self._map_formats_to_full_forms(), p=self.formats_probs)
            return np.random.choice(list(ResourceLoader.get_legal_entities_full_to_abb_dict().keys()))
        return None

    def generate_le_name_for_le_form(self, le_form: str) -> Optional[str]:
        if not le_form:
            return None
        if le_form.upper() in AbstractLegalEntitiesAbbFullColumn.INDIVIDUAL_ENTERPRENEUR_FULL_FORM_NAMES:
            lastname = self.faker_ru.last_name()
            acronim = random.choice(self.AVAILABLE_ACRONIM_LETTERS) \
                + '.' + random.choice(self.AVAILABLE_ACRONIM_LETTERS) + '.'
            return lastname + ' ' + acronim
        return '"' + self.faker_ru.word().capitalize() + '"'


class LegalEntitiesAbbColumn(AbstractLegalEntitiesAbbFullColumn):
    CLASS_NAME = "LE_ABB"

    def _map_formats_to_full_forms(self) -> List[str]:
        if not self._full_format:
            for abb_format in self.formats:
                for f_format, a_format in ResourceLoader.get_legal_entities_full_to_abb_dict().items():
                    if abb_format == a_format:
                        self._full_format.append(f_format)
                        break
        return self._full_format

    def _map_formats_to_abb_forms(self) -> List[str]:
        return self.formats

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        short_le = [word for word in ResourceLoader.get_legal_entities_full_to_abb_dict().values()
                    if word.upper() in set(value.upper().split())]
        if short_le:
            return True, short_le[0]
        return False, None

    def generate_data(self, output_size: int) -> pd.Series:
        """In general generate_data() is not used. Class LegalEntitiesAbbColumn is used in multi-column context

        Args:
            output_size (int): number of items to generate

        Returns:
            pd.Series: generated data

        """
        res = []
        for _ in range(output_size):
            le_full_form = self.generate_le_full_form_name()
            le_name = self.generate_le_name_for_le_form(le_full_form)
            if le_full_form:
                res.append(ResourceLoader.get_legal_entities_full_to_abb_dict()[le_full_form] + ' ' + le_name)
            else:
                res.append(None)
        return pd.Series(res)


class LegalEntitiesFullColumn(AbstractLegalEntitiesAbbFullColumn):
    CLASS_NAME = "LE_FULLNAME"

    def _map_formats_to_full_forms(self) -> List[str]:
        return self.formats

    def _map_formats_to_abb_forms(self) -> List[str]:
        if not self._abb_format:
            self._abb_format = [ResourceLoader.get_legal_entities_full_to_abb_dict()[full_format] for full_format in self.formats]
        return self._abb_format

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        full_le = [word for word in ResourceLoader.get_legal_entities_full_to_abb_dict().keys()
                   if word.upper() in value.upper()]
        if full_le:
            return True, full_le[0]
        return False, None

    def generate_data(self, output_size: int) -> pd.Series:
        """
        In general generate_data() is not used. Class LegalEntitiesFullColumn is used in multi-column context

        Args:
            output_size (int): number of items to generate

        Returns:
            pd.Series: generated data
        """        
        res = []
        for _ in range(output_size):
            le_full_form = self.generate_le_full_form_name()
            le_name = self.generate_le_name_for_le_form(le_full_form)
            if le_full_form:
                res.append(le_full_form + ' ' + le_name)
            else:
                res.append(None)
        return pd.Series(res)
