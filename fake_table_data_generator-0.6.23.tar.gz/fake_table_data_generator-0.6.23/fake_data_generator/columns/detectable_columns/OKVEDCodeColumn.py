from typing import Dict, Optional, Tuple
import random
import re

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char
from .resource_loader import ResourceLoader


class OKVEDCodeColumn(AbstractDetectableColumn):
    CLASS_NAME = "OKVED_CODE"
    RECOGNITION_THRESHOLD = 0.9
    REGEX_FOR_OKVED = r"^\d{1,2}\.\d{1,2}(\.\d{1,2})?$"
    types = (String, Varchar, Char)

    def generate_okved_code(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if ResourceLoader.OKVED_CODES is None:
                ResourceLoader.load_okved()
            return random.choice(ResourceLoader.OKVED_CODES)
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_okved_codes = [self.generate_okved_code() for _ in range(output_size)]
        return pd.Series(fake_okved_codes)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.OKVED_CODES is None:
            ResourceLoader.load_okved()
        if (re.match(cls.REGEX_FOR_OKVED, value)
                and value in ResourceLoader.OKVED_CODES):
            return True, None
        else:
            return False, None
