from typing import Dict, Optional, Tuple
from datetime import date, timedelta
import random
import re
import rstr

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char


class PaymentPurposeColumn(AbstractDetectableColumn):
    CLASS_NAME = "PAYMENT_PURPOSE"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    KEY_WORDS_1 = [
        "ндс",
    ]
    KEY_WORDS_2 = [
        "платеж",
        "платёж",
        "плата",
        "выплата",
        "оплата",
        "зарплата",
        "взнос",
        "внесение",
        "удержание",
        "аванс",
    ]
    AGREEMENT_DATE = (date.today() - timedelta(days=2)).strftime("%d.%m.%Y")
    PAYMENT_PURPOSE_PATTERN = "Оплата по договору №{} от {} за поставку товара. НДС не облагается"

    def generate_payment_purpose(self):
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            agreement_number = f"{str(random.randint(1, 999)).zfill(3)}{rstr.xeger(r'[А-ЩЭ-Я]{2}')}"
            return self.PAYMENT_PURPOSE_PATTERN.format(agreement_number, self.AGREEMENT_DATE)
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_payment_purposes = [self.generate_payment_purpose() for _ in range(output_size)]
        return pd.Series(fake_payment_purposes)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        words = re.findall(r"\b\w+\b", value)
        if len(words) <= 1:
            return False, None
        value_in_lower_case = value.lower()
        if not any(key_word in value_in_lower_case for key_word in cls.KEY_WORDS_1):
            return False, None
        if any(key_word in value_in_lower_case for key_word in cls.KEY_WORDS_2):
            return True, None
        return False, None
