from typing import Dict, Optional, Tuple
import random

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char
from .resource_loader import ResourceLoader


class GPBNumberCardsColumn(AbstractDetectableColumn):
    CLASS_NAME = "GPB_NUMBER_CARDS"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    @classmethod
    def calculate_luna(cls, value: str) -> str:
        value_test = []
        for i in range(len(value[:15])):
            if not i % 2:
                if int(value[:15][i]) * 2 > 9:
                    value_test.append(int(value[:15][i]) * 2 - 9)
                else:
                    value_test.append(int(value[:15][i]) * 2)
            else:
                value_test.append(int(value[:15][i]))
        return str(10 - int(str(sum(value_test))[-1]))[-1]

    def generate_number_cards(self) -> Optional[str]:
        if np.random.choice(a=[None, True],p=[self.null_ratio, self.not_null_ratio]):
            number = str(random.choice(ResourceLoader.get_bin_gpb_codes())) + str(random.randint(100000000, 999999999))
            card_numbers = number + self.calculate_luna(number)
            return card_numbers
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        number_cards = [self.generate_number_cards() for _ in range(output_size)]
        return pd.Series(number_cards)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if not isinstance(value, str) or not value.isdigit() or len(value) != 16:
            return False, None
        if value[0] not in ['2', '3', '4', '5', '6']:
            return False, None
        if not value[0:6] in ResourceLoader.get_bin_gpb_codes() or value[6:16] == '0000000000':
            return False, None
        if value[-1] != cls.calculate_luna(value):
            return False, None
        return True, None
