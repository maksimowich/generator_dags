from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from .AbstractSupportColumn import AbstractSupportColumn
from ...data_types import String, Varchar, Char


class GenderColumn(AbstractSupportColumn):
    CLASS_NAME = "GENDER"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = [
        "М",
        "Ж",
    ]
    FORMATS = {
        "m": [
            "m",
            "Мужской",
            "мужской",
            "Муж.",
            "Муж",
            "муж.",
            "муж",
            "М",
            "м",
            "male",
        ],
        "f": [
            "f",
            "Женский",
            "женский",
            "Жен.",
            "Жен",
            "жен.",
            "жен",
            "Ж",
            "ж",
            "female",
        ]
    }
    MALE = FORMATS["m"]
    FEMALE = FORMATS["f"]
    GENDER = MALE + FEMALE
    types = (String, Varchar, Char)

    def generate_gender(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            gender = np.random.choice(self.formats, p=self.formats_probs)
            return gender
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_genders = [self.generate_gender() for _ in range(output_size)]
        return pd.Series(fake_genders)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if value in cls.GENDER:
            return True, value
        else:
            return False, None
