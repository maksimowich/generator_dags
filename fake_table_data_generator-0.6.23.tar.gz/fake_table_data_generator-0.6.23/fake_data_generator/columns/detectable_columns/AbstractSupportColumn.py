from abc import ABCMeta

from .AbstractDetectableColumn import AbstractDetectableColumn


class AbstractSupportColumn(AbstractDetectableColumn, metaclass=ABCMeta):
    pass
