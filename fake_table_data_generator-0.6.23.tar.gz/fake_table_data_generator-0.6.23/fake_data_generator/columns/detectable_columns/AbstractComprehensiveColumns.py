from abc import ABCMeta
from typing import List, Tuple, Type

from ..Column import Column
from ..MultipleColumns import MultipleColumns


class AbstractComprehensiveColumns(MultipleColumns, metaclass=ABCMeta):
    SINGLE_COLUMN_CLASSES: List[Type[Column]] = None

    @staticmethod
    def get_index_and_column(
            columns: List[Column],
            cls,
    ) -> Tuple:
        for i, column in enumerate(columns):
            if isinstance(column, cls):
                return i, column
        return None, None

    def get_indexes_by_columns_names(
            self,
            column_names: List[str],
    ) -> List[int]:
        res = []
        for i, column in enumerate(self.columns):
            if column.get_column_name() in column_names:
                res.append(i)
        return res

    def replace_values_with_mix(
            self,
            row: List[Tuple[object, int]],
            mix_columns_indexes: List[int],
    ) -> None:
        for i, (value, index) in enumerate(row):
            if index in mix_columns_indexes:
                random_pattern = self.columns[index].mix.get_random_pattern()
                if self.columns[index].__class__ != random_pattern.__class__:
                    new_value = random_pattern.generate_data(1)[0]
                    row[i] = (new_value, index)
                else:
                    pass

    @staticmethod
    def get_sorted_row(
            unsorted_row: List[Tuple[object, int]],
    ) -> List[object]:
        sorted_row = sorted(
            [(value, index) for value, index in unsorted_row if index is not None],
            key=lambda x: x[1],
        )
        return [value for value, _ in sorted_row]

    def replace_values_with_mix_and_get_sorted_row(
            self,
            unsorted_row: List[Tuple[object, int]],
            mix_columns_indexes: List[int],
    ) -> List[object]:
        if mix_columns_indexes:
            self.replace_values_with_mix(unsorted_row, mix_columns_indexes)
        return self.get_sorted_row(unsorted_row)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        super().__init__(algorithm_name, columns)
        for cls in self.SINGLE_COLUMN_CLASSES:
            index, column = self.get_index_and_column(columns, cls)
            setattr(self, f"{cls.CLASS_NAME.lower()}_index", index)
            setattr(self, f"{cls.CLASS_NAME.lower()}_column", column)
