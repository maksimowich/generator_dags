import csv
import os
from collections import defaultdict


class ResourceLoader:
    resources_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../resources')

    SUBJECTS_CODES = None

    DEPARTMENTS_CODES = None
    DEPARTMENTS_NAMES = None
    DEPARTMENTS_CODES_AND_NAMES = None

    OKADO_CODES = None
    SUBJECT_CODE_TO_OKADO_CODE = None

    BIK = None
    BIN_GPB = None

    OKVED_CODES = None

    OKATO_REGIONS_AND_NUMBERS = None
    OKTMO_REGIONS_AND_NUMBERS = None
    OKATO_FIRST_8_DIGITS = None
    OKTMO_FIRST_8_DIGITS = None
    OKATO_OKTMO_REGIONS_AND_NUMBERS = None

    NAMES = None
    MALE_NAMES = None
    FEMALE_NAMES = None

    PATRONYMICS = None
    MALE_PATRONYMICS = None
    FEMALE_PATRONYMICS = None

    ADDRESS_POSTCODE_TO_LOCALITY_CODE = None
    ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME = None

    ADDRESS_GNINMB_CODES = None
    ADDRESS_SUBJECT_CODE_TO_SUBJECT_NAME = None
    ADDRESS_GNINMB_CODE_TO_CITIES = None
    ADDRESS_CITY_CODE_TO_STREET = None
    ADDRESS_STREET_CODE_TO_POSTCODE = None

    BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER = None
    CURRENCY_CODES = None
    GPB_BRANCH_BIK_789_DIGITS = None
    
    LEGAL_ENTITIES_FULL_TO_ABB = {}

    EMBOSS_NAMES = None

    @classmethod
    def load_subjects_codes(cls):
        file_path = os.path.join(cls.resources_path, 'russian_subject_codes.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            cls.SUBJECTS_CODES = [row[0] for row in csv.reader(resource_file)]

    @classmethod
    def load_departments_codes_and_names(cls):
        file_path = os.path.join(cls.resources_path, 'fms_unit.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            cls.DEPARTMENTS_CODES_AND_NAMES = {row[0]: row[1] for row in csv.reader(resource_file)}
        cls.DEPARTMENTS_CODES = list(cls.DEPARTMENTS_CODES_AND_NAMES.keys())
        cls.DEPARTMENTS_NAMES = list(cls.DEPARTMENTS_CODES_AND_NAMES.values())

    @classmethod
    def load_okado_codes(cls):
        file_path = os.path.join(cls.resources_path, 'okato.csv')
        with open(file_path, encoding='utf-8-sig') as resource_file:
            cls.OKADO_CODES = [row[0][:2] for row in csv.reader(resource_file, delimiter=',', quoting=csv.QUOTE_NONE)]

    @classmethod
    def load_subject_code_to_okado_code(cls):
        file_path = os.path.join(cls.resources_path, 'subject_code_to_okato_code.csv')
        with open(file_path, encoding='utf-8-sig') as resource_file:
            cls.SUBJECT_CODE_TO_OKADO_CODE = {
                row[0]: row[1]
                for row in csv.reader(resource_file, delimiter=',', quoting=csv.QUOTE_NONE)
            }

    @classmethod
    def load_bik_codes(cls):
        file_path = os.path.join(cls.resources_path, 'bik.csv')
        with open(file_path, encoding='utf-8-sig') as resource_file:
            cls.BIK = [row[0] for row in csv.reader(resource_file, delimiter=',', quoting=csv.QUOTE_NONE)]

    @classmethod
    def load_okved(cls):
        file_path = os.path.join(cls.resources_path, 'okved.csv')
        with open(file_path, encoding='utf-8-sig') as resource_file:
            cls.OKVED_CODES = [
                row[0] for row in csv.reader(resource_file, delimiter=';', quoting=csv.QUOTE_NONE)
                if len(row[0]) > 3
            ]

    @classmethod
    def load_names(cls):
        file_path_male = os.path.join(cls.resources_path, 'male_names.csv')
        file_path_female = os.path.join(cls.resources_path, 'female_names.csv')
        with open(file_path_male, 'r', encoding='utf-8') as resource_file:
            cls.MALE_NAMES = [row[0].upper() for row in csv.reader(resource_file)]
        with open(file_path_female, 'r', encoding='utf-8') as resource_file:
            cls.FEMALE_NAMES = [row[0].upper() for row in csv.reader(resource_file)]
        cls.NAMES = cls.MALE_NAMES + cls.FEMALE_NAMES

    @classmethod
    def load_patronymics(cls):
        file_path_male = os.path.join(cls.resources_path, 'male_patronymics.csv')
        file_path_female = os.path.join(cls.resources_path, 'female_patronymics.csv')
        with open(file_path_male, 'r', encoding='utf-8') as resource_file:
            cls.MALE_PATRONYMICS = [row[0].upper() for row in csv.reader(resource_file)]
        with open(file_path_female, 'r', encoding='utf-8') as resource_file:
            cls.FEMALE_PATRONYMICS = [row[0].upper() for row in csv.reader(resource_file)]
        cls.PATRONYMICS = cls.MALE_PATRONYMICS + cls.FEMALE_PATRONYMICS

    @classmethod
    def load_postcodes(cls):
        file_path = os.path.join(cls.resources_path, 'address_postcode_to_localities_codes.csv')
        cls.ADDRESS_POSTCODE_TO_LOCALITY_CODE = defaultdict(list)
        with open(file_path, 'r', encoding='utf-8') as resource_file:
            for row in csv.reader(resource_file):
                cls.ADDRESS_POSTCODE_TO_LOCALITY_CODE[row[0]].append(row[1])

    @classmethod
    def load_localities_codes_and_name(cls):
        file_path = os.path.join(cls.resources_path, 'address_locality_code_to_locality_name.csv')
        cls.ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME = {}
        with open(file_path, 'r', encoding='utf-8') as resource_file:
            for row in csv.reader(resource_file):
                cls.ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME[row[0]] = row[1]

    @classmethod
    def load_address_resources(cls):
        file_path = os.path.join(cls.resources_path, 'address_subject_code_to_subject_name.csv')
        with open(file_path, encoding='utf-8-sig') as resource_file:
            cls.ADDRESS_SUBJECT_CODE_TO_SUBJECT_NAME = {
                row[0]: row[1] for row in csv.reader(resource_file)
            }

        file_path = os.path.join(cls.resources_path, 'address_gninmb_code_to_city.csv')
        cls.ADDRESS_GNINMB_CODES = []
        cls.ADDRESS_GNINMB_CODE_TO_CITIES = defaultdict(list)
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.ADDRESS_GNINMB_CODES.append(row[0])
                cls.ADDRESS_GNINMB_CODE_TO_CITIES[row[0]] += [[row[2], row[3]]]

        file_path = os.path.join(cls.resources_path, 'address_street_code_and_socr_and_name.csv')
        cls.ADDRESS_CITY_CODE_TO_STREET = defaultdict(list)
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.ADDRESS_CITY_CODE_TO_STREET[row[0][:13]] += [[row[0], row[1], row[2]]]

        file_path = os.path.join(cls.resources_path, 'address_street_code_to_postcode.csv')
        cls.ADDRESS_STREET_CODE_TO_POSTCODE = {}
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.ADDRESS_STREET_CODE_TO_POSTCODE[row[0][:17]] = row[1]

    @classmethod
    def load_balance_sheet_accounts_of_second_order(cls):
        file_path = os.path.join(cls.resources_path, 'balance_sheet_accounts_of_second_order.csv')
        cls.BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER = []
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER.append(row[0])

    @classmethod
    def load_currency_codes(cls):
        file_path = os.path.join(cls.resources_path, 'currency_codes.csv')
        cls.CURRENCY_CODES = []
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.CURRENCY_CODES.append(row[0])

    @classmethod
    def load_gpb_branch_bik_789_digits(cls):
        file_path = os.path.join(cls.resources_path, 'gpb_branch_bik_789_digits.csv')
        cls.GPB_BRANCH_BIK_789_DIGITS = []
        with open(file_path, encoding='utf-8-sig') as resource_file:
            for row in csv.reader(resource_file):
                cls.GPB_BRANCH_BIK_789_DIGITS.append(row[0])

    @classmethod
    def load_legal_entities_full_to_abb(cls):
        file_path = os.path.join(cls.resources_path, 'legal_entities_full_to_abb.csv')
        for row in csv.reader(open(file_path, 'r', encoding='utf-8')):
            cls.LEGAL_ENTITIES_FULL_TO_ABB[row[0]] = row[1]
        if not cls.LEGAL_ENTITIES_FULL_TO_ABB:
            raise Exception("Failed to load legal_entities_full_to_abb.csv")
            
    @classmethod
    def get_legal_entities_full_to_abb_dict(cls) -> dict:
        if not cls.LEGAL_ENTITIES_FULL_TO_ABB:
            cls.load_legal_entities_full_to_abb()
        return cls.LEGAL_ENTITIES_FULL_TO_ABB

    @classmethod
    def load_emboss_names(cls):
        file_path = os.path.join(cls.resources_path, 'emboss_names.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            cls.EMBOSS_NAMES = [row[0] for row in csv.reader(resource_file)]

    @classmethod
    def load_bin_gpb_codes(cls):
        cls.BIN_GPB = list()
        file_path = os.path.join(cls.resources_path, 'bin_gpb.csv')
        for row in csv.reader(open(file_path, 'r', encoding='utf-8')):
            cls.BIN_GPB.append(row[0])
        if not cls.BIN_GPB:
            raise Exception("Failed to load bin_gpb.csv")

    @classmethod
    def get_bin_gpb_codes(cls) -> list:
        if not cls.BIN_GPB:
            cls.load_bin_gpb_codes()
        return cls.BIN_GPB

    @classmethod
    def load_okato_regions(cls):
        cls.OKATO_REGIONS_AND_NUMBERS = {}
        file_path = os.path.join(cls.resources_path, 'okato_oktmo_cod.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            reader = csv.DictReader(resource_file)
            for data in reader:
                cls.OKATO_REGIONS_AND_NUMBERS.setdefault(data['cod'], []).append(data['okato'])

    @classmethod
    def load_oktmo_regions(cls):
        cls.OKTMO_REGIONS_AND_NUMBERS = {}
        file_path = os.path.join(cls.resources_path, 'okato_oktmo_cod.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            reader = csv.DictReader(resource_file)
            for data in reader:
                cls.OKTMO_REGIONS_AND_NUMBERS.setdefault(data['cod'], []).append(data['oktmo'])

    @classmethod
    def load_okato_first_8_digits(cls):
        file_path = os.path.join(cls.resources_path, 'okato_first_8_digits.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            cls.OKATO_FIRST_8_DIGITS = [row[0] for row in csv.reader(resource_file)]

    @classmethod
    def load_oktmo_first_8_digits(cls):
        file_path = os.path.join(cls.resources_path, 'oktmo_first_8_digits.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            cls.OKTMO_FIRST_8_DIGITS = [row[0] for row in csv.reader(resource_file)]

    @classmethod
    def load_okato_oktmo_regions(cls):
        cls.OKATO_OKTMO_REGIONS_AND_NUMBERS = {}
        file_path = os.path.join(cls.resources_path, 'okato_oktmo_cod.csv')
        with open(file_path, encoding='utf-8') as resource_file:
            reader = csv.DictReader(resource_file)
            for data in reader:
                row_list = []
                row_list.append(data['okato'])
                row_list.append(data['oktmo'])
                cls.OKATO_OKTMO_REGIONS_AND_NUMBERS.setdefault(data['cod'], []).append(row_list)
