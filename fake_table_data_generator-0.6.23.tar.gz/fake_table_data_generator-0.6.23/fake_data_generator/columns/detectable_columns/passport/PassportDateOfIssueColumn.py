from typing import Dict, Optional, Tuple, Union
from datetime import date, datetime
from dateutil.relativedelta import relativedelta

import numpy as np
import pandas as pd

from .. import AbstractDependentDetectableColumn
from ....data_types import String, Varchar, Char, Date, Timestamp
from .PassportSeriesAndNumberColumn import PassportSeriesAndNumberColumn
from ..datetime_functions import (
    DATE_FORMATS,
    does_satisfy_format,
    generate_random_timestamp,
)


class PassportDateOfIssueColumn(AbstractDependentDetectableColumn):
    CLASS_NAME = "PASSPORT_DATE_OF_ISSUE"
    RECOGNITION_THRESHOLD = 0.7
    DEFAULT_FORMATS = None
    FORMATS = DATE_FORMATS
    types = (String, Varchar, Char, Date, Timestamp)

    DEPENDENCIES_CLASSES = (
        PassportSeriesAndNumberColumn,
    )

    START_DATE_OF_ISSUE = pd.Timestamp(1997, 1, 1)

    def generate_data(self, output_size: int) -> pd.Series:
        return pd.Series([None] * output_size)

    def get_year_of_issue(
            self,
            date_of_issue,
    ) -> int:
        if isinstance(date_of_issue, str):
            for date_format in self.formats:
                try:
                    return datetime.strptime(date_of_issue, date_format).year
                except ValueError:
                    continue
            raise ValueError(f"{date_of_issue} does not match any format")
        elif isinstance(date_of_issue, date):
            return date_of_issue.year

    def generate_date_of_issue(
            self,
            date_of_birth_dt: date,
    ) -> Union[str, pd.Timestamp, None]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if date_of_birth_dt is None:
                random_date_of_issue = generate_random_timestamp(
                    start_timestamp=self.START_DATE_OF_ISSUE,
                    end_timestamp=pd.Timestamp.now(),
                )
            else:
                age = (date.today() - date_of_birth_dt).days // 365
                if 14 <= age <= 44:
                    start_timestamp = max(
                        self.START_DATE_OF_ISSUE,
                        pd.to_datetime(date_of_birth_dt) + relativedelta(years=14),
                    )
                elif age > 45:
                    start_timestamp = max(
                        self.START_DATE_OF_ISSUE,
                        pd.to_datetime(date_of_birth_dt) + relativedelta(years=45),
                    )
                else:
                    return None
                end_timestamp = start_timestamp + relativedelta(months=+6)
                random_date_of_issue = generate_random_timestamp(
                    start_timestamp=start_timestamp,
                    end_timestamp=end_timestamp,
                )

            if self.formats is None:
                return random_date_of_issue
            else:
                date_format = np.random.choice(self.formats, p=self.formats_probs)
                return random_date_of_issue.strftime(date_format)
        else:
            return None

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        series_and_number = values_of_other_columns[PassportSeriesAndNumberColumn.CLASS_NAME]
        if series_and_number is None:
            return False, None
        else:
            try:
                year_of_printing = int(series_and_number[2:4])
            except ValueError:
                return False, None
            if isinstance(value, date):
                return (value.year % 100) in [year_of_printing, (year_of_printing + 1) % 100], None
            elif isinstance(value, str):
                for frmt in cls.FORMATS:
                    if (does_satisfy_format(value, frmt)
                            and (datetime.strptime(value, frmt).year % 100) in [year_of_printing, (year_of_printing + 1) % 100]):
                        return True, frmt
                    else:
                        return False, None
                return False, None
