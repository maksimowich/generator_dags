from typing import List

import pandas as pd

from ... import Column
from ..AbstractComprehensiveColumns import AbstractComprehensiveColumns
from ..DateOfBirthColumn import DateOfBirthColumn
from .PassportDateOfIssueColumn import PassportDateOfIssueColumn
from .PassportDepartmentCodeColumn import PassportDepartmentCodeColumn
from .PassportDepartmentNameColumn import PassportDepartmentNameColumn
from .PassportSeriesAndNumberColumn import PassportSeriesAndNumberColumn


class PassportColumns(AbstractComprehensiveColumns):
    CLASS_NAME = 'PASSPORT'

    SINGLE_COLUMN_CLASSES = (
        PassportDateOfIssueColumn,
        PassportDepartmentCodeColumn,
        PassportDepartmentNameColumn,
        PassportSeriesAndNumberColumn,
    )

    def generate_row(
            self,
            date_of_birth=None,
            mix_columns_indexes: List[int] = None,
    ) -> List:
        passport_date_of_issue = None
        passport_department_code = None
        passport_department_name = None
        passport_series_and_number = None

        if self.passport_department_code_column:
            passport_department_code = self.passport_department_code_column.generate_department_code()

        if self.passport_department_name_column:
            passport_department_name = self.passport_department_name_column.generate_department_name(
                department_code=passport_department_code,
            )

        if self.passport_date_of_issue_column:
            if date_of_birth is not None:
                date_of_birth_dt = DateOfBirthColumn.get_date_of_birth_as_dt(
                    date_of_birth=date_of_birth,
                )
            else:
                date_of_birth_dt = None
            passport_date_of_issue = self.passport_date_of_issue_column.generate_date_of_issue(
                date_of_birth_dt=date_of_birth_dt,
            )

        if self.passport_series_and_number_column:
            if passport_date_of_issue is not None:
                year_of_issue = self.passport_date_of_issue_column.get_year_of_issue(
                    date_of_issue=passport_date_of_issue,
                )
            else:
                year_of_issue = None
            if passport_department_code is not None:
                subject_code = passport_department_code[:2]
            else:
                subject_code = None
            passport_series_and_number = self.passport_series_and_number_column.generate_series_and_number(
                year_of_issue=year_of_issue,
                subject_code=subject_code,
            )

        unsorted_row = [
            (passport_date_of_issue, self.passport_date_of_issue_index),
            (passport_department_code, self.passport_department_code_index),
            (passport_department_name, self.passport_department_name_index),
            (passport_series_and_number, self.passport_series_and_number_index),
        ]

        return self.replace_values_with_mix_and_get_sorted_row(
            unsorted_row=unsorted_row,
            mix_columns_indexes=mix_columns_indexes
        )

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            mix_columns_names
    ) -> pd.DataFrame:
        mix_columns_indexes = self.get_indexes_by_columns_names(mix_columns_names)
        date_of_birth_col = generated_data.get(DateOfBirthColumn.CLASS_NAME)
        data = [
            self.generate_row(
                date_of_birth=date_of_birth_col[i] if date_of_birth_col is not None else None,
                mix_columns_indexes=mix_columns_indexes,
            )
            for i in range(output_size)
        ]
        return pd.DataFrame(data)

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
    ):
        self.passport_date_of_issue_column = None
        self.passport_department_code_column = None
        self.passport_department_name_column = None
        self.passport_series_and_number_column = None

        self.passport_date_of_issue_index = None
        self.passport_department_code_index = None
        self.passport_department_name_index = None
        self.passport_series_and_number_index = None

        super().__init__(algorithm_name, columns)
