from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class PassportDepartmentCodeColumn(AbstractDetectableColumn):
    CLASS_NAME = "PASSPORT_DEPARTMENT_CODE"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    def generate_department_code(self):
        if ResourceLoader.DEPARTMENTS_CODES_AND_NAMES is None:
            ResourceLoader.load_departments_codes_and_names()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            return np.random.choice(ResourceLoader.DEPARTMENTS_CODES)
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_department_codes = []
        for _ in range(output_size):
            fake_department_codes.append(self.generate_department_code())
        return pd.Series(fake_department_codes)

    @classmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.SUBJECTS_CODES is None:
            ResourceLoader.load_subjects_codes()
        if (len(value) == 7
                and value[0:2] in ResourceLoader.SUBJECTS_CODES
                and re.match(r'[0-3]-\b(?!000)\d{3}\b', value[2:])):
            return True, None
        else:
            return False, None
