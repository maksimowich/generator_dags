from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class PassportDepartmentNameColumn(AbstractDetectableColumn):
    CLASS_NAME = "PASSPORT_DEPARTMENT_NAME"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    BODY_TYPES = ["ОВД", "РОВД", "МВД", "УВД", "ГУВД", "ГУ МВД", "УФМС", "ОМ"]

    def generate_department_name(
            self,
            department_code: str = None,
    ):
        if ResourceLoader.DEPARTMENTS_CODES_AND_NAMES is None:
            ResourceLoader.load_departments_codes_and_names()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if department_code is None:
                return np.random.choice(ResourceLoader.DEPARTMENTS_NAMES)
            else:
                return ResourceLoader.DEPARTMENTS_CODES_AND_NAMES[department_code]
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_department_names = []
        for _ in range(output_size):
            fake_department_names.append(self.generate_department_name())
        return pd.Series(fake_department_names)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if (any(body_type in value for body_type in cls.BODY_TYPES)
                and re.match(r'[А-ЯЁ. №0-9-]+$', value)):
            return True, None
        else:
            return False, None
