from typing import Dict, Optional, Tuple
from random import randint

import numpy as np
import pandas as pd

from .. import AbstractDetectableColumn
from ....data_types import String, Varchar, Char
from ..resource_loader import ResourceLoader


class PassportSeriesAndNumberColumn(AbstractDetectableColumn):
    CLASS_NAME = "PASSPORT_SERIES_AND_NUMBER"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = [
        'space',
    ]
    FORMATS = [
        'space',
        'not_separated',
    ]
    MAPPING = {
        'space': ' ',
        'not_separated': ''
    }
    types = (String, Varchar, Char)

    def generate_series_and_number(
            self,
            year_of_issue: int = None,
            subject_code: str = None,
    ):
        if ResourceLoader.OKADO_CODES is None:
            ResourceLoader.load_okado_codes()
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if subject_code is None:
                okado_code = np.random.choice(ResourceLoader.OKADO_CODES)
            else:
                if ResourceLoader.SUBJECT_CODE_TO_OKADO_CODE is None:
                    ResourceLoader.load_subject_code_to_okado_code()
                okado_code = ResourceLoader.SUBJECT_CODE_TO_OKADO_CODE.get(subject_code)
            if year_of_issue is None:
                year_of_issue = str(np.random.choice([randint(97, 99), randint(0, 24)])).zfill(2)
            else:
                year_of_issue = str(year_of_issue % 100).zfill(2)
            number = str(randint(111, 999999)).zfill(6)
            separator = self.MAPPING[np.random.choice(self.formats, p=self.formats_probs)]
            return f'{okado_code}{year_of_issue}{separator}{number}'
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_series_and_numbers = []
        for _ in range(output_size):
            fake_series_and_numbers.append(self.generate_series_and_number())
        return pd.Series(fake_series_and_numbers)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.OKADO_CODES is None:
            ResourceLoader.load_okado_codes()
        string_without_spaces = value.replace(" ", "")
        if (len(string_without_spaces) != 10
                or len(value) not in [10, 11]
                or not string_without_spaces.isdigit()
                or string_without_spaces[:2] not in ResourceLoader.OKADO_CODES
                or not ((97 <= int(string_without_spaces[2:4]) <= 99) or (0 <= int(string_without_spaces[2:4]) <= 24))
                or not (101 <= int(string_without_spaces[-6:]) <= 999999)):
            return False, None
        elif len(value) == 11 and value[4] == ' ':
            return True, 'space'
        elif len(value) == 10:
            return True, 'not_separated'
        else:
            return False, None
