from typing import Dict, Optional, Tuple
import random
import re

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char
from .resource_loader import ResourceLoader


def choose_random_list(list_of_lists):
    random_index = random.randint(0, len(list_of_lists) - 1)
    return list_of_lists[random_index]


class AddressOneStringColumn(AbstractDetectableColumn):
    CLASS_NAME = "ADDRESS_ONE_STRING"
    RECOGNITION_THRESHOLD = 0.7
    types = (String, Varchar, Char)

    def generate_address(self):
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if ResourceLoader.ADDRESS_GNINMB_CODES is None:
                ResourceLoader.load_address_resources()
            gninmb = np.random.choice(ResourceLoader.ADDRESS_GNINMB_CODES)
            subject_name = ResourceLoader.ADDRESS_SUBJECT_CODE_TO_SUBJECT_NAME[gninmb[:2]]
            city_name, city_code = choose_random_list(ResourceLoader.ADDRESS_GNINMB_CODE_TO_CITIES[gninmb])
            street_code, street_type, street_name = choose_random_list(ResourceLoader.ADDRESS_CITY_CODE_TO_STREET[city_code])
            postcode = ResourceLoader.ADDRESS_STREET_CODE_TO_POSTCODE.get(street_code)
            house = str(random.randint(1, 10))
            flat = f"кв. {random.randint(1, 20)}"
            return f"{postcode}, {subject_name}, г. {city_name}, {street_type}. {street_name}, {house}, {flat}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_addresses = [self.generate_address() for _ in range(output_size)]
        return pd.Series(fake_addresses)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        potential_postcode = re.findall(r"\d{6}", value)
        if len(potential_postcode) != 1:
            return False, None
        postcode = potential_postcode[0]

        if ResourceLoader.ADDRESS_POSTCODE_TO_LOCALITY_CODE is None:
            ResourceLoader.load_postcodes()
        localities_codes = ResourceLoader.ADDRESS_POSTCODE_TO_LOCALITY_CODE.get(postcode)
        if localities_codes is None:
            return False, None

        subject_code = f"{localities_codes[0][:2]}00000000000"

        if ResourceLoader.ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME is None:
            ResourceLoader.load_localities_codes_and_name()
        localities_names = []
        for locality_code in localities_codes:
            localities_name = ResourceLoader.ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME.get(locality_code)
            if localities_name is not None:
                localities_names.append(re.sub(r'[^а-яА-Я]', '', localities_name))
        if len(localities_names) == 0:
            return False, None

        subject_name = re.sub(r'[^а-яА-Я]', '', ResourceLoader.ADDRESS_LOCALITY_CODE_TO_LOCALITY_NAME.get(subject_code))
        value_in_lower_case = re.sub(r'[^а-я]', '', value.lower())

        if (any(locality_name.lower() in value_in_lower_case for locality_name in localities_names)
                and subject_name.lower() in value_in_lower_case):
            return True, None
        else:
            return False, None
