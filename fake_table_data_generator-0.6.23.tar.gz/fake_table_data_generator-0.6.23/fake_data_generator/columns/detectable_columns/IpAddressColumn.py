from typing import Dict, Optional, Tuple
import random

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char


class IpAddressColumn(AbstractDetectableColumn):
    CLASS_NAME = "IP_ADDRESS"
    RECOGNITION_THRESHOLD = 1.0
    types = (String, Varchar, Char)

    def generate_data(self, output_size: int) -> pd.Series:
        fake_ip_address = []
        for _ in range(output_size):
            if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
                ip_address = f"{str(random.randint(0, 255))}.{str(random.randint(0, 255))}." \
                             f"{str(random.randint(0, 255))}.{str(random.randint(0, 255))}"
            else:
                ip_address = None
            fake_ip_address.append(ip_address)
        return pd.Series(fake_ip_address)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if (value.count('.') != 3
                or not all(char.isdigit() or char == '.' for char in value)):
            return False, None
        else:
            return max(map(int, value.split('.'))) < 256, None
