from abc import ABCMeta, abstractmethod
from typing import Dict, List, Optional, Tuple, Type, Union

from faker import Faker
from pandas import Series

from ..ColumnWithMix import ColumnWithMix
from ...data_types import DataType
from ..CategoricalColumn import CategoricalColumn
from ..MixedColumn import MixedColumn


class AbstractDetectableColumn(ColumnWithMix, metaclass=ABCMeta):
    RECOGNITION_THRESHOLD: float = None
    DEFAULT_FORMATS: List[str] = None
    FORMATS: Union[Dict, List] = None
    types: Tuple[Type[DataType]] = None

    faker_en = Faker()
    faker_ru = Faker('ru_RU')

    @abstractmethod
    def generate_data(
            self,
            output_size: int,
    ) -> Series:
        pass

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str, None] = None,
            null_ratio: Optional[float] = 0,
            format_: Dict[str, float] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            mix=mix,
        )
        if null_ratio is None:
            null_ratio = 0
        self.null_ratio = null_ratio
        self.not_null_ratio = 1 - self.null_ratio
        if format_ is None and self.DEFAULT_FORMATS is not None:
            self.formats, self.formats_probs = CategoricalColumn.get_values_and_probabilities(
                column_values=Series(self.DEFAULT_FORMATS)
            )
        elif format_ is not None:
            self.formats = list(format_.keys())
            self.formats_probs = list(format_.values())
        else:
            self.formats = None
            self.formats_probs = None

    @classmethod
    @abstractmethod
    def does_match_class(
            cls,
            value,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        pass

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name]["null_ratio"] = self.null_ratio
        if self.formats:
            super_dict[self.column_name]["format"] = {
                frmt: prob
                for frmt, prob in zip(self.formats, self.formats_probs)
            }
        self.set_mix_to_end(super_dict)
        return super_dict
