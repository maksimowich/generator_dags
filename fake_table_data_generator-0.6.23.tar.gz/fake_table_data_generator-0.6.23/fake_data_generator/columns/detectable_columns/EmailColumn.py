from typing import Dict, Optional, Tuple
import re

import numpy as np
import pandas as pd
from rstr import xeger

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char


class EmailColumn(AbstractDetectableColumn):
    CLASS_NAME = "EMAIL"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = [
        'gmail.com',
        'mail.ru',
        'yandex.ru',
        'yahoomail.com',
        'outlook.com',
    ]
    types = (String, Varchar, Char)

    REGEX_FOR_EMAIL = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    REGEX_FOR_LOCAL_PART = "^-[a-zA-Z][a-zA-Z0-9-]{2,20}[a-z0-9]{0,3}@"

    def generate_email(self):
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            domain = np.random.choice(self.formats, p=self.formats_probs)
            return f"{self.faker_en.word()}{xeger(self.REGEX_FOR_LOCAL_PART)}{domain}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_emails = [self.generate_email() for _ in range(output_size)]
        return pd.Series(fake_emails)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if bool(re.match(cls.REGEX_FOR_EMAIL, value)):
            return True, value.split('@')[-1]
        else:
            return False, None
