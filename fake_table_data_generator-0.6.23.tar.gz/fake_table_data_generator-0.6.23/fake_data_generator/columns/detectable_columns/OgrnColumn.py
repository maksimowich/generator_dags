from typing import Dict, Optional, Tuple
from datetime import date
import random

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char
from .resource_loader import ResourceLoader


class OGRNColumn(AbstractDetectableColumn):
    CLASS_NAME = "OGRN"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = [
        "ogrn",
    ]
    types = (String, Varchar, Char)

    CURRENT_YEAR = date.today().year % 100
    FIRST_NUMBERS_OGRN = ["1", "5"]
    FIRST_NUMBERS_OGRNIP = "3"

    def generate_ogrn(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            if ResourceLoader.SUBJECTS_CODES is None:
                ResourceLoader.load_subjects_codes()
            year_of_issue = str(random.randrange(2, self.CURRENT_YEAR)).zfill(2)
            subject_code = np.random.choice(ResourceLoader.SUBJECTS_CODES)
            ogrn_type = np.random.choice(self.formats, p=self.formats_probs)
            if ogrn_type == 'ogrn':
                first_number = random.choice(self.FIRST_NUMBERS_OGRN)
                egryul_number = str(random.randrange(11111, 9999999)).zfill(7)
                orgn_except_check_number = f"{first_number}{year_of_issue}{subject_code}{egryul_number}"
                check_number = str(int(orgn_except_check_number) % 11 % 10)
                return f"{orgn_except_check_number}{check_number}"
            elif ogrn_type == 'ogrnip':
                first_number = self.FIRST_NUMBERS_OGRNIP
                egryul_number = str(random.randrange(111111111, 999999999)).zfill(9)
                orgnip_except_check_number = f"{first_number}{year_of_issue}{subject_code}{egryul_number}"
                check_number = str(int(orgnip_except_check_number) % 13 % 10)
                return f"{orgnip_except_check_number}{check_number}"
            else:
                raise ValueError(f"unsupported format '{ogrn_type}' for OGRNColumn")
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_ogrn = [self.generate_ogrn() for _ in range(output_size)]
        return pd.Series(fake_ogrn)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.SUBJECTS_CODES is None:
            ResourceLoader.load_subjects_codes()
        if (len(value) == 13
                and value[0] in ['1', '5']
                and value.isdigit()
                and int(str(date.today().year)[2:4]) >= int(value[1:3]) >= 2
                and value[3:5] in ResourceLoader.SUBJECTS_CODES
                and value[5:12] != "0000000"
                and int(value[0:12]) % 11 % 10 == int(value[-1])):
            return True, 'ogrn'
        elif (len(value) == 15
                and value[0] == '3'
                and value.isdigit()
                and int(str(date.today().year)[2:4]) >= int(value[1:3]) >= 2
                and value[3:5] in ResourceLoader.SUBJECTS_CODES
                and value[5:7] != "00"
                and value[7:14] != "0000000"
                and int(value[0:14]) % 13 % 10 == int(value[-1])):
            return True, 'ogrnip'
        else:
            return False, None
