from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char
from .resource_loader import ResourceLoader


class BIKColumn(AbstractDetectableColumn):
    CLASS_NAME = "BIK"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)

    def generate_data(self, output_size: int) -> pd.Series:
        if ResourceLoader.BIK is None:
            ResourceLoader.load_bik_codes()
        fake_biks = []
        for _ in range(output_size):
            if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
                bik = np.random.choice(ResourceLoader.BIK)
            else:
                bik = None
            fake_biks.append(bik)
        return pd.Series(fake_biks)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if ResourceLoader.OKADO_CODES is None:
            ResourceLoader.load_okado_codes()
        if (len(value) != 9
                or not value.isdigit()
                or value[:2] != '04'
                or (value[2:4] not in ResourceLoader.OKADO_CODES and value[2:4] != '00')
                or value[4:6] == '00'):
            return False, None
        else:
            return True, None
