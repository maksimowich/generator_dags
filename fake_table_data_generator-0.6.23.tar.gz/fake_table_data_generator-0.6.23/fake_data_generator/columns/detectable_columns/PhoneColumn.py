from typing import Dict, Optional, Tuple, Union
import re

import numpy as np
import pandas as pd
from rstr import xeger

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import DataType, String, Varchar, Char
from ..MixedColumn import MixedColumn


class PhoneColumn(AbstractDetectableColumn):
    CLASS_NAME = "PHONE"
    RECOGNITION_THRESHOLD = 0.9
    DEFAULT_FORMATS = [
        "+7(XXX)XXXXXXX",
        "+7-(XXX)-XXXXXXX",
        "8XXXXXXXXXX",
    ]
    types = (String, Varchar, Char)

    REGEX_FOR_PHONE_DIGITS = r'^(?:7|8)[0-9]{10}$'

    def generate_phone(self):
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            frmt_regex = np.random.choice(self.formats_regex, p=self.formats_probs)
            return xeger(frmt_regex)
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_phones = [self.generate_phone() for _ in range(output_size)]
        return pd.Series(fake_phones)

    @staticmethod
    def extract_format(
            value: str,
    ):
        result_format = ''
        digit_index = 0
        for char in value:
            if char in ['+', ' ', '-', '(', ')']:
                result_format += char
            elif char.isdigit() and digit_index in [0, 1, 2, 3]:
                result_format += char
                digit_index += 1
            elif char.isdigit():
                result_format += 'X'
                digit_index += 1
            else:
                return None
        return result_format

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        phone_digits = re.sub(r'\D', '', value)
        if re.match(cls.REGEX_FOR_PHONE_DIGITS, phone_digits):
            frmt = cls.extract_format(value)
            if frmt:
                return True, frmt
            else:
                return False, None
        else:
            return False, None

    @staticmethod
    def get_regex_by_format(
            frmt: str,
    ):
        result_regex = r''
        for char in frmt:
            if char in ['+', '(', ')']:
                result_regex += f'\\{char}'
            elif char in [' ', '-'] or char.isdigit():
                result_regex += char
            elif char in ['X']:
                result_regex += '\\d'
            else:
                raise ValueError
        return result_regex

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            null_ratio: float = 0,
            format_: Dict[str, float] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            null_ratio=null_ratio,
            format_=format_,
            mix=mix,
        )
        self.formats_regex = [self.get_regex_by_format(frmt) for frmt in self.formats]
