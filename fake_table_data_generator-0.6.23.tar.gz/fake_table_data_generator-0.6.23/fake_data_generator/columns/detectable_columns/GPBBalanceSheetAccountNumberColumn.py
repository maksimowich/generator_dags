from typing import Dict, Optional, Tuple, Union
import random
import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import DataType, String, Varchar, Char
from ..MixedColumn import MixedColumn
from .resource_loader import ResourceLoader

if ResourceLoader.BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER is None:
    ResourceLoader.load_balance_sheet_accounts_of_second_order()
    ResourceLoader.load_currency_codes()


class GPBBalanceSheetAccountNumberColumn(AbstractDetectableColumn):
    CLASS_NAME = "GPB_BALANCE_SHEET_ACCOUNT_NUMBER"
    RECOGNITION_THRESHOLD = 0.9
    types = (String, Varchar, Char)
    
    DEFAULT_FORMATS = [
        random.choice(ResourceLoader.BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER) + random.choice(ResourceLoader.CURRENCY_CODES) for _ in range(10)
    ]

    COEFFICIENTS = [7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1, 3, 7, 1]
    BIK_789_DIGITS_OF_HEAD_OFFICE = "823"
 
    @classmethod
    def compute_check_number(cls, value: str) -> int:
        digits: str = cls.BIK_789_DIGITS_OF_HEAD_OFFICE + value
        return sum((int(digit) * coef) % 10 for digit, coef in zip(digits, cls.COEFFICIENTS)) % 10 * 3 % 10

    def generate_gpb_balance_sheet_account_number(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            account_second_order_code = np.random.choice(self.second_order_codes, p=self.formats_probs)
            number_1 = str(random.randint(0, 9999)).zfill(4)
            number_2 = str(random.randint(1, 9999999)).zfill(7)
            gpb_balance_sheet_account_number = f"{account_second_order_code}0{number_1}{number_2}"
            check_number = self.compute_check_number(gpb_balance_sheet_account_number)
            return f"{account_second_order_code}{check_number}{number_1}{number_2}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_numbers = [self.generate_gpb_balance_sheet_account_number() for _ in range(output_size)]
        return pd.Series(fake_numbers)

    @classmethod
    def is_check_number_correct(cls, value) -> bool:
        for gpb_branch_bik in ResourceLoader.GPB_BRANCH_BIK_789_DIGITS:
            check_number = sum((int(digit) * coef) % 10 for digit, coef in zip(gpb_branch_bik + value, cls.COEFFICIENTS)) % 10
            if check_number == 0:
                return True
        return False

    @classmethod
    def extract_format(cls, match: bool, value: str):
        if match:
            return value[: 8]
        else:
            return None

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if (len(value) != 20
                or not value.isdigit()):
            return False, None
        if value[:5] not in ResourceLoader.BALANCE_SHEET_ACCOUNTS_OF_SECOND_ORDER:
            return False, None
        if value[5:8] not in ResourceLoader.CURRENCY_CODES:
            return False, None
        if ResourceLoader.GPB_BRANCH_BIK_789_DIGITS is None:
            ResourceLoader.load_gpb_branch_bik_789_digits()
        match = cls.is_check_number_correct(value) 
        return match, cls.extract_format(match ,value)
    
    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            null_ratio: float = 0,
            format_: Dict[str, float] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            null_ratio=null_ratio,
            format_=format_,
            mix=mix,
        )
        self.second_order_codes = [frmt for frmt in self.formats]
