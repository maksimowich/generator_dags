from typing import Dict, Optional, Tuple
import random

import numpy as np
import pandas as pd

from .AbstractDetectableColumn import AbstractDetectableColumn
from ...data_types import String, Varchar, Char


class SNILSColumn(AbstractDetectableColumn):
    CLASS_NAME = "SNILS"
    RECOGNITION_THRESHOLD = 0.95
    DIGITS = [str(i) for i in range(10)]
    types = (String, Varchar, Char)

    @staticmethod
    def get_check_number(
            string: str,
    ) -> str:
        check_sum = sum(
            map(
                lambda x: int(x[0]) * x[1],
                zip(string[0:9], list(range(9, 0, -1)))
            )
        )
        if check_sum < 100:
            return str(check_sum)
        elif check_sum in [100, 101]:
            return '00'
        else:
            return str((check_sum % 101) % 100).zfill(2)

    def generate_snils(self) -> Optional[str]:
        if np.random.choice([None, True], p=[self.null_ratio, self.not_null_ratio]):
            res_string = ""
            for j in range(9):
                if j == 0:
                    res_string += str(random.randint(0, 9))
                else:
                    prev_digit = int(res_string[j - 1])
                    res_string += random.choice(self.DIGITS[:prev_digit] + self.DIGITS[prev_digit + 1:])
            check_number = self.get_check_number(res_string)
            return f"{res_string}{check_number}"
        else:
            return None

    def generate_data(self, output_size: int) -> pd.Series:
        fake_snils = [self.generate_snils() for _ in range(output_size)]
        return pd.Series(fake_snils)

    @classmethod
    def does_match_class(
            cls,
            value: str,
            values_of_other_columns: Dict = None,
    ) -> Tuple[bool, Optional[str]]:
        if len(value) != 11 or not value.isdigit():
            return False, None
        check_number = cls.get_check_number(value)
        if check_number == value[9:12]:
            return True, None
        else:
            return False, None
