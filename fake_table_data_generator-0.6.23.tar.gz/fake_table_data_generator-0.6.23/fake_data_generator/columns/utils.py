from typing import List, Optional

from .Column import Column
from .MultipleColumns import MultipleColumns
from .Pattern import Pattern
from .id_columns import ID_COLUMNS


def get_pattern_by_name(
        patterns: List[Pattern],
        pattern_name: str,
) -> Optional[Pattern]:
    for pattern in patterns:
        if pattern.get_pattern_name() == pattern_name:
            return pattern


def get_columns_names(
        patterns: List[Pattern],
) -> List[str]:
    columns_names = []
    for pattern in patterns:
        if isinstance(pattern, Column):
            columns_names.append(pattern.get_column_name())
        elif isinstance(pattern, MultipleColumns):
            columns_names += pattern.get_columns_names()
    return columns_names


def get_id_pattern(
        patterns: List[Pattern],
) -> Optional[Column]:
    for pattern in patterns:
        if type(pattern) in ID_COLUMNS:
            return pattern


def get_defined_patterns(
        patterns: List[Pattern],
) -> List[Pattern]:
    return [
        pattern for pattern in patterns
        if not pattern.is_predefined_pattern()
    ]
