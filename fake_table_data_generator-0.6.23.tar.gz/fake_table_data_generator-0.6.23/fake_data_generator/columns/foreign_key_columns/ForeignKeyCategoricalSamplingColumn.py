from typing import List, Union
import importlib

import pandas as pd

from .FKColumn import FKColumn
from ...data_types import DataType
from ..CategoricalColumn import generate_categorical_data


class ForeignKeyCategoricalSamplingColumn(FKColumn):
    CLASS_NAME = "FOREIGN_KEY_CATEGORICAL_SAMPLING"

    def __init__(
            self,
            column_name: str,
            data_type: Union[DataType, str],
            foreign_key_table_name: str,
            foreign_key_column_name: str,
            values: List[object],
            probabilities: List[float],
            fk_constraint: bool = False,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            foreign_key_table_name=foreign_key_table_name,
            foreign_key_column_name=foreign_key_column_name,
            fk_constraint=fk_constraint,
        )
        self.values = values
        self.probabilities = probabilities

    def generate_data(self, output_size: int) -> pd.Series:
        return generate_categorical_data(
            values=self.values,
            probabilities=self.probabilities,
            output_size=output_size,
        )

    @staticmethod
    def get_values_and_probabilities(
            engine,
            table_name: str,
            column_name: str,
            id_mapping: dict,
    ):
        sql_query = f'''
        SELECT
            {column_name},
            COUNT(*) * 1.0 / SUM(COUNT(*)) OVER () AS probability
        FROM {table_name}
        GROUP BY {column_name};
        '''

        sqlalchemy = importlib.import_module("sqlalchemy")
        with engine.begin() as conn:
            res = conn.execute(sqlalchemy.text(sql_query))

        values = []
        probabilities = []
        for row in res.fetchall():
            row_value = row[0]
            row_probability = row[1]
            if row_value in id_mapping:
                values.append(id_mapping[row_value])
                probabilities.append(float(row_probability))

        return values, probabilities

    def get_as_dict(self):
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'values': self.values,
            'probabilities': self.probabilities,
        })
        return super_dict
