from abc import ABCMeta
from typing import Union

from .. import Column
from ...data_types import DataType


class FKColumn(Column, metaclass=ABCMeta):
    def __init__(
            self,
            column_name: str,
            data_type: Union[DataType, str],
            foreign_key_table_name: str,
            foreign_key_column_name: str,
            fk_constraint: bool = False,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.foreign_key_table_name = foreign_key_table_name
        self.foreign_key_column_name = foreign_key_column_name
        self.fk_constraint = fk_constraint

    def get_fk_table_name(self):
        return self.foreign_key_table_name

    def get_fk_column_name(self):
        return self.foreign_key_column_name

    def get_as_dict(self):
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'foreign_key_table_name': self.foreign_key_table_name,
            'foreign_key_column_name': self.foreign_key_column_name,
            'fk_constraint': self.fk_constraint
        })
        return super_dict
