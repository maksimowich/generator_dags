from typing import Union
import pandas as pd

from .FKColumn import FKColumn
from ...data_types import DataType
from ...execute_sql import execute_sql


class ForeignKeyRandomSamplingColumn(FKColumn):
    CLASS_NAME = "FOREIGN_KEY_RANDOM_SAMPLING"

    def __init__(
            self,
            column_name: str,
            data_type: Union[DataType, str],
            foreign_key_table_name: str,
            foreign_key_column_name: str,
            fk_constraint: bool = False,
            conn=None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            foreign_key_table_name=foreign_key_table_name,
            foreign_key_column_name=foreign_key_column_name,
            fk_constraint=fk_constraint,
        )
        self.conn = conn

    def generate_data(self, output_size: int) -> pd.Series:
        fk_df = execute_sql(
            conn=self.conn,
            sql_query=(
                f'SELECT {self.foreign_key_column_name} AS fk '
                f'FROM {self.foreign_key_table_name} '
                f'ORDER BY RANDOM() LIMIT {output_size}'
            )
        )
        if len(fk_df) == 0:
            return pd.Series([None] * output_size, dtype=object)
        else:
            return fk_df['fk'].sample(n=output_size, replace=True).reset_index(drop=True)
