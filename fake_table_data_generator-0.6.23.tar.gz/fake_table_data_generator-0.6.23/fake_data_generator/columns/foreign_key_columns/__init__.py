from .FKColumn import FKColumn
from .ForeignKeyCategoricalSamplingColumn import ForeignKeyCategoricalSamplingColumn
from .ForeignKeyRandomSamplingColumn import ForeignKeyRandomSamplingColumn


FK_COLUMNS = [
    ForeignKeyRandomSamplingColumn,
    ForeignKeyCategoricalSamplingColumn,
]
