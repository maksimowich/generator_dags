from typing import Union
import pandas as pd

from .IDColumn import IDColumn
from ...data_types import DataType, IntegerType
from ...execute_sql import execute_sql


class IncrementalIDColumn(IDColumn):
    CLASS_NAME = 'INCREMENTAL_ID'

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            null_ratio: float = 0,
            pk_constraint: bool = False,
            next_id: int = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            null_ratio=null_ratio,
            pk_constraint=pk_constraint,
        )
        self.next_id = next_id
        if isinstance(self.data_type, IntegerType):
            self.conversion_func = int
        else:
            self.conversion_func = str

    def set_next_id(self, table_name, conn) -> None:
        try:
            select_max_id = f"SELECT MAX({self.column_name}) AS id FROM {table_name}"
            current_max_id_df = execute_sql(conn, select_max_id)
            current_max_id = current_max_id_df['id'][0]
            if current_max_id is not None:
                self.next_id = int(current_max_id) + 1
            else:
                self.next_id = 1
        except Exception:
            self.next_id = 1

    def generate_data(self, output_size: int) -> pd.Series:
        if self.next_id is None:
            self.next_id = 1
        ids = []
        curr_id = self.next_id
        for _ in range(self.next_id, self.next_id + output_size):
            if not self.generate_null():
                ids.append(self.conversion_func(curr_id))
                curr_id += 1
            else:
                ids.append(None)
        self.next_id = curr_id
        return pd.Series(ids)
