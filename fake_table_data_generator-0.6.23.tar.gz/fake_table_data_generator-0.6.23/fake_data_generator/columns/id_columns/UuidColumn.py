from typing import Dict, Union

import pandas as pd
from uuid import uuid4

from .IDColumn import IDColumn
from ...data_types import DataType


UUID_VERSION = 4


class UuidColumn(IDColumn):
    CLASS_NAME = "UUID"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            null_ratio: float = 0,
            pk_constraint: bool = False,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            null_ratio=null_ratio,
            pk_constraint=pk_constraint,
        )
        self.uuid_version = UUID_VERSION

    def generate_data(self, output_size: int) -> pd.Series:
        uuids = [
            uuid4()
            if not self.generate_null()
            else None
            for _ in range(output_size)
        ]
        return pd.Series(uuids)

    def get_null_ratio(self) -> float:
        return self.null_ratio

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'uuid_version': self.uuid_version,
        })
        return super_dict
