from abc import ABCMeta
from typing import Dict, Union

from .. import Column
from ...data_types import DataType


class IDColumn(Column, metaclass=ABCMeta):
    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            null_ratio: float = 0,
            pk_constraint: bool = False,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.null_ratio = null_ratio
        self.not_null_ratio = 1 - self.null_ratio
        self.pk_constraint = pk_constraint

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'null_ratio': self.null_ratio,
            'pk_constraint': self.pk_constraint,
        })
        return super_dict
