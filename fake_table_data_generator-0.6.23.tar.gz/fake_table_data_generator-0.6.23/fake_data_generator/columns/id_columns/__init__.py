from .IDColumn import IDColumn
from .IncrementalIDColumn import IncrementalIDColumn
from .UuidColumn import UuidColumn

ID_COLUMNS = [
    IncrementalIDColumn,
    UuidColumn,
]
