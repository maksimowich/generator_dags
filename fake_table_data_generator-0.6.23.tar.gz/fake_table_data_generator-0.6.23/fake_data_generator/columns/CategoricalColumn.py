from typing import (
    Dict,
    List,
    Tuple,
    Union,
)
import datetime
import math
import uuid

import numpy as np
import pandas as pd

from .ColumnWithMix import ColumnWithMix
from .MixedColumn import MixedColumn
from ..data_types import DataType


def generate_categorical_data(
        values,
        probabilities,
        output_size,
) -> pd.Series:
    fake_sample = np.random.choice(
        a=values,
        p=probabilities,
        size=output_size,
    )
    fake_sample_in_series = pd.Series(
        data=fake_sample,
        dtype=object,
    )
    return fake_sample_in_series.where(fake_sample_in_series.notna(), None)


class CategoricalColumn(ColumnWithMix):
    CLASS_NAME = "CATEGORICAL"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            values: List[Union[int, float, str, pd.Timestamp, datetime.date, bool, None]] = None,
            probabilities: List[float] = None,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            mix=mix,
        )
        self.values = values
        self.probabilities = probabilities

    def generate_data(
            self,
            output_size: int,
    ) -> pd.Series:
        return generate_categorical_data(
            values=self.values,
            probabilities=self.probabilities,
            output_size=output_size,
        )

    @staticmethod
    def get_values_and_probabilities(
            column_values: pd.Series,
    ) -> Tuple[List[Union[int, float, str, pd.Timestamp, datetime.date, bool, None]], List[float]]:
        """
        Returns categorical distribution (unique values and their probabilities) for given values.

        Parameters:
        -----------
        column_values: Series
            Values of column from which categorical distribution will be inferred.

        Returns:
        -----------
            Tuple containing two lists: first list — values, second list — probabilities.
            Example:
                ([1, 2, 3], [0.25, 0.25, 0.5])
        """
        normalized_frequencies_of_values = column_values.value_counts(normalize=True, dropna=False)
        values = normalized_frequencies_of_values.index.tolist()
        if any(isinstance(value, pd.Timestamp) for value in values):
            values = list(map(lambda x: x.to_pydatetime() if isinstance(x, pd.Timestamp) else None, values))
        elif any(isinstance(value, str) for value in values):
            values = list(map(lambda x: x if not pd.isna(x) else None, values))
        elif any(isinstance(value, float) and not math.isnan(value) for value in values):
            values = list(map(lambda x: (x if not x.is_integer() else int(x)) if not math.isnan(x) else None, values))
        probabilities = normalized_frequencies_of_values.to_list()
        return values, probabilities

    def get_values(self) -> List:
        return self.values

    def get_probabilities(self) -> List[float]:
        return self.probabilities

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        if any(isinstance(value, datetime.date) for value in self.values):
            values = list(map(
                lambda x: x.strftime("%Y-%m-%d") if not pd.isna(x) else None,
                self.values
            ))
        elif any(isinstance(value, pd.Timestamp) for value in self.values):
            values = list(map(
                lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if not pd.isna(x) else None,
                self.values
            ))
        elif any(isinstance(value, uuid.UUID) for value in self.values):
            values = list(map(
                lambda x: str(x),
                self.values
            ))
        else:
            values = self.values
        super_dict[self.column_name].update({
            'values': values,
            'probabilities': self.probabilities,
        })
        self.set_mix_to_end(super_dict)
        return super_dict
