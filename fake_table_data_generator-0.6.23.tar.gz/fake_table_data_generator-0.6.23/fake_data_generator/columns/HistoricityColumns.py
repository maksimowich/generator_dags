from typing import (
    Callable,
    Dict,
    List,
    Union,
)
from dateutil.relativedelta import relativedelta

import pandas as pd
import numpy as np

from .Column import Column
from ..data_types import (
    Date, Timestamp, TimestampWithTZ,
    String, Varchar, Char,
)
from .MultipleColumns import MultipleColumns
from ..databases import get_db, ClickHouse
from ..execute_sql import execute_sql
from .generate_central_data import generate_central_data


class HistoricityColumns(MultipleColumns):
    CLASS_NAME = "HISTORICITY"

    SECONDS_IN_DAY = 86400
    MONTH_DELTA = relativedelta(months=1)
    SECONDS_IN_MONTHS = [
        2419200,
        2505600,
        2592000,
        2678400,
    ]

    SQL_QUERY_1 = """
        with v1 as (
            select
                {key_columns_names},
                min({unix_timestamp_column}) as min_unix_timestamp,
                max({unix_timestamp_column}) as max_unix_timestamp
            from {table_name}
            group by {key_columns_names}
        ),
        v2 as (
            select 
                min_unix_timestamp,
                max_unix_timestamp,
                count(*) over (partition by 1,2) as cnt
            from v1
        ),
        v3 as (
            select
                min_unix_timestamp,
                max_unix_timestamp,
                cnt,
                sum(cnt) over () as total_cnt
            from v2
            group by min_unix_timestamp,max_unix_timestamp,cnt
        )
        select 
            min_unix_timestamp,
            max_unix_timestamp,
            cnt / total_cnt as prob
        from v3
        limit {max_timestamps}
    """

    SQL_QUERY_2_ONE_HISTORICITY_COLUMN = """
        with v1 as (
            select
                {key_columns_names},
                {unix_timestamp_column} as unix_timestamp
            from {table_name}
        ),
        v2 as (
            select 
                unix_timestamp - lag(unix_timestamp) over (partition by {key_columns_names} order by unix_timestamp) as diff_in_seconds
            from v1
        ),
        v3 as (
            select
                diff_in_seconds,
                count(*) as cnt
            from v2
            where diff_in_seconds is not null
            group by diff_in_seconds
            order by cnt desc
            limit 100
        )
        select
            diff_in_seconds,
            cnt / sum(cnt) over () as prob
        from v3
        limit {max_intervals}
    """

    SQL_QUERY_2_ONE_HISTORICITY_COLUMN__CLICKHOUSE = """
        with v1 as (
            select
                {key_columns_names},
                {unix_timestamp_column} as unix_timestamp
            from {table_name}
        ),
        v2 as (
            select 
                unix_timestamp,
                any(unix_timestamp) over (partition by {key_columns_names} order by unix_timestamp rows between 1 preceding and 1 preceding) as unix_timestamp_prev
            from v1
        ),
        v3 as (
            select 
                unix_timestamp - unix_timestamp_prev as diff_in_seconds
            from v2
            where unix_timestamp_prev <> 0
        ),
        v4 as (
            select
                diff_in_seconds,
                count(*) as cnt
            from v3
            where diff_in_seconds is not null and diff_in_seconds > 0
            group by diff_in_seconds
            order by cnt desc 
            limit 100
        ),
        v5 as (
            select 
                diff_in_seconds,
                cnt,
                sum(cnt) over () as total_cnt
            from v4
            group by diff_in_seconds,cnt
        )
        select
            diff_in_seconds,
            cnt / total_cnt as prob
        from v5
        limit 20
        settings allow_experimental_window_functions = 1
    """

    SQL_QUERY_2_TWO_HISTORICITY_COLUMNS = """
        with v1 as (
            select
                {key_columns_names},
                {end_unix_timestamp_column} - {start_unix_timestamp_column} as diff_in_seconds
            from {table_name}
        ),
        v2 as (
            select
                diff_in_seconds,
                count(*) as cnt
            from v1
            where diff_in_seconds is not null
            group by diff_in_seconds
            order by cnt desc
            limit 100
        ),
        v3 as (
            select
                diff_in_seconds,
                cnt,
                sum(cnt) over () as total_cnt
            from v2
        )
        select
            diff_in_seconds,
            cnt / total_cnt as prob
        from v3
        limit {max_intervals}
    """

    def get_conversion_func(self) -> Callable:
        data_type = self.columns[0].get_data_type()
        if isinstance(data_type, (Timestamp, TimestampWithTZ)):
            return lambda x: pd.to_datetime(x, unit='s') if not pd.isna(x) else None
        elif isinstance(data_type, Date):
            return lambda x: pd.to_datetime(x, unit='s').date() if not pd.isna(x) else None
        elif isinstance(data_type, (String, Varchar, Char)) and self.string_datetime_format is not None:
            return lambda x: pd.to_datetime(x, unit='s').strftime(self.string_datetime_format) if not pd.isna(x) else None
        else:
            raise Exception("incorrect data type for historicity columns!")

    def __init__(
            self,
            algorithm_name: str,
            columns: List[Column],
            key_columns_names: List[str],
            min_and_max_unix_timestamps: List[Dict] = None,
            time_intervals: List[Dict] = None,
            string_datetime_format: str = None,
            max_timestamps: int = 20,
            max_intervals: int = 20,
    ):
        if len(columns) not in [1, 2]:
            raise Exception("invalid number of columns for HISTORICITY pattern")
        super().__init__(
            algorithm_name=algorithm_name,
            columns=columns,
        )
        self.historicity_columns_names = [column.get_column_name() for column in columns]
        self.key_columns_names = key_columns_names
        self.min_and_max_unix_timestamps = min_and_max_unix_timestamps
        if min_and_max_unix_timestamps is not None:
            self.timestamps_probs = [d.get("probability") for d in min_and_max_unix_timestamps]
            self.timestamps_values = [d.get("min_and_max") for d in min_and_max_unix_timestamps]
            self.timestamps_values_indices = list(range(len(self.timestamps_values)))
        else:
            self.timestamps_probs = None
            self.timestamps_values = None
        self.time_intervals = time_intervals
        if isinstance(self.time_intervals, list):
            self.intervals_probs = [d.get("probability") for d in time_intervals]
            self.intervals_values = [d.get("interval_length") for d in time_intervals]
        elif self.time_intervals == "day":
            self.intervals_probs = [1]
            self.intervals_values = [86400]
        else:
            self.intervals_probs = None
            self.intervals_values = None
        self.string_datetime_format = string_datetime_format
        self._left_timestamps: List[float] = None
        self._left_keys_row: pd.DataFrame = None
        if columns[0].get_data_type() is not None:
            self._conversion_func: Callable = self.get_conversion_func()
        else:
            self._conversion_func = None
        self.max_timestamps = max_timestamps
        self.max_intervals = max_intervals

    def compute_min_and_max_unix_timestamps(
            self,
            conn,
            table_name,
    ) -> List[Dict]:
        historicity_column_name = self.columns[0].get_column_name()
        historicity_column_type = self.columns[0].get_data_type()
        unix_timestamp_column = get_db(conn).get_unix_timestamp_column(
            historicity_column_name=historicity_column_name,
            historicity_column_type=historicity_column_type,
            string_datetime_format=self.string_datetime_format,
        )
        sql_query = self.SQL_QUERY_1.format(
            key_columns_names=','.join(self.key_columns_names),
            unix_timestamp_column=unix_timestamp_column,
            table_name=table_name,
            max_timestamps=self.max_timestamps,
        )
        if get_db(conn) == ClickHouse:
            sql_query += " settings  allow_experimental_window_functions = 1;"
        res_df = execute_sql(conn, sql_query)
        return [
            {
                "min_and_max": (row["min_unix_timestamp"], row['max_unix_timestamp']),
                "probability": row["prob"],
            }
            for _, row in res_df.iterrows()
        ]

    @classmethod
    def is_month_intervals(cls, res_df) -> bool:
        for _, row in res_df.iterrows():
            if not row["diff_in_seconds"] in cls.SECONDS_IN_MONTHS:
                return False
        return True

    @classmethod
    def is_day_intervals(cls, res_df) -> bool:
        for _, row in res_df.iterrows():
            if not row["diff_in_seconds"] != cls.SECONDS_IN_DAY:
                return False
        return True

    def generate_timestamps(self) -> List[float]:
        index = np.random.choice(self.timestamps_values_indices, p=self.timestamps_probs)
        min_unix_timestamp, max_unix_timestamp = self.timestamps_values[index]
        if isinstance(self.time_intervals, list) or self.time_intervals == "day":
            unix_timestamps = [min_unix_timestamp]
            current_unix_timestamp = min_unix_timestamp
            while True:
                interval_value = np.random.choice(self.intervals_values, p=self.intervals_probs)
                current_unix_timestamp += interval_value
                if current_unix_timestamp >= max_unix_timestamp:
                    unix_timestamps.append(max_unix_timestamp)
                    break
                else:
                    unix_timestamps.append(current_unix_timestamp)
            return unix_timestamps
        elif self.time_intervals == "month":
            max_timestamp = pd.to_datetime(max_unix_timestamp, unit='s')
            timestamps = [pd.to_datetime(min_unix_timestamp, unit='s')]
            current_timestamp = timestamps[0]
            while True:
                current_timestamp += self.MONTH_DELTA
                if current_timestamp >= max_timestamp:
                    timestamps.append(max_timestamp)
                    break
                else:
                    timestamps.append(current_timestamp)
            return [timestamp.timestamp() for timestamp in timestamps]
        else:
            raise Exception("incorrect time_intervals!")

    def compute_time_intervals(
            self,
            conn,
            table_name,
    ) -> Union[List[Dict], str]:
        if len(self.columns) == 1:
            historicity_column_name = self.columns[0].get_column_name()
            historicity_column_type = self.columns[0].get_data_type()
            unix_timestamp_column = get_db(conn).get_unix_timestamp_column(
                historicity_column_name=historicity_column_name,
                historicity_column_type=historicity_column_type,
                string_datetime_format=self.string_datetime_format,
            )
            if get_db(conn) == ClickHouse:
                query_pattern = self.SQL_QUERY_2_ONE_HISTORICITY_COLUMN__CLICKHOUSE
            else:
                query_pattern = self.SQL_QUERY_2_ONE_HISTORICITY_COLUMN
            sql_query = query_pattern.format(
                key_columns_names=','.join(self.key_columns_names),
                unix_timestamp_column=unix_timestamp_column,
                table_name=table_name,
                max_intervals=self.max_intervals,
            )
        elif len(self.columns) == 2:
            start_historicity_column_name = self.columns[0].get_column_name()
            start_historicity_column_type = self.columns[0].get_data_type()
            start_unix_timestamp_column = get_db(conn).get_unix_timestamp_column(
                historicity_column_name=start_historicity_column_name,
                historicity_column_type=start_historicity_column_type,
                string_datetime_format=self.string_datetime_format,
            )
            end_historicity_column_name = self.columns[0].get_column_name()
            end_historicity_column_type = self.columns[0].get_data_type()
            end_unix_timestamp_column = get_db(conn).get_unix_timestamp_column(
                historicity_column_name=end_historicity_column_name,
                historicity_column_type=end_historicity_column_type,
                string_datetime_format=self.string_datetime_format,
            )
            sql_query = self.SQL_QUERY_2_TWO_HISTORICITY_COLUMNS.format(
                key_columns_names=','.join(self.key_columns_names),
                start_unix_timestamp_column=start_unix_timestamp_column,
                end_unix_timestamp_column=end_unix_timestamp_column,
                table_name=table_name,
                max_intervals=self.max_intervals,
            )
        else:
            raise Exception("invalid number of columns for HISTORICITY pattern")
        if get_db(conn) == ClickHouse:
            sql_query += " settings  allow_experimental_window_functions = 1;"
        res_df = execute_sql(conn, sql_query)
        if self.is_month_intervals(res_df):
            return "month"
        elif self.is_day_intervals(res_df):
            return "day"
        else:
            return [
                {
                    "interval_length": row["diff_in_seconds"],
                    "probability": row["prob"],
                }
                for _, row in res_df.iterrows()
            ]

    def generate_data(
            self,
            output_size: int,
            generated_data: pd.DataFrame,
            key_patterns: List[Union[Column, MultipleColumns]] = None
    ) -> pd.DataFrame:
        if self._left_timestamps and len(self._left_timestamps) >= output_size:
            data = [self._left_timestamps[:output_size]]
            if len(self.columns) == 2:
                end_timestamps = self._left_timestamps[1:output_size + 1]
                data.append(end_timestamps)
            self._left_timestamps = self._left_timestamps[output_size:]
            historicity_data = pd.DataFrame([[self._conversion_func(t) for t in timestamps] for timestamps in data]).T
            historicity_data.columns = self.historicity_columns_names
            return pd.concat([
                pd.concat([self._left_keys_row] * output_size, ignore_index=True),
                historicity_data,
            ], axis=1)

        if self._left_timestamps:
            keys_data = pd.concat([self._left_keys_row] * len(self._left_timestamps), ignore_index=True)
            start_timestamps = self._left_timestamps[:]
            if len(self.columns) == 2:
                end_timestamps = self._left_timestamps[1:output_size] + [None]
            else:
                end_timestamps = None
            self._left_keys_row = None
            self._left_timestamps = None

        else:
            keys_data = pd.DataFrame()
            start_timestamps = []
            if len(self.columns) == 2:
                end_timestamps = []
            else:
                end_timestamps = None

        while True:
            timestamps = self.generate_timestamps()
            keys_row = generate_central_data(
                patterns=key_patterns,
                output_size=1,
                skip_custom_generator=False,
                mix_columns_names=[]
            )

            if len(start_timestamps) + len(timestamps) <= output_size:
                keys_data = pd.concat([keys_data] + [keys_row] * len(timestamps), ignore_index=True)
                start_timestamps.extend(timestamps)
                if end_timestamps is not None:
                    end_timestamps.extend(timestamps[1:output_size] + [None])
                if len(start_timestamps) == output_size:
                    self._left_keys_row = None
                    self._left_timestamps = None
                    break
            else:
                self._left_keys_row = keys_row
                self._left_timestamps = timestamps[output_size - len(start_timestamps):]
                keys_data = pd.concat([keys_data] + [keys_row] * (output_size - len(start_timestamps)), ignore_index=True)
                if end_timestamps is not None:
                    end_timestamps.extend(timestamps[1:output_size - len(start_timestamps) + 1])
                start_timestamps.extend(timestamps[:output_size - len(start_timestamps)])
                break

        data = [start_timestamps]
        if end_timestamps is not None:
            data.append(end_timestamps)
        historicity_data = pd.DataFrame([[self._conversion_func(t) for t in timestamps] for timestamps in data]).T
        historicity_data.columns = self.historicity_columns_names
        return pd.concat([
            keys_data,
            historicity_data
        ], axis=1)

    def get_key_columns_names(self):
        return self.key_columns_names

    def set_key_columns_names(self, key_columns_names: List[str]):
        self.key_columns_names = key_columns_names

    def get_min_and_max_unix_timestamps(self):
        return self.min_and_max_unix_timestamps

    def get_time_intervals(self):
        return self.time_intervals

    def get_string_datetime_format(self):
        return self.string_datetime_format

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.algorithm_name].update({
            "key_columns_names": self.key_columns_names,
            "min_and_max_unix_timestamps": self.min_and_max_unix_timestamps,
            "time_intervals": self.time_intervals,
        })
        if self.string_datetime_format is not None:
            super_dict[self.algorithm_name].update({
                "string_datetime_format": self.string_datetime_format,
            })
        return super_dict

    def is_predefined_pattern(self):
        return (self.get_min_and_max_unix_timestamps() is None
                or self.get_time_intervals() is None)
