from typing import Union
from datetime import datetime, timedelta
import pytz

import pandas as pd

from .. import Column
from ...data_types import DataType


class CurrentTimestampColumn(Column):
    CLASS_NAME = "CURRENT_TIMESTAMP"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            timezone: str = "Europe/Moscow",
            is_data_type_with_timezone: bool = None,
            string_datetime_format: str = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.timezone = pytz.timezone(timezone)
        self.is_data_type_with_timezone = is_data_type_with_timezone
        self.string_datetime_format = string_datetime_format

    def generate_data(self, output_size: int) -> pd.Series:
        if self.is_data_type_with_timezone:
            dttms = [
                datetime.now(tz=self.timezone).replace(microsecond=0)
                for _ in range(output_size)
            ]
        else:
            hours_offset = self.timezone.utcoffset(datetime.now()).total_seconds() / 3600
            dttms = []
            for _ in range(output_size):
                dttm = datetime.now(pytz.timezone('Etc/GMT')).replace(microsecond=0) + timedelta(hours=hours_offset)
                if self.string_datetime_format is not None:
                    dttm = dttm.strftime(self.string_datetime_format)
                dttms.append(dttm)
        return pd.Series(dttms)

    def get_as_dict(self):
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            "timezone": str(self.timezone),
        })
        if self.is_data_type_with_timezone is not None:
            super_dict[self.column_name].update({
                "is_data_type_with_timezone": self.is_data_type_with_timezone,
            })
        if self.string_datetime_format is not None:
            super_dict[self.column_name].update({
                "string_datetime_format": self.string_datetime_format,
            })
        return super_dict
