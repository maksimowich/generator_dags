from typing import Dict, List, Union
from collections import defaultdict

import numpy as np
import pandas as pd

from .Column import Column
from ..data_types import DataType


class MixedColumn(Column):
    CLASS_NAME = "MIXED"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            patterns: List[Column] = None,
            probabilities: List[float] = None,
            null_ratio: float = 0,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.patterns = patterns
        self.probabilities = probabilities
        self.null_ratio = null_ratio if null_ratio is not None else 0
        self.not_null_ratio = 1 - self.null_ratio

    def generate_data(
            self,
            output_size: int,
    ) -> pd.Series:
        null_cnt = 0
        pattern_to_cnt = defaultdict(int)
        for _ in range(output_size):
            if np.random.choice([False, True], p=[self.null_ratio, self.not_null_ratio]):
                pattern_to_cnt[np.random.choice(self.patterns, p=self.probabilities)] += 1
            else:
                null_cnt += 1
        generated_values = pd.concat([
            pattern.generate_data(output_size=cnt)
            for pattern, cnt in pattern_to_cnt.items()
        ] + [pd.Series([None] * null_cnt, dtype=object)])
        return generated_values.sample(output_size, ignore_index=True)

    def get_null_ratio(self) -> float:
        return self.null_ratio

    def get_random_pattern(self) -> Column:
        return np.random.choice(self.patterns, size=1, p=self.probabilities)[0]

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            "patterns": {
                i: {
                    attr_name: attr_value
                    for attr_name, attr_value in pattern.get_as_dict().get(pattern.get_column_name()).items()
                    if attr_name not in ["data_type", "null_ratio"]
                }
                for i, pattern in enumerate(self.patterns)
            },
            "probabilities": self.probabilities,
            "null_ratio": self.null_ratio,
        })
        return super_dict
