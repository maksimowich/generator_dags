from typing import Dict, Iterable, Union
from re import match

import numpy as np
import pandas as pd
from rstr import xeger

from .ColumnWithMix import ColumnWithMix
from .MixedColumn import MixedColumn
from ..data_types import DataType


class StringFromRegexColumn(ColumnWithMix):
    CLASS_NAME = "STRING_FROM_REGEX"

    def __init__(
            self,
            column_name: str = None,
            data_type: Union[DataType, str] = None,
            common_regex: str = None,
            null_ratio: float = 0,
            mix: MixedColumn = None,
    ):
        super().__init__(
            column_name=column_name,
            data_type=data_type,
            mix=mix,
        )
        self.common_regex = common_regex
        self.null_ratio = null_ratio
        self.not_null_ratio = 1 - self.null_ratio

    def generate_data(
            self,
            output_size: int,
    ) -> pd.Series:
        strings = [
            xeger(self.common_regex)
            if np.random.choice(
                a=[None, True],
                p=[self.null_ratio, self.not_null_ratio]
            )
            else None
            for _ in range(output_size)
        ]
        return pd.Series(strings)

    @staticmethod
    def get_common_regex(
            strings: Iterable[str],
    ) -> str:
        """
        Function that returns common regular expression of given strings.

        Parameters
        ----------
        strings: Iterable of strings
            Strings for which common regex should be found.

        Returns
        -------
        String representing common regular expression of given strings.

        Examples
        --------
        # >>> get_common_regex(['123', '32314', '131'])
        # '[0-9][0-9][0-9][0-9][0-9]'
        # >>> get_common_regex(['abc', 'a0c', 'xyz'])
        # '[a-z][a-z0-9][a-z]'
        # >>> get_common_regex(['1234-2314', '1241-1234', '2514-2141'])
        '[0-9][0-9][0-9][0-9][-][0-9][0-9][0-9][0-9]'
        """
        common_pattern = {}
        for string in strings:
            for index, char in enumerate(string):
                if match(r"[0-9]", char):
                    if '0-9' not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + '0-9'
                    else:
                        continue
                elif match(r"[A-Z]", char):
                    if 'A-Z' not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + 'A-Z'
                    else:
                        continue
                elif match(r"[a-z]", char):
                    if 'a-z' not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + 'a-z'
                    else:
                        continue
                elif match(r"[А-Я]", char):
                    if 'А-Я' not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + 'А-Я'
                    else:
                        continue
                elif match(r"[а-я]", char):
                    if 'а-я' not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + 'а-я'
                    else:
                        continue
                else:
                    if char not in common_pattern.get(index, ''):
                        common_pattern[index] = common_pattern.get(index, '') + char
        common_pattern_string = ''
        for _, symbol_regex in sorted(common_pattern.items()):
            common_pattern_string += '[' + symbol_regex + ']'
        return common_pattern_string

    def get_null_ratio(self) -> float:
        return self.null_ratio

    def get_regex(self) -> str:
        return self.common_regex

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()
        super_dict[self.column_name].update({
            'common_regex': self.common_regex,
            'null_ratio': self.null_ratio,
        })
        self.set_mix_to_end(super_dict)
        return super_dict

    def is_predefined_pattern(self):
        return self.get_regex() is None
