from typing import Dict, List, Optional, Union
from collections import defaultdict

import pandas as pd

from ..data_types import DataType
from .utils import get_pattern_by_name
from .Column import Column
from .ContinuousColumn import ContinuousColumn
from .MultipleCategoricalColumns import MultipleCategoricalColumns
from .Pattern import Pattern


class ConditionalContinuousColumn(Column):
    CLASS_NAME = "CONDITIONAL_CONTINUOUS"

    def __init__(
            self,
            column_name: str,
            data_type: Union[DataType, str] = None,
            parameter_columns_names: List[str] = None,
            parameter_pattern_name: str = None,
            intervals_computation_method: str = None,
            number_of_intervals: int = None,
            number_of_quantiles: int = None,
            upper_percentile: int = None,
            lower_percentile: int = None,
            compute_distributions_null_ratio: bool = False,
            distributions: Dict[int, ContinuousColumn] = None,
            null_ratio: float = 0,
    ):
        """
        Conditional continuous pattern allows:
            1) computing a continuous pattern for each unique combination of specified columns;
            2) generating data from computed distributions.


        To specify pattern computation you should define:
        Necessary:
            1) column_name - target column name;
            2) parameter_columns_names - columns in the context of which distributions should be calculated.
        Optional:
            3) number_of_intervals - number of intervals to compute for each continuous distribution;
            4) upper_percentile - values greater than value of upper percentile will be ignored
                    when constructing continuous distribution;
            5) lower_percentile - values less than value of lower percentile will be ignored
                    when constructing continuous distribution;
            6) compute_distributions_null_ratio - whether to compute null_ratio for each continuous distribution.

            If number_of_intervals, upper_percentile or lower_percentile is not specified
            then their values will be taken from parameters of generate_table_profile function.

        To directly add a pattern to your profile you should define:
            1) parameter_columns_names or parameter_pattern_name - columns` names or pattern name of
                    dependent multiple categorical pattern, use only one of parameters;
            2) distributions - dictionary which contains indexes of multiple categorical pattern as keys
                    and defined continuous patterns as values;
            3) null_ratio - probability with which nulls will be generated.
        """
        if parameter_columns_names is None and parameter_pattern_name is None:
            raise Exception(
                f"Either parameter_columns_names or parameter_pattern_name "
                f"must be defined in {self.CLASS_NAME} pattern."
            )
        super().__init__(
            column_name=column_name,
            data_type=data_type,
        )
        self.parameter_columns_names = parameter_columns_names
        self.parameter_pattern_name = parameter_pattern_name or f"_{'__'.join(self.parameter_columns_names)}"
        self.intervals_computation_method = intervals_computation_method
        self.number_of_intervals = number_of_intervals
        self.number_of_quantiles = number_of_quantiles
        self.upper_percentile = upper_percentile
        self.lower_percentile = lower_percentile
        self.compute_distributions_null_ratio = compute_distributions_null_ratio
        self.distributions = distributions
        self.null_ratio = null_ratio
        self.not_null_ratio = 1 - null_ratio

        self.parameter_pattern: MultipleCategoricalColumns = None

    def set_parameter_pattern(
            self,
            parameter_pattern: MultipleCategoricalColumns,
    ) -> None:
        self.parameter_pattern = parameter_pattern

    def generate_data(self, output_size) -> pd.Series:
        nulls_cnt = 0
        distributions_indexes = self.parameter_pattern.generated_data_indexes

        distribution_index_to_cnt = defaultdict(int)
        for index in distributions_indexes:
            if not self.generate_null():
                distribution_index_to_cnt[index] += 1
            else:
                nulls_cnt += 1

        list_of_series = [
            self.distributions[distribution_index].generate_data(cnt)
            for distribution_index, cnt in distribution_index_to_cnt.items()
        ]

        return pd.concat(list_of_series + [pd.Series([None] * nulls_cnt, dtype=object)]) \
            .sample(output_size, ignore_index=True)

    def get_as_dict(self) -> Dict[str, Dict]:
        super_dict = super().get_as_dict()

        distributions = {}
        for row_index, continuous_pattern in self.distributions.items():
            pattern_as_dict = continuous_pattern.get_as_dict().get(continuous_pattern.get_column_name())
            del pattern_as_dict["type"]
            del pattern_as_dict["data_type"]
            distributions[row_index] = pattern_as_dict

        super_dict[self.column_name].update({
            "parameter_pattern_name": self.parameter_pattern_name,
            "null_ratio": self.null_ratio,
            "distributions": distributions,
        })
        return super_dict

    def is_predefined_pattern(self):
        if not self.distributions:
            return True
        else:
            return False


def find_and_set_parameter_pattern(
        patterns: List[Pattern],
        conditional_continuous_pattern: ConditionalContinuousColumn,
) -> None:
    if not conditional_continuous_pattern.parameter_pattern:
        parameter_pattern = get_pattern_by_name(
            patterns=patterns,
            pattern_name=conditional_continuous_pattern.parameter_pattern_name
        )
        if not isinstance(parameter_pattern, MultipleCategoricalColumns):
            raise Exception(
                f"No parameter pattern was found "
                f"for {ConditionalContinuousColumn.CLASS_NAME} "
                f"{conditional_continuous_pattern.get_column_name()}"
            )
        conditional_continuous_pattern.set_parameter_pattern(parameter_pattern)


def generate_continuous_conditional_data(
        patterns: List[Pattern],
        output_size: int,
) -> pd.DataFrame:
    list_of_generated_series: List[pd.Series] = []
    for pattern in patterns:
        if isinstance(pattern, ConditionalContinuousColumn):
            find_and_set_parameter_pattern(patterns, pattern)
            list_of_generated_series.append(pattern.generate_fake_data(output_size))
    return pd.concat(list_of_generated_series, axis=1) if len(list_of_generated_series) > 0 else pd.DataFrame()


def compute_conditional_continuous_pattern(
    conditional_continuous_predefined_pattern: ConditionalContinuousColumn,
    parameter_pattern: MultipleCategoricalColumns,
    table_data_df: pd.DataFrame,
    number_of_intervals: int,
    number_of_quantiles: int,
    intervals_computation_method: str,
    upper_percentile: int,
    lower_percentile: int,
):
    column_name = conditional_continuous_predefined_pattern.get_column_name()
    column_data_type = conditional_continuous_predefined_pattern.get_data_type()

    column_number_of_intervals = conditional_continuous_predefined_pattern.number_of_intervals or number_of_intervals
    column_number_of_quantiles = conditional_continuous_predefined_pattern.number_of_quantiles or number_of_quantiles
    column_intervals_computation_method = conditional_continuous_predefined_pattern.intervals_computation_method or intervals_computation_method
    column_upper_percentile = conditional_continuous_predefined_pattern.upper_percentile or upper_percentile
    column_lower_percentile = conditional_continuous_predefined_pattern.lower_percentile or lower_percentile
    compute_distributions_null_ratio = conditional_continuous_predefined_pattern.compute_distributions_null_ratio
    column_null_ratio = table_data_df[column_name].isnull().mean() if not compute_distributions_null_ratio else 0

    parameter_rows: pd.DataFrame = parameter_pattern.get_values()
    parameter_column_names: List[str] = parameter_pattern.get_columns_names()

    df = table_data_df[parameter_column_names + [column_name]]

    def get_filtered_df(df: pd.DataFrame, row: pd.Series) -> pd.DataFrame:
        filter_mask = pd.Series([True] * len(df))
        for column_index in range(len(parameter_column_names)):
            if pd.isna(row[column_index]):
                filter_mask &= (df[parameter_column_names[column_index]].isnull())
            else:
                filter_mask &= (df[parameter_column_names[column_index]] == row[column_index])
        return df[filter_mask]

    distributions = {}
    for row_index, row in parameter_rows.iterrows():
        filtered_df = get_filtered_df(df, row)
        target_column_values = filtered_df[column_name]
        target_column_null_ratio = target_column_values.isnull().mean() if compute_distributions_null_ratio else 0
        if target_column_values.nunique() > 1:
            intervals, probabilities = ContinuousColumn.get_intervals_and_probabilities(
                column_values=target_column_values,
                intervals_computation_method=column_intervals_computation_method,
                number_of_intervals=column_number_of_intervals,
                number_of_quantiles=column_number_of_quantiles,
                upper_percentile=column_upper_percentile,
                lower_percentile=column_lower_percentile,
            )
        elif target_column_values.nunique() == 1:
            first_not_null_index = target_column_values.first_valid_index()
            not_null_value = target_column_values[first_not_null_index]
            intervals, probabilities = [[not_null_value, not_null_value]], [1]
        else:
            intervals, probabilities = None, None

        distributions[row_index] = ContinuousColumn(
            column_name=None,
            data_type=column_data_type,
            intervals=intervals,
            probabilities=probabilities,
            null_ratio=target_column_null_ratio,
        )

    return ConditionalContinuousColumn(
        column_name=column_name,
        data_type=column_data_type,
        parameter_columns_names=parameter_column_names,
        number_of_intervals=number_of_intervals,
        distributions=distributions,
        null_ratio=column_null_ratio,
    )
