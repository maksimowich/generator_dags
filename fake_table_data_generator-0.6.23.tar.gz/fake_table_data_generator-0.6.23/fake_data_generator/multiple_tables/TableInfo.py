from typing import Dict, List, Union, Set

from .. import get_table_profile
from ..columns import (
    Column,
    MultipleColumns,
    MultipleCategoricalColumns,
    ID_COLUMNS,
)


class TableInfo:
    def __init__(
            self,
            profile_table_name: str,
            depth: int = 0,
            columns_info: List[Union[Column, MultipleColumns]] = None,
            conn=None,
            source_table_name: str = None,
            columns_to_include: List[str] = None,
            number_of_rows_from_which_create_patterns: int = 5000,
            is_dict: bool = False,
            number_of_intervals: int = 10,
            # categorical_threshold: float = 0.2,
            max_search: int = None,
            rows_to_insert: int = None,
            batch_size: int = None,
            is_immutable: bool = False,
    ):
        self.profile_table_name = profile_table_name
        self.columns_info = columns_info

        self.conn = conn
        self.source_table_name = source_table_name
        self.columns_to_include = columns_to_include
        self.number_of_rows_from_which_create_patterns = number_of_rows_from_which_create_patterns
        self.is_dict = is_dict
        self.number_of_intervals = number_of_intervals
        # self.categorical_threshold = categorical_threshold

        self.depth = depth
        self.max_search = max_search
        self.is_immutable = is_immutable

        self.rows_to_insert = rows_to_insert
        self.batch_size = batch_size

        self.dependent_tables = set()
        self.profile = None

    def get_dependent_tables(self) -> Set:
        return self.dependent_tables

    def add_dependent_table(self, dependent_table) -> None:
        self.dependent_tables.add(dependent_table)

    def delete_column(self, column_name: str) -> None:
        for index, column_info in enumerate(self.columns_info or []):
            if isinstance(column_info, MultipleColumns):
                for column in column_info.get_columns():
                    if column.get_column_name() == column_name:
                        del self.columns_info[index]
                        return
            else:
                if column_info.get_column_name() == column_name:
                    del self.columns_info[index]
                    return

    def get_columns_names(self) -> List[str]:
        columns_names = []
        for column_info in self.columns_info or []:
            if isinstance(column_info, MultipleColumns):
                columns_names += column_info.get_columns_names()
            else:
                columns_names.append(column_info.get_column_name())
        return columns_names

    def get_profile_table_name(self) -> str:
        return self.profile_table_name

    def get_source_table_name(self) -> str:
        return self.source_table_name

    def get_conn(self):
        return self.conn

    def set_conn(self, conn):
        self.conn = conn

    def get_depth(self):
        return self.depth

    def set_depth(self, depth):
        self.depth = depth

    def get_max_search(self):
        return self.max_search

    def get_columns_info(self):
        return self.columns_info

    def set_columns_info(self, columns_info):
        self.columns_info = columns_info

    def get_id_column(self):
        for column_info in self.columns_info or []:
            if type(column_info) in ID_COLUMNS:
                return column_info

    def set_table_profile(self, profile: Dict) -> None:
        self.profile = profile

    def get_table_profile(self) -> Dict:
        if self.profile is not None:
            return self.profile
        else:
            profile = {
                'rows_to_insert': self.rows_to_insert,
                'batch_size': self.batch_size,
                'columns': get_table_profile(
                        conn=self.conn,
                        source_table_name=self.source_table_name,
                        number_of_rows_from_which_create_patterns=self.number_of_rows_from_which_create_patterns,
                        columns_info=self.columns_info,
                        columns_to_include=self.columns_to_include,
                        number_of_intervals=self.number_of_intervals,
                        # categorical_threshold=self.categorical_threshold,
                        is_dict=self.is_dict,
                    )
                }
            if self.is_dict:
                for pattern_name, pattern_info in profile.get('columns').items():
                    if pattern_info['type'] == MultipleCategoricalColumns.CLASS_NAME:
                        profile['rows_to_insert'] = len(pattern_info['values'])
                        profile['id_mapping'] = pattern_info['id_mapping']
                        del pattern_info['id_mapping']
                        break
                else:
                    raise Exception()
            return profile
