from typing import Dict, List
from collections import defaultdict
from copy import copy

from loguru import logger

from ..databases import get_db
from ..data_types import UUID
from .TableInfo import TableInfo
from ..execute_sql import execute_sql
from ..columns import (
    IncrementalIDColumn,
    UuidColumn,
    ForeignKeyRandomSamplingColumn,
    ForeignKeyCategoricalSamplingColumn,
)
from ..single_table.generate_profile import load_profile_to_json


def increment_tables_depth(
    table_info: TableInfo,
    increment_size: int,
):
    table_info.set_depth(table_info.get_depth() + increment_size)
    dependent_tables_info = table_info.get_dependent_tables()
    for dependent_table_info in dependent_tables_info:
        increment_tables_depth(dependent_table_info, 1)


def add_linked_tables(
    table_info: TableInfo,
    profile_table_name_to_table_info: Dict[str, TableInfo],
    source_table_name_to_table_info: Dict[str, TableInfo],
    fk_tables_depth: int,
    max_searchable_depth: int,
    postfix_for_computed_fk_tables: str,
) -> None:
    if fk_tables_depth > max_searchable_depth:
        return

    conn = table_info.get_conn()
    db = get_db(conn)

    source_table_name = table_info.get_source_table_name()

    select_table_fk_query = db.get_select_table_fk_query(
        table_schema=source_table_name.split('.')[0],
        table_name=source_table_name.split('.')[1],
    )

    table_fk_df = execute_sql(
        conn=conn,
        sql_query=select_table_fk_query,
    )

    for _, fk in table_fk_df.iterrows():
        columns_names_of_columns_info = table_info.get_columns_names()
        column_name = fk['column_name']
        column_data_type = db.get_generator_data_type(
            describe_data_row={
                'data_type': fk.get('column_data_type'),
                'numeric_scale': fk.get('column_numeric_scale'),
                'numeric_precision': fk.get('column_numeric_precision'),
                'character_maximum_length': fk.get('column_character_maximum_length'),
            }
        )

        source_fk_table_name = f"{fk['foreign_table_schema']}.{fk['foreign_table_name']}"
        profile_fk_table_name = source_fk_table_name + postfix_for_computed_fk_tables
        fk_column_name = fk['foreign_column_name']
        fk_column_data_type = db.get_generator_data_type(
            describe_data_row={
                'data_type': fk.get('foreign_column_data_type'),
                'numeric_scale': fk.get('foreign_column_numeric_scale'),
                'numeric_precision': fk.get('foreign_column_numeric_precision'),
                'character_maximum_length': fk.get('foreign_column_character_maximum_length'),
            }
        )

        if source_table_name == source_fk_table_name:
            if (column_name not in columns_names_of_columns_info
                    and not table_info.is_immutable):
                fk_column = ForeignKeyRandomSamplingColumn(
                    column_name=column_name,
                    data_type=column_data_type,
                    foreign_key_table_name=profile_fk_table_name,
                    foreign_key_column_name=fk_column_name,
                )
                table_info.set_columns_info((table_info.get_columns_info() or []) + [fk_column])

            if (fk_column_name not in columns_names_of_columns_info
                    and not table_info.is_immutable):
                if isinstance(fk_column_data_type, UUID):
                    id_column = UuidColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                else:
                    id_column = IncrementalIDColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                table_info.set_columns_info((table_info.get_columns_info() or []) + [id_column])

        else:
            if source_fk_table_name in source_table_name_to_table_info:
                fk_table_info = source_table_name_to_table_info.get(source_fk_table_name)
                if fk_table_info.get_depth() < fk_tables_depth:
                    increment_tables_depth(
                        table_info=fk_table_info,
                        increment_size=fk_tables_depth - fk_table_info.get_depth(),
                    )
            else:
                if isinstance(fk_column_data_type, UUID):
                    id_column = UuidColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                else:
                    id_column = IncrementalIDColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                fk_table_info = TableInfo(
                    profile_table_name=profile_fk_table_name,
                    source_table_name=source_fk_table_name,
                    columns_info=[
                        id_column
                    ],
                    conn=conn,
                    depth=fk_tables_depth,
                )
                profile_table_name_to_table_info[profile_fk_table_name] = fk_table_info
                source_table_name_to_table_info[source_fk_table_name] = fk_table_info
            table_info.add_dependent_table(fk_table_info)

            fk_columns_names_of_columns_info = fk_table_info.get_columns_names()
            if (fk_column_name not in fk_columns_names_of_columns_info
                    and not fk_table_info.is_immutable):
                if isinstance(fk_column_data_type, UUID):
                    id_column = UuidColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                else:
                    id_column = IncrementalIDColumn(
                        column_name=fk_column_name,
                        data_type=fk_column_data_type,
                    )
                fk_table_info.set_columns_info((fk_table_info.get_columns_info() or []) + [id_column])

            add_linked_tables(
                table_info=fk_table_info,
                fk_tables_depth=fk_table_info.get_depth() + 1,
                profile_table_name_to_table_info=profile_table_name_to_table_info,
                source_table_name_to_table_info=source_table_name_to_table_info,
                max_searchable_depth=max_searchable_depth,
                postfix_for_computed_fk_tables=postfix_for_computed_fk_tables,
            )

            if (column_name not in columns_names_of_columns_info
                    and not table_info.is_immutable):
                if not fk_table_info.is_dict:
                    fk_column = ForeignKeyRandomSamplingColumn(
                        column_name=column_name,
                        data_type=column_data_type,
                        foreign_key_table_name=profile_fk_table_name,
                        foreign_key_column_name=fk_column_name,
                    )
                else:
                    fk_table_profile = fk_table_info.get_table_profile()
                    fk_table_info.set_table_profile(fk_table_profile)
                    values, probabilities = ForeignKeyCategoricalSamplingColumn.get_values_and_probabilities(
                        engine=conn,
                        table_name=source_table_name,
                        column_name=column_name,
                        id_mapping=fk_table_profile.get('id_mapping'),
                    )
                    fk_column = ForeignKeyCategoricalSamplingColumn(
                        column_name=column_name,
                        data_type=column_data_type,
                        foreign_key_table_name=profile_fk_table_name,
                        foreign_key_column_name=fk_column_name,
                        values=values,
                        probabilities=probabilities,
                    )
                table_info.set_columns_info((table_info.get_columns_info() or []) + [fk_column])


def compute_dependencies(
        profile_table_name_to_table_info: Dict[str, TableInfo],
        max_searchable_depth: int,
        postfix_for_computed_fk_tables: str,
):
    tables_info = list(profile_table_name_to_table_info.values())
    source_table_name_to_table_info = {
        table_info.get_source_table_name(): table_info
        for table_info in tables_info
        if table_info.get_source_table_name() is not None
    }

    for table_info in tables_info:
        table_depth = table_info.get_depth()
        source_table_name = table_info.get_source_table_name()
        if source_table_name is None:
            continue

        if table_info.get_max_search() is not None:
            table_max_searchable_depth = table_info.get_depth() + table_info.get_max_search()
        else:
            table_max_searchable_depth = max_searchable_depth

        add_linked_tables(
            table_info=table_info,
            profile_table_name_to_table_info=profile_table_name_to_table_info,
            source_table_name_to_table_info=source_table_name_to_table_info,
            fk_tables_depth=table_depth + 1,
            max_searchable_depth=table_max_searchable_depth,
            postfix_for_computed_fk_tables=postfix_for_computed_fk_tables,
        )


def set_conn(
        conn,
        tables_info: List[TableInfo],
) -> None:
    for table_info in tables_info:
        if not table_info.get_conn():
            table_info.set_conn(conn)


def generate_tables_profile(
        output_tables_profile_path: str,
        tables_info: List[TableInfo],
        max_searchable_depth: int = 0,
        postfix_for_computed_fk_tables: str = '',
        conn=None,
) -> None:
    tables_info = copy(tables_info)
    set_conn(
        conn=conn,
        tables_info=tables_info,
    )
    profile_table_name_to_table_info = {
        table_info.get_profile_table_name(): table_info
        for table_info in tables_info
    }
    compute_dependencies(
        profile_table_name_to_table_info=profile_table_name_to_table_info,
        max_searchable_depth=max_searchable_depth,
        postfix_for_computed_fk_tables=postfix_for_computed_fk_tables,
    )

    tables_profile = defaultdict(dict)
    for profile_table_name, table_info in profile_table_name_to_table_info.items():
        table_depth = table_info.get_depth()
        source_table_name = table_info.get_source_table_name()
        logger.info(f'TABLE depth={table_depth}: {profile_table_name} (source table: {source_table_name})')
        table_profile = table_info.get_table_profile()
        if table_info.is_dict:
            del table_profile['id_mapping']
        tables_profile[table_depth][profile_table_name] = table_profile

    load_profile_to_json(output_tables_profile_path, tables_profile)
    logger.info(f'Profile was loaded into {output_tables_profile_path}')
