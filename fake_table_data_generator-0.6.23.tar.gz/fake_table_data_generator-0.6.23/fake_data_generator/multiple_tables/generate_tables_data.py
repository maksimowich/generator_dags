from typing import List
import json

from loguru import logger

from .. import generate_table_from_profile


class GenerationInfo:
    def __init__(
            self,
            table_name: str,
            rows_to_insert: int = None,
            batch_size: int = None,
            output_file_starting_postfix: int = None,
    ):
        self.table_name = table_name
        self.rows_to_insert = rows_to_insert
        self.batch_size = batch_size
        self.output_file_starting_postfix = output_file_starting_postfix


def generate_tables_data(
        tables_profile_path: str,
        depth_levels: List[int] = None,
        table_names: List[str] = None,
        generation_info: List[GenerationInfo] = None,
        conn=None,
        output_file_format=None,
) -> None:
    if tables_profile_path is not None:
        with open(tables_profile_path, 'r', encoding='utf-8') as file:
            tables_profile = json.load(file)
    else:
        raise Exception()

    generation_info = {info.table_name: info for info in (generation_info or {})}
    for depth_level in sorted(depth_levels or tables_profile, key=lambda x: int(x), reverse=True):
        logger.info(f" ------------- Depth: {depth_level} -------------")
        for table_name, table_info in tables_profile.get(depth_level).items():
            if table_names is None or table_name in table_names:
                table_generation_info = generation_info.get(table_name) or GenerationInfo(table_name)

                rows_to_insert = table_generation_info.rows_to_insert or table_info.get('rows_to_insert')
                batch_size = table_generation_info.batch_size or table_info.get('batch_size')
                output_file_starting_postfix = table_generation_info.output_file_starting_postfix or 1
                table_profile = table_info.get('columns')

                generate_table_from_profile(
                    dest_table_name=table_name,
                    number_of_rows_to_insert=rows_to_insert,
                    batch_size=batch_size,
                    conn=conn,
                    output_file_format=output_file_format,
                    output_file_starting_postfix=output_file_starting_postfix,
                    source_table_profile=table_profile,
                )
