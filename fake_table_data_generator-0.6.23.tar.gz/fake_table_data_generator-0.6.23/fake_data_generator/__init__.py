import sys
from loguru import logger
from .columns import *
from .data_types import *
from .single_table import (
    get_table_profile,
    generate_table_profile,
    generate_table_from_profile,
)
from .multiple_tables import (
    TableInfo,
    GenerationInfo,
    generate_tables_profile,
    generate_tables_data,
)

logger.remove(0)
logger.add(
    sys.stdout,
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level}</level> | <cyan>{message}</cyan>",
    filter=lambda record: 'Column "None"' not in record["message"],
)

del generate_data, get_historicity_pattern, Pattern
