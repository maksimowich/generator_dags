from abc import ABCMeta

from ..DataType import DataType


class IntegerType(DataType, metaclass=ABCMeta):
    NUMPY_TYPE = None
