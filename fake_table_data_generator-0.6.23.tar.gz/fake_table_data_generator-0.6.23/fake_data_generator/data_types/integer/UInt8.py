import numpy as np

from .IntegerType import IntegerType


class UInt8(IntegerType):
    NUMPY_TYPE = np.uint8
