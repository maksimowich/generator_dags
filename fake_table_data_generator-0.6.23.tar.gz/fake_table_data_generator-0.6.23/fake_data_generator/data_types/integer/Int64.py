import numpy as np

from .IntegerType import IntegerType


class Int64(IntegerType):
    NUMPY_TYPE = np.int64
