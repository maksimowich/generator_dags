import numpy as np

from .IntegerType import IntegerType


class Int8(IntegerType):
    NUMPY_TYPE = np.int8
