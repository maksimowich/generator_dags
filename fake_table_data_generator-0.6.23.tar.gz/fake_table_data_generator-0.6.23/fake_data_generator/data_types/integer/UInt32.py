import numpy as np

from .IntegerType import IntegerType


class UInt32(IntegerType):
    NUMPY_TYPE = np.uint32
