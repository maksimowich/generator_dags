import numpy as np

from .IntegerType import IntegerType


class Int32(IntegerType):
    NUMPY_TYPE = np.int32
