import numpy as np

from .IntegerType import IntegerType


class UInt64(IntegerType):
    NUMPY_TYPE = np.uint64
