import numpy as np

from .IntegerType import IntegerType


class Int16(IntegerType):
    NUMPY_TYPE = np.int16
