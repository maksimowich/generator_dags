from ..DataType import DataType


class Date(DataType):
    pass
