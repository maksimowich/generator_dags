from ..DataType import DataType


class TimestampWithTZ(DataType):
    pass
