from ..DataType import DataType


class Timestamp(DataType):
    pass
