from ..DataType import DataType


class Float32(DataType):
    pass
