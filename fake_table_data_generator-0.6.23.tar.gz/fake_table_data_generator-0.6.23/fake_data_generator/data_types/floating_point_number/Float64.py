from ..DataType import DataType


class Float64(DataType):
    pass
