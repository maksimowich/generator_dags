from .DataType import DataType


class Boolean(DataType):
    pass
