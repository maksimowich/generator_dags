from .DataType import DataType


class UUID(DataType):
    pass
