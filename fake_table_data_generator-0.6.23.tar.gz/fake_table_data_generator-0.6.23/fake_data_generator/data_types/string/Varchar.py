from ..DataType import DataType


class Varchar(DataType):
    def __init__(
            self,
            n: int,
    ):
        self.n = n

    def __str__(self):
        return f"{self.__class__.__name__}({self.n})"
