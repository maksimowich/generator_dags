from ..DataType import DataType


class String(DataType):
    pass
