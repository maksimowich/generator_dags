from .DataType import DataType


class Decimal(DataType):
    def __init__(
            self,
            precision: int = None,
            scale: int = None,
    ):
        self.precision = precision
        self.scale = scale

    def __str__(self):
        if self.precision is None and self.scale is None:
            return self.__class__.__name__
        elif self.scale is None:
            return f"{self.__class__.__name__}({self.precision})"
        else:
            return f"{self.__class__.__name__}({self.precision},{self.scale})"
