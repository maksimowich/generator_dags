from typing import List, Union
import importlib

from loguru import logger

from .databases import get_db, RELATIONAL_DATABASES
from .databases.errors import ConnectionTypeIsNotSupported
from .columns import (
    Pattern,
    Column,
    MultipleColumns,
    IDColumn,
    FKColumn,
)


def create_table(
        conn,
        table_name: str,
        table_patterns: List[Pattern],
        columns_order: List[str],
        partition_columns: List[str],
        table_details: str,
) -> None:
    """
    Create table in database.
    """
    db = get_db(conn)

    columns_names_and_types: List[str] = []
    for pattern in table_patterns:
        if isinstance(pattern, MultipleColumns):
            for column in pattern.get_columns():
                column_names_and_type = f"{column.get_column_name()} {db.get_db_data_type(column.get_data_type())}"
                columns_names_and_types.append(column_names_and_type)

        elif isinstance(pattern, Column):
            data_type = db.get_db_data_type(data_type=pattern.get_data_type())
            if (isinstance(pattern, FKColumn)
                    and pattern.fk_constraint
                    and db in RELATIONAL_DATABASES):
                columns_names_and_types.append(
                    f"{pattern.get_column_name()} {data_type} "
                    f"REFERENCES {pattern.get_fk_table_name()}({pattern.get_fk_column_name()})"
                )

            elif (isinstance(pattern, IDColumn)
                  and pattern.pk_constraint
                  and db in RELATIONAL_DATABASES):
                columns_names_and_types.append(f"{pattern.get_column_name()} {data_type} UNIQUE")

            else:
                columns_names_and_types.append(f"{pattern.get_column_name()} {data_type}")

        else:
            raise TypeError

    if columns_order is not None:
        columns_names_and_types = sorted(
            columns_names_and_types,
            key=lambda x: columns_order.index(x.split(' ')[0]) if x.split(' ')[0] in columns_order else float('inf')
        )

    create_query = db.get_create_query(
        table_name_and_schema=table_name,
        columns_names_and_types=', '.join(columns_names_and_types),
        partition_columns=partition_columns,
        table_details=table_details,
    )

    if conn.__class__.__name__ == 'Engine':
        sqlalchemy = importlib.import_module("sqlalchemy")
        query = sqlalchemy.text(create_query)
        with conn.connect() as connection:
            # Using explicit transaction commit to create table even if 0 rows are inserted.
            # This hackish way resolves the problem that timestamptz data changes the time to timestamp
            # when None exist in the column
            trans = connection.begin()
            connection.execute(query)
            trans.commit()

    elif conn.__class__.__name__ == 'SparkSession':
        conn.sql(create_query)

    else:
        raise ConnectionTypeIsNotSupported()

    logger.info(f'Table {table_name} was created')
