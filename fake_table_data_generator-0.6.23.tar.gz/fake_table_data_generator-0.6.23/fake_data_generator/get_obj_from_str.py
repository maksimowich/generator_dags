import inspect
import re

import fake_data_generator
from .data_types import (
    Int64, Int32, Int16, Int8,
    Timestamp, TimestampWithTZ,
    String, Varchar,
    Decimal, Float64,
)

CLS_NAME_TO_CLS = {
    cls_name.lower(): cls
    for cls_name, cls in inspect.getmembers(fake_data_generator.data_types, inspect.isclass)
}

# adding aliases for backward compatibility
CLS_NAME_TO_CLS["bigint"] = Int64
CLS_NAME_TO_CLS["int"] = Int32
CLS_NAME_TO_CLS["integer"] = Int32
CLS_NAME_TO_CLS["smallint"] = Int16
CLS_NAME_TO_CLS["tinyint"] = Int8
CLS_NAME_TO_CLS["datetime"] = Timestamp
CLS_NAME_TO_CLS["timestamp with time zone"] = TimestampWithTZ
CLS_NAME_TO_CLS["text"] = String
CLS_NAME_TO_CLS["numeric"] = Decimal
CLS_NAME_TO_CLS["double precision"] = Float64
CLS_NAME_TO_CLS["double"] = Float64


def get_obj_from_str(string):
    cls_name = re.split("[" + re.escape(",()") + "]", string.lower())
    cls = CLS_NAME_TO_CLS.get(cls_name[0])
    if len(cls_name) == 0:
        return cls()
    else:
        params = [int(param) for param in cls_name[1:] if param]
        return cls(*params)
