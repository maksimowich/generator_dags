import pytest
from sqlalchemy import create_engine, MetaData

from tests.credentials import CONNECTION_STRING


# ОБЩИЕ ДЛЯ ВСЕХ ТЕСТОВ ФИКСТУРЫ
@pytest.fixture(scope='session')
def engine():
    # создание объекта Engine для обращения к базе в тестах
    engine = create_engine(CONNECTION_STRING)
    return engine


@pytest.fixture(scope='session')
def metadata_obj(engine):
    metadata_obj = MetaData(engine)
    yield metadata_obj

    metadata_obj.reflect()
    metadata_obj.drop_all()


