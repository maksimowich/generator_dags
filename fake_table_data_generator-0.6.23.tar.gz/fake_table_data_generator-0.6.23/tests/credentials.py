from sqlalchemy import (
    Column,
    VARCHAR,
)
from datetime import date


# различные данные для тестов, архитектура в разработке

# строка подключения к базе postgres
CONNECTION_STRING = "postgresql+psycopg2://test:test@host.docker.internal:6543/test"

# название таблицы с корректными данными для снятия профиля
CORRECT_TABLE_NAME = 'all_correct'

# таблица сгенерированных данных для тестирования
SINGLE_COLUMN_TABLE_NAME = 'single_column_table'  # лучше вынести в отдельный файл для кредов генерации
SINGLE_COLUMN_CONTINUOUS_TABLE_NAME = 'single_column_continuous_table'
MULTI_INN_KPP_TABLE_NAME = 'multi_inn_kpp_table'
MULTI_LE_TABLE_NAME = 'multi_le_table'
MULTI_CLIENT_TABLE_NAME = 'multi_client_table'
MULTI_PASSPORT_TABLE_NAME = 'multi_passport_table'
MULTI_CATEGORICAL_TABLE_NAME = 'multi_categorical_table'

# список окончаний фамилий, на основании которых определяется их корректность
SURNAME_ENDINGS = ('ОВ', 'ОВА', 'ЕВ', 'ЕВА', 'ИН', 'ИНА', 'ИЙ', 'АЯ', 'ИЧ')

# самая ранняя дата выдачи паспорта
earliest_passport_issue_date = date(1997, 1, 1)



# колонки для генерации таблицы с корректными данными с помощью sqlalchemy
COLUMNS = [
    Column('inn_yur', VARCHAR(100)),
    Column('inn_fiz', VARCHAR(100))
]


# названия колонок таблицы с корректными данными
CORRECT_COLUMN_TITLES = [
    'inn_yur',
    'inn_fiz'
]

# данные колонок таблицы с корректными данными
COLUMN_VALUES = [
    ["7506591451","0149144543","7297981097","0829067060","7901269627","5653105350","2927033850","8968613794",
     "3674011822","4463423716"],
    ["447234429108","734836988888","529181665735","183243329848","407632276228","166551162507","439015968230",
     "659633675944","135747431842","861620975596"]
]  # в будущем перейти на дамп базы

# список доменов для генерации email
DOMAIN_LIST = ['gmail.com', 'mail.ru', 'yandex.ru', 'yahoomail.com', 'outlook.com']

# словарь для транслитерирования слов по ГОСТ Р52535.1-2006
EMBOSS_LETTERS = {
        "А": "A",
        "Б": "B",
        "В": "V",
        "Г": "G",
        "Д": "D",
        "Е": "E",
        "Ё": "E",
        "Ж": "ZH",
        "З": "Z",
        "И": "I",
        "Й": "I",
        "К": "K",
        "Л": "L",
        "М": "M",
        "Н": "N",
        "О": "O",
        "П": "P",
        "Р": "R",
        "С": "S",
        "Т": "T",
        "У": "U",
        "Ф": "F",
        "Х": "KH",
        "Ц": "TC",
        "Ч": "CH",
        "Ш": "SH",
        "Щ": "SHCH",
        "Ы": "Y",
        "Э": "E",
        "Ю": "IU",
        "Я": "IA"
    }