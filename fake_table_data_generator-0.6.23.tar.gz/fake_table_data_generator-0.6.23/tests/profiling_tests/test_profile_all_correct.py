from sqlalchemy.engine.base import Engine
from fake_data_generator import generate_table_profile

from tests.credentials import CORRECT_TABLE_NAME


def test_profiling_correct_table(engine: Engine, correct_table):
    # Тест в разработке. Должен снимать профиль с таблицы и сравнивать его с заранее подготовленным профилем
    # пока только снимает профиль и сохраняет в файл (стандартный функционал генератора), анализ вручную
    generate_table_profile(
        output_table_profile_path=f'{CORRECT_TABLE_NAME}.json',
        conn=engine,
        source_table_name=f'public.all_correct',
        number_of_rows_from_which_create_patterns=100,
        number_of_intervals=10,
        columns_info=[]
    )
