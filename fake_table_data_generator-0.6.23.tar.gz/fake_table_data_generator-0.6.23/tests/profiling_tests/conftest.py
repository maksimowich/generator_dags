import pytest
from sqlalchemy import create_engine, MetaData, Table, insert
from sqlalchemy.engine.base import Engine

from tests.converter import make_rows
from tests.credentials import (
    CORRECT_TABLE_NAME,
    COLUMNS, CORRECT_COLUMN_TITLES, COLUMN_VALUES, CONNECTION_STRING
)


@pytest.fixture(scope='session')
def engine():
    # creating sqlalchemy Engine to connect to database
    engine = create_engine(CONNECTION_STRING)
    return engine


# ФИКСТУРЫ ПРОФАЙЛИНГА
@pytest.fixture(scope='session')
def correct_table(engine: Engine): 
    # creating table in database
    metadata_obj = MetaData()
    correct_table = Table(
        CORRECT_TABLE_NAME,
        metadata_obj,
        *COLUMNS
    )
    correct_table.create(engine)

    # filling created table with data
    engine.execute(
        insert(correct_table),
        make_rows(CORRECT_COLUMN_TITLES, COLUMN_VALUES)
    )
    # returning table to use it late for getting data from it
    yield correct_table
    # deleting table after tests are finished
    correct_table.drop(engine)
    # os.remove(f'{creds.all_correct_table_name}.json')
