# вспомогательные функции для преобразования полученных из таблицы данных или записи данных в базу
def get_columns(select_output, column_titles):
    # Функция раскладывает данные таблицы из sqlalchemy в словарь, где ключ - название колонки, значение - список значений
    # этой колонки
    columns = {}

    for i in range(len(column_titles)):
        column_values = []
        for j in range(len(select_output)):
            column_values.append(select_output[j][i])
        columns[column_titles[i]] = column_values
    
    return columns


def make_rows(column_titles, column_values):
    # Функция превращает список названий колонок и список списков значений этих колонок в словарь для записи данных в базу
    # через sqlalchemy
    rows = []
    
    for i in range(len(column_values[0])):
        row = {}
        for j in range(len(column_titles)):
            row[column_titles[j]] = column_values[j][i]
        rows.append(row)
    
    return rows
    